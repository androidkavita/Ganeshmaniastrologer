package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.HistoryOfReportLayoutBinding
import com.callastrouser.model.ReportsHistoryResponseData

class ReportsHistoryAdapter (val context : Context, var data: ArrayList<ReportsHistoryResponseData>, var linear:ClickReport) :
    RecyclerView.Adapter<ReportsHistoryAdapter.ViewHolder>() {
    lateinit var file :String
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: HistoryOfReportLayoutBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReportsHistoryAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.history_of_report_layout, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ReportsHistoryAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.rawdata.text = List.text.toString()
        Glide.with(context).load(List.profile).into(holder.binding.ivImage)
        holder.binding.tvName.text = List.name

        var startDate: String = List.created_at.toString()
        var splitLink = startDate.split(" ").toTypedArray()
        var start = splitLink[0]
        var end = splitLink[1]
        holder.binding.date.text = start
        holder.binding.download.setOnClickListener {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(List.file)))
        }
        holder.binding.linearItem.setOnClickListener {
            linear.layoutid(List.id.toString(),holder.binding.linearItem)
        }

    }

    override fun getItemCount(): Int {
        return data.size
    }
}
interface ClickReport{
    fun layoutid(id:String,layout:LinearLayout)
}