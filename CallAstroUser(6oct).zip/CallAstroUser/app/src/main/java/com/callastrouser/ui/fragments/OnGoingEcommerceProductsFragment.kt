package com.callastrouser.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.MyOrderEcommersAdapter
import com.callastrouser.databinding.FragmentOnGoingEcommerceProductsBinding
import com.callastrouser.model.MyOrdersEcommersProductData
import com.callastrouser.ui.activities.BookingDetailsActivity
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.OrderDetailsViewModel
import com.maxtra.astrorahi.interfaces.ProductDetails
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class OnGoingEcommerceProductsFragment : BaseFragment(),ProductDetails {
    lateinit var binding: FragmentOnGoingEcommerceProductsBinding
    private val viewModel: OrderDetailsViewModel by viewModels()
    lateinit var adapter: MyOrderEcommersAdapter
    var List :ArrayList<MyOrdersEcommersProductData> = arrayListOf()
    var flag:String = "1"
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentOnGoingEcommerceProductsBinding.inflate(inflater,container,false)

        viewModel.OrderDetail(
            "Bearer "+userPref.getToken().toString(),
            "1",
        )
        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.myorderResponse.observe(viewLifecycleOwner){
            if (it.status == 1){
                binding.rvOngoingEcommerce.visibility = View.VISIBLE
                binding.idNouser.visibility = View.GONE
                List.clear()
                List.addAll(it.data)
                adapter = MyOrderEcommersAdapter(requireContext(),List,this)
                binding.rvOngoingEcommerce.adapter = adapter
            }else{
                binding.rvOngoingEcommerce.visibility = View.GONE
                binding.idNouser.visibility = View.VISIBLE
                binding.nodatatext.text = "NO Data Found!!"
            }
        }
        return binding.root
    }

    override fun Details(button: Button, id: String,order_id:String) {
        button.setOnClickListener {
            startActivity(Intent(requireContext(), BookingDetailsActivity::class.java)
                .putExtra("id",id)
                .putExtra("order_id",order_id)
                .putExtra("flag",flag)
            )
        }
    }

    override fun onStart() {
        super.onStart()
        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.OrderDetail(
                "Bearer "+userPref.getToken().toString(),
                "1",
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }
    }

    override fun onResume() {
        super.onResume()
        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.OrderDetail(
                "Bearer "+userPref.getToken().toString(),
                "1",
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }
    }

}