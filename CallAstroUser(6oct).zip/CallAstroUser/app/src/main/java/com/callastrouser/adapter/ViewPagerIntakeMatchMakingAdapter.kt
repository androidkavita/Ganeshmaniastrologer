package com.callastrouser.adapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.callastrouser.ui.fragments.IntakeFormFragment
import com.callastrouser.ui.fragments.MatchMakingFragment


class ViewPagerIntakeMatchMakingAdapter(
    fragmentManager: FragmentManager,
    var astroid:String,
    var request_type:String,
    var fix:String,
    var sessiontype:String,
    var minimumbalence:String
) : FragmentPagerAdapter(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    private val titles =
        arrayOf("Intake Form","Match Making")

    override fun getItem(position: Int): Fragment {

        val bundle = Bundle()
        val fragment : Fragment
        return when (position) {
            0 -> {
                fragment = IntakeFormFragment()
                bundle.putString("id",astroid)
                bundle.putString("request_type",request_type)
                bundle.putString("fix",fix)
                bundle.putString("sessiontype",sessiontype)
                bundle.putString("minimumbalence",minimumbalence)
                fragment.arguments = bundle
                fragment

//                val bundle = Bundle()
//                bundle.putString("id",astroid)
//                bundle.putString("request_type",request_type)
//                val fragobj = IntakeFormFragment()
//                fragobj.setArguments(bundle)
//                supportFragmentManager.beginTransaction()?.replace(
//                    R.id.flContent,
//                    fragobj, "Payment"
//                )?.addToBackStack(null)?.commit()
            }

            else -> {
                fragment = MatchMakingFragment()
                bundle.putString("id",astroid)
                bundle.putString("request_type",request_type)
                bundle.putString("fix",fix)
                bundle.putString("sessiontype",sessiontype)
                bundle.putString("minimumbalence",minimumbalence)
                fragment.arguments = bundle
                fragment
            }
        }
    }

    override fun getCount(): Int {
        return titles.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return titles[position]
    }
}