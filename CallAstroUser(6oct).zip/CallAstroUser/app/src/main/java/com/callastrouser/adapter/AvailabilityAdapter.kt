package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowAvailabilityBinding
import com.callastrouser.model.AvailTimmings
import com.callastrouser.model.CalendarAvailability

class AvailabilityAdapter (val context : Context, var data: ArrayList<CalendarAvailability>) :
    RecyclerView.Adapter<AvailabilityAdapter.ViewHolder>() {
    var ListNew:ArrayList<AvailTimmings> = arrayListOf()
    lateinit var adapter:AvailabilitySlotAdapter
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowAvailabilityBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AvailabilityAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_availability, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: AvailabilityAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.tvDay.text = List.dayName.toString()
        holder.binding.tvDate.text = List.availDate.toString()
        ListNew.clear()
        ListNew.addAll(List.availTimmings)
        adapter = AvailabilitySlotAdapter(context,ListNew)
        holder.binding.rvMypayments.adapter = adapter
    }

    override fun getItemCount(): Int {
        return data.size
    }

}