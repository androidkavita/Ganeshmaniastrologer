package com.callastrouser.ui.activities

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.databinding.ActivityAboutUsBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.CustomerViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AboutUs : BaseActivity() {
    lateinit var binding: ActivityAboutUsBinding
    private val viewModel: CustomerViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_us)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_about_us)

        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "About Us"

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.AboutUsResponse.observe(this) {
            if (it?.status == 1) {
                binding.simpletext.text = it.data?.details.toString()
            } else {
                snackbar(it?.message!!)
            }
        }

        if (CommonUtils.isInternetAvailable(this@AboutUs)) {
            viewModel.AboutUs(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

    }
}