package com.callastro.data


import com.callastrouser.model.LoginResponse
import com.callastrouser.model.LoginverificationResponse
import com.callastrouser.model.RegistrationResponse
import com.callastrouser.model.AboutUsResponse
import com.callastrouser.model.ActiveHomeResponse
import com.callastrouser.model.AddAddressResponse
import com.callastrouser.model.AddressListResponse
import com.callastrouser.model.AgoraCreateUserResponse
import com.callastrouser.model.AgoraGenerateTokenResponse
import com.callastrouser.model.AstrologersListViewAllResponse
import com.callastrouser.model.AstrorahiResponse
import com.callastrouser.model.AvailabilityResponse
import com.callastrouser.model.BannerResponse
import com.callastrouser.model.BlogListResponse
import com.callastrouser.model.BookingDetailsResponse
import com.callastrouser.model.CallHistoryResponse
import com.callastrouser.model.CallRingResponse
import com.callastrouser.model.CallStartResponse
import com.callastrouser.model.CallendbyuserResponse
import com.callastrouser.model.CancelReasonResponse
import com.callastrouser.model.CartCountResponse
import com.callastrouser.model.CartListResponse
import com.callastrouser.model.CartPlaceOrderResponse
import com.callastrouser.model.CategoryProductResponse
import com.callastrouser.model.ChatAgoraResponse
import com.callastrouser.model.ChatFragmentResponse
import com.callastrouser.model.ChatHistoryResponse
import com.callastrouser.model.ChatListMessageResponse
import com.callastrouser.model.CheckChatEndResponse
import com.callastrouser.model.CityList
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.ConsultancyDetail
import com.callastrouser.model.ConsultancyOrderResponse
import com.callastrouser.model.EmailUs_Response
import com.callastrouser.model.ExpertizeResponse
import com.callastrouser.model.FAQResponse
import com.callastrouser.model.GetAstroDetailsResponse
import com.callastrouser.model.GetIntakeResponse
import com.callastrouser.model.GiveReviewResponse
import com.callastrouser.model.HistoryProductSuggestedResponse
import com.callastrouser.model.HistoryWallet
import com.callastrouser.model.IntakeResponse
import com.callastrouser.model.LanguageResponse
import com.callastrouser.model.LiveAstrologerResponse
import com.callastrouser.model.LiveastrologerviewallResponse
import com.callastrouser.model.MaritalStatusList
import com.callastrouser.model.MatchMakingResponse
import com.callastrouser.model.MissedCallChatResponse
import com.callastrouser.model.MyCartResponse
import com.callastrouser.model.MyOrdersEcommersProductResponse
import com.callastrouser.model.MyReviewsResponse
import com.callastrouser.model.NotificationResponse
import com.callastrouser.model.PlaceOrderResponse
import com.callastrouser.model.ProductResponse
import com.callastrouser.model.RechargeAmountDiscountResponse
import com.callastrouser.model.RemedyProductResponse
import com.callastrouser.model.RemedySuggestedResponse
import com.callastrouser.model.ReportIntakeDetail
import com.callastrouser.model.ReportsHistoryResponse
import com.callastrouser.model.ShopwithusViewallResponse
import com.callastrouser.model.StateList
import com.callastrouser.model.TransactionHistoryResponse
import com.callastrouser.model.ViewProfile
import com.callastrouser.model.ViewReportResponse
import com.callastrouser.model.WaitingListResponse
import com.callastrouser.model.WalletResponse
import com.callastrouser.model.ChatAcceptedResponse
import com.callastrouser.model.ChatCallCancelReasonResponse
import com.callastrouser.model.ChatRequestCancelResponse
import com.callastrouser.model.DThreeChartResponse
import com.callastrouser.model.EditAddressResponse
import com.callastrouser.model.GetAddressResponse
import com.callastrouser.model.GetAstroSlotsResponse
import com.callastrouser.model.GetBlogDetailResponse
import com.callastrouser.model.GetCustomerSupportChat
import com.callastrouser.model.GetGiftResponse
import com.callastrouser.model.GiveGiftResponse
import com.callastrouser.model.KundliMatchMakingResponse
import com.callastrouser.model.LiveCommentsModelClass
import com.callastrouser.model.MakeKundaliResponse
import com.callastrouser.model.NavmsaResponse
import com.callastrouser.model.Notiffication_Count_Response
import com.callastrouser.model.PlanetsResponse
import com.callastrouser.model.RecentSeeKundliResponse
import com.callastrouser.model.RemedyPoojaResponse
import com.callastrouser.model.SendKundliResponse
import com.callastrouser.model.UserAstroConnectStatusResponse
import com.callastrouser.model.call_ring_status_save_Response
import com.callastrouser.model.requesBody.MatchHoroscopeRequest
import com.google.gson.JsonObject
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    @FormUrlEncoded
    @POST("user_login")
    suspend fun login(
        @Field("country_code") country_code: String,
        @Field("mobile_no") mobile: String,
        @Field("device_id") device_id: String,
        @Field("device_type") device_type: String,
        @Field("device_name") device_name: String,
        @Field("device_token") device_token: String,
    ): Response<LoginResponse>

    @FormUrlEncoded
    @POST("user_verify_otp")
    suspend fun login_verification(
        @Field("id") id: String,
        @Field("otp") otp: String,
    ): Response<LoginverificationResponse>


    @FormUrlEncoded
    @POST("recent_otp")
    suspend fun recent_otp(
        @Field("mobile_no") mobile_no: String,
        @Field("type") type: String,
    ): Response<LoginResponse>


    @GET("notification_count")
    suspend fun notification_count(
        @Header("Authorization") authorization: String,
    ): Response<Notiffication_Count_Response>

    @GET("user_home")
    suspend fun liveAstrologers(
        @Header("Authorization") authorization: String,
    ): Response<LiveAstrologerResponse>

    @GET("banner")
    suspend fun banner(
        @Header("Authorization") authorization: String,
    ): Response<BannerResponse>

    @FormUrlEncoded
    @POST("live_end")
    suspend fun live_end(
        @Header("Authorization") authorization: String,
        @Field("timer") timer: String,
        @Field("from_user") from_user: String,
        @Field("to_user") to_user: String,
        @Field("type") type: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("add_comment")
    suspend fun add_comment(
        @Header("Authorization") authorization: String,
        @Field("message") message: String,
        @Field("channl_name") channel_name: String,
        @Field("astro_id") astro_id: String,
//        @Field("type") type: String,
    ): Response<CommonResponse>

    @GET("customer_support_email")
    suspend fun EmailUs(
        @Header("Authorization") authorization: String,
    ): Response<EmailUs_Response>

    @GET("user_wallet")
    suspend fun Wallet(
        @Header("Authorization") authorization: String,
    ): Response<WalletResponse>

    @GET("address_list")
    suspend fun AddressList(
        @Header("Authorization") authorization: String,
    ): Response<AddressListResponse>

    @FormUrlEncoded
    @POST("get_address")
    suspend fun get_address(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<GetAddressResponse>




    @FormUrlEncoded
    @POST("signup_save_profile")
    suspend fun Registration(
        @Field("id") id: String,
        @Field("name") name: String,
        @Field("dob") dob: String,
        @Field("birth_place") birth_place: String,
        @Field("gender") gender: String,
        @Field("birth_time") birth_time: String,
        @Field("email") email: String,
//        @Field("mobile_no") mobile_no: String,
        ): Response<RegistrationResponse>

    @FormUrlEncoded
    @POST("kundli_match")
    suspend fun kundli_match(
        @Header("Authorization") authorization: String,
        @Field("boy_name") boy_name: String,
        @Field("boy_birth_date") boy_birth_date: String,
        @Field("boy_birth_time") boy_birth_time: String,
        @Field("boy_birth_place") boy_birth_place: String,
        @Field("girl_name") girl_name: String,
        @Field("girl_birth_date") girl_birth_date: String,
        @Field("girl_birth_time") girl_birth_time: String,
        @Field("girl_birth_place") girl_birth_place: String,
    ): Response<MakeKundaliResponse>

    @GET("get_blog_list")
    suspend fun get_blog_list(
        @Header("Authorization") authorization: String,
    ): Response<BlogListResponse>

    @FormUrlEncoded
    @POST("get_blog_detail")
    suspend fun get_blog_detail(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<GetBlogDetailResponse>

    @FormUrlEncoded
    @POST("get_live_comments")
    suspend fun get_live_comments(
        @Header("Authorization") authorization: String,
        @Field("channel_name") channel_name: String,
    ): Response<LiveCommentsModelClass>

    @GET("active_home")
    suspend fun active_home(
        @Header("Authorization") authorization: String,
    ): Response<ActiveHomeResponse>

    @FormUrlEncoded
    @POST("strologer_availability")
    suspend fun strologer_availability(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<AvailabilityResponse>

    @FormUrlEncoded
    @POST("add_user_details_second")
    suspend fun MatchMaking(
        @Header("Authorization") authorization: String,
        @Field("boy_name") boy_name: String,
        @Field("dob_boy") dob_boy: String,
        @Field("birth_time_boy") birth_time_boy: String,
        @Field("place_birth_boy") place_birth_boy: String,
        @Field("occupation_boy") occupation_boy: String,
//        @Field("maritial_status_boy") maritial_status_boy: String,
//        @Field("topic_consultation_boy") topic_consultation_boy: String,
        @Field("girl_name") girl_name: String,
        @Field("dob_girl") dob_girl: String,
        @Field("birth_time_girl") birth_time_girl: String,
        @Field("place_birth_girl") place_birth_girl: String,
        @Field("occupation_girl") occupation_girl: String,
//        @Field("maritial_status_girl") maritial_status_girl: String,
//        @Field("topic_consultation_girl") topic_consultation_girl: String,
        @Field("request_type") request_type: String,
        @Field("astro_id") astro_id: String,
        @Field("language_id") language_id: String,
    ): Response<MatchMakingResponse>

    @FormUrlEncoded
    @POST("agora_generate_token")
    suspend fun agora_generate_tokenApi(
        @Header("Authorization") authorization: String,
        @Field("astro_id") astro_id: String,
        @Field("call_type") call_type: String,  // 1-audiocall, 2-videocall
    ): Response<AgoraGenerateTokenResponse>


    @GET("puja_video_list")
    suspend fun get_puja_list(
        @Header("Authorization") authorization: String,
    ): Response<RemedyPoojaResponse>

    @FormUrlEncoded
    @POST("strologer_details")
    suspend fun strologer_details(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<AstrorahiResponse>

    @GET("missed_requests")
    suspend fun missed_requests(
        @Header("Authorization") authorization: String,
    ): Response<MissedCallChatResponse>

    @GET("recharg_amount_list")
    suspend fun recharg_amount_list(
        @Header("Authorization") authorization: String,
    ): Response<RechargeAmountDiscountResponse>

    @FormUrlEncoded
    @POST("add_address")
    suspend fun AddAddress(
        @Header("Authorization") authorization: String,
        @Field("full_name") full_name: String,
        @Field("phone_no") phone_no: String,
        @Field("house_no") house_no: String,
        @Field("area") area: String,
//        @Field("state") state: String,
//        @Field("city") city: String,
        @Field("pincode") pincode: String,
        @Field("address_type") address_type: String,
    ): Response<AddAddressResponse>

    @FormUrlEncoded
    @POST("update_address")
    suspend fun UpdateAddress(
        @Header("Authorization") authorization: String,
        @Field("address_id") address_id: String,
        @Field("full_name") full_name: String,
        @Field("phone_no") phone_no: String,
        @Field("house_no") house_no: String,
        @Field("area") area: String,
//        @Field("state") state: String,
//        @Field("city") city: String,
        @Field("pincode") pincode: String,
        @Field("address_type") address_type: String,
    ): Response<EditAddressResponse>


    @FormUrlEncoded
    @POST("help")
    suspend fun help(
        @Header("Authorization") authorization: String,
        @Field("astro_id") astro_id: String,
        @Field("message") message: String,
        @Field("booking_id") booking_id: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("add_user_details_first")
    suspend fun add_user_details_first(
        @Header("Authorization") authorization: String,
        @Field("name") name: String,
        @Field("dob") dob: String,
        @Field("birth_time") birth_time: String,
        @Field("place_birth") place_birth: String,
        @Field("occupation") occupation: String,
        @Field("maritial_status") maritial_status: String,
        @Field("topic_consultation") topic_consultation: String,
        @Field("language_id") language_id: String,
        @Field("astro_id") astro_id: String,
        @Field("request_type") request_type: String,
//        @Field("state") state: String,
//        @Field("city") city: String,
        @Field("gender") gender :String,
        @Field("fixed_session") fixed_session :String,
        @Field("fixed_session_type") fixed_session_type :String,
        @Field("slot_date") slot_date :String,
        @Field("slot_time") slot_time :String,
    ): Response<IntakeResponse>


    @FormUrlEncoded
    @POST("add_report_intake")
    suspend fun add_report_intake(
        @Header("Authorization") authorization: String,
        @Field("astro_id") astro_id: String,
        @Field("report_id") report_id: String,
        @Field("full_name") full_name: String,
        @Field("gender") gender: String,
        @Field("dob") dob: String,
        @Field("birth_time") birth_time: String,
        @Field("place_birth") place_birth: String,
        @Field("occupation") occupation: String,
        @Field("maritial_status") maritial_status: String,
        @Field("topic_consultation") topic_consultation: String,
        @Field("language_id") language_id: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("request_for_report")
    suspend fun request_for_report(
        @Header("Authorization") authorization: String,
        @Field("dob") dob: String,
        @Field("time_birth") birth_time: String,
        @Field("place_birth") place_birth: String,
        @Field("occupation") occupation: String,
        @Field("maritial_status") maritial_status: String,
        @Field("topic") topic: String,
        @Field("astro_id") astro_id: String,
    ): Response<CommonResponse>


    @FormUrlEncoded
    @POST("report_intake_detail")
    suspend fun report_intake_detail(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<ReportIntakeDetail>

    @FormUrlEncoded
    @POST("send_chat_with_us")
    suspend fun send_chat_with_us(
        @Header("Authorization") authorization: String,
        @Field("message") caller_id: String,
    ): Response<CommonResponse>


    @GET("get_chat_with_us")
    suspend fun get_chat_with_us(
        @Header("Authorization") authorization: String,
    ): Response<GetCustomerSupportChat>

    @GET("language_list")
    suspend fun Language(
        @Header("Authorization") authorization: String,
    ): Response<LanguageResponse>

    @FormUrlEncoded
    @POST("callback_apply")
    suspend fun callback_apply(
        @Header("Authorization") authorization: String,
        @Field("mobile") mobile: String,
        @Field("message") message: String,
    ): Response<CommonResponse>

//    @FormUrlEncoded
//    @POST("add_to_cart")
//    suspend fun add_to_cart(
//        @Header("Authorization") authorization: String,
//        @Field("product_id") product_id: String,
//        @Field("type") type: String,
//    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("call_ring_status_save")
    suspend fun call_ring_status_save(
        @Header("Authorization") authorization: String,
        @Field("channel_name") channel_name: String,
    ): Response<call_ring_status_save_Response>

    @FormUrlEncoded
    @POST("call_ring_end")
    suspend fun call_ring_end(
        @Header("Authorization") authorization: String,
        @Field("channel_name") channel_name: String,
    ): Response<CommonResponse>

    @GET("about_us")
    suspend fun AboutUs(
        @Header("Authorization") authorization: String,
    ): Response<AboutUsResponse>

    @GET("notification")
    suspend fun Notification(
        @Header("Authorization") authorization: String,
    ): Response<NotificationResponse>

    @GET("faq")
    suspend fun FAQ(
        @Header("Authorization") authorization: String,
    ): Response<FAQResponse>

    @FormUrlEncoded
    @POST("add_to_cart")
    suspend fun add_to_cart(
        @Header("Authorization") authorization: String,
        @Field("product_id") product_id: String,
        @Field("type") type: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("cart_lists")
    suspend fun cart_lists(
        @Header("Authorization") authorization: String,
        @Field("coupon_code") coupon_code: String,
        @Field("address_id") address_id: String,
    ): Response<CartListResponse>


    @FormUrlEncoded
    @POST("cart_place_order")
    suspend fun cart_place_order(
        @Header("Authorization") authorization: String,
        @Field("address_id") address_id: String,
        @Field("payment_status") payment_status: String,
        @Field("payment_type") payment_type: String,
        @Field("transaction_id") transaction_id: String,
        @Field("order_from") orderfrom: String,
        @Field("product_id") product_id: String,
        @Field("coupon_discount") coupon_discount: String,
        @Field("qty") qty: String,
    ): Response<CartPlaceOrderResponse>

    @GET("user_profile2")
    suspend fun ViewProfile(
        @Header("Authorization") authorization: String,
    ): Response<ViewProfile>

    @GET("expertise_list")
    suspend fun Expertize(
        @Header("Authorization") authorization: String,
    ): Response<ExpertizeResponse>

    @GET("product_category_list")
    suspend fun Shopwithusviewall(
        @Header("Authorization") authorization: String,
    ): Response<ShopwithusViewallResponse>

    @GET("live_strologers")
    suspend fun Liveastrologersviewall(
        @Header("Authorization") authorization: String,
    ): Response<LiveastrologerviewallResponse>

    @GET("remedy_suggested")
    suspend fun remedysuggested(
        @Header("Authorization") authorization: String,
    ): Response<RemedySuggestedResponse>

    @GET("remedy_products")
    suspend fun remedyproduct(
        @Header("Authorization") authorization: String,
    ): Response<RemedyProductResponse>

    @FormUrlEncoded
    @POST("call_end_by_status")
    suspend fun call_end_by_status(
        @Header("Authorization") authorization: String,
        @Field("caller_id") caller_id: String,
    ): Response<CallendbyuserResponse>

    @FormUrlEncoded
    @POST("live_astrologer_user")
    suspend fun live_astrologer_user(
        @Header("Authorization") authorization: String,
        @Field("astro_id") astro_id: String,
        @Field("channel_name") channel_name: String,
        @Field("status") status: String,
    ): Response<CommonResponse>

    @GET("notification_read")
    suspend fun Notification_Read(
        @Header("Authorization") authorization: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("user_astro_connect_status")
    suspend fun user_astro_connect_status(
        @Header("Authorization") authorization: String,
        @Field("channel_name") channel_name: String,
    ): Response<UserAstroConnectStatusResponse>

    @FormUrlEncoded
    @POST("check_chat_end")
    suspend fun check_chat_end(
        @Header("Authorization") authorization: String,
        @Field("caller_id") caller_id: String,
    ): Response<CheckChatEndResponse>

    @FormUrlEncoded
    @POST("category_product_list")
    suspend fun CategoryList(
        @Header("Authorization") authorization: String,
        @Field("category_id") category_id: String,
    ): Response<CategoryProductResponse>

    @FormUrlEncoded
    @POST("product_deatil")
    suspend fun ProductDetails(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<ProductResponse>

    @FormUrlEncoded
    @POST("home_chat_list")
    suspend fun ChatList(
        @Header("Authorization") authorization: String,
        @Field("expertise_id") expertise_id: String,
        @Field("sort_filter") sort_filter: String,
    ): Response<ChatFragmentResponse>

    @FormUrlEncoded
    @POST("home_call_list")
    suspend fun CallList(
        @Header("Authorization") authorization: String,
        @Field("expertise_id") expertise_id: String,
        @Field("sort_filter") sort_filter: String
    ): Response<ChatFragmentResponse>

    @GET("history_wallet")
    suspend fun HistoryWallet(
        @Header("Authorization") authorization: String,
    ): Response<HistoryWallet>

    @GET("history_call")
    suspend fun history_call(
        @Header("Authorization") authorization: String,
    ): Response<CallHistoryResponse>

    @GET("history_chat")
    suspend fun history_chat(
        @Header("Authorization") authorization: String,
    ): Response<ChatHistoryResponse>

    @GET("history_reports")
    suspend fun history_reports(
        @Header("Authorization") authorization: String,
    ): Response<ReportsHistoryResponse>

    @GET("user_my_reveiw")
    suspend fun user_my_reveiw(
        @Header("Authorization") authorization: String,
    ): Response<MyReviewsResponse>

    @FormUrlEncoded
    @POST("history_products")
    suspend fun history_products(
        @Header("Authorization") authorization: String,
        @Field("type") type: String,
    ): Response<HistoryProductSuggestedResponse>

    @FormUrlEncoded
    @POST("my_orders")
    suspend fun my_orders(
        @Header("Authorization") authorization: String,
        @Field("type") type: String,
    ): Response<MyOrdersEcommersProductResponse>

    @GET("get_intake_report")
    suspend fun get_intake_report(
        @Header("Authorization") authorization: String,
    ): Response<GetIntakeResponse>

    @FormUrlEncoded
    @POST("booking_detail")
    suspend fun booking_detail(
        @Header("Authorization") authorization: String,
        @Field("order_id") order_id: String,
        @Field("product_id") product_id: String,
    ): Response<BookingDetailsResponse>

    @GET("consultancy_order")
    suspend fun consultancy_order(
        @Header("Authorization") authorization: String,
    ): Response<ConsultancyOrderResponse>

    @FormUrlEncoded
    @POST("consultancy_order_detail")
    suspend fun consultancy_order_detail(
        @Header("Authorization") authorization: String,
        @Field("booking_id") booking_id: String,
    ): Response<ConsultancyDetail>

    @FormUrlEncoded
    @POST("user_give_review")
    suspend fun user_give_review(
        @Header("Authorization") authorization: String,
        @Field("astro_id") astro_id: String,
        @Field("rating") rating: String,
        @Field("review") review: String,
        @Field("caller_id") caller_id: String,
        @Field("type") type: String,
    ): Response<GiveReviewResponse>

    @FormUrlEncoded
    @POST("product_give_review")
    suspend fun product_give_review(
        @Header("Authorization") authorization: String,
        @Field("product_id") astro_id: String,
        @Field("rating") rating: String,
        @Field("reveiw") review: String,
    ): Response<GiveReviewResponse>

    @FormUrlEncoded
    @POST("call_request_cancel")
    suspend fun call_request_cancel_api(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
        @Field("reason") reason: String,
        @Field("comment") comment: String,
        @Field("action_by") action_by: String,
    ): Response<ChatRequestCancelResponse>

    @GET("reason_cancel_list")
    suspend fun chatcallReasonCancelListApi(
        @Header("Authorization") authorization: String,
    ): Response<ChatCallCancelReasonResponse>

    @GET("gifts")
    suspend fun gifts(
        @Header("Authorization") authorization: String,
    ): Response<GetGiftResponse>

    @Multipart
    @POST("update_user_profile")
    suspend fun Editprofile(
        @Header("Authorization") authorization: String,
        @Part("name") name: RequestBody,
        @Part("mobile_no") mobile_no: RequestBody,
        @Part("email") email: RequestBody,
        @Part("dob") dob: RequestBody,
        @Part("birth_place") address: RequestBody,
        @Part("birth_time") birth_time: RequestBody,
        @Part("gender") gender: RequestBody,
       /* @Part("state") state: RequestBody,
        @Part("city") city: RequestBody,*/
        @Part profile: MultipartBody.Part
    ): Response<CommonResponse>

//    @GET("state_list")
//    suspend fun StateList(): Response<StateList>

    @FormUrlEncoded
    @POST("user_send_gifts")
    suspend fun user_send_gifts(
        @Header("Authorization") authorization: String,
        @Field("gift_id") id: String,
        @Field("astro_id") astro_id: String,
        @Field("channel_name") channel_name: String,
    ): Response<GiveGiftResponse>


    @GET("maritials_list")
    suspend fun maritials_list(
        @Header("Authorization") authorization: String,
    ): Response<MaritalStatusList>

//    @FormUrlEncoded
//    @POST("city_list")
//    suspend fun CityList(
//        @Field("state_id") state_id: Int,
//    ): Response<CityList>

    @FormUrlEncoded
    @POST("order_detail")
    suspend fun OrderDetails(
        @Header("Authorization") authorization: String,
        @Field("product_id") product_id: String,
        @Field("address_id") address_id: String,
        @Field("type") type: String,
        @Field("coupon_code") coupon_code: String,
    ): Response<MyCartResponse>

    @FormUrlEncoded
    @POST("place_order")
    suspend fun PlaceOrder(
        @Header("Authorization") authorization: String,
        @Field("product_id") product_id: String,
        @Field("product_price") product_price: String,
        @Field("shipping_chard") shipping_chard: String,
        @Field("coupon_discount") coupon_discount: String,
        @Field("grand_total") grand_total: String,
        @Field("coupon_code") coupon_code: String,
        @Field("address_id") address_id: String,
        @Field("qty") qty: String,
        @Field("transaction_id") transaction_id: String,
        @Field("payment_status") payment_status: String,
        @Field("payment_type") payment_type: String,
    ): Response<PlaceOrderResponse>

    @FormUrlEncoded
    @POST("agora_create_user")
    suspend fun agora_create_userApi(
        @Header("Authorization") authorization: String,
        @Field("to_userId") to_userId: String,
        @Field("nickname") nickname: String,
    ): Response<AgoraCreateUserResponse>

    @FormUrlEncoded
    @POST("chat_list")
    suspend fun chat_list_MessageApi(
        @Header("Authorization") authorization: String,
        @Field("to_id") to_id: String,
    ): Response<ChatListMessageResponse>

    @FormUrlEncoded
    @POST("get_astro_slot")
    suspend fun get_astro_slot(
        @Header("Authorization") authorization: String,
        @Field("date") date: String,
        @Field("astro_id") astro_id: String,
    ): Response<GetAstroSlotsResponse>

    @FormUrlEncoded
    @POST("planets")
    suspend fun planets(
        @Field("year") year : String,
        @Field("month") month: String,
        @Field("date") date: String,
        @Field("hours") hours: String,
        @Field("minutes") minutes: String,
        @Field("seconds") seconds: String,
        @Field("latitude") latitude: String,
        @Field("longitude") longitude: String,
        @Field("timezone") timezone: String,
    ): Response<PlanetsResponse>

    @FormUrlEncoded
    @POST("navamsa_chart")
    suspend fun navamsa_chart(
        @Field("year") year : String,
        @Field("month") month: String,
        @Field("date") date: String,
        @Field("hours") hours: String,
        @Field("minutes") minutes: String,
        @Field("seconds") seconds: String,
        @Field("latitude") latitude: String,
        @Field("longitude") longitude: String,
        @Field("timezone") timezone: String,
    ): Response<NavmsaResponse>

    @FormUrlEncoded
    @POST("d3_chart")
    suspend fun dThreechart(
        @Field("year") year : String,
        @Field("month") month: String,
        @Field("date") date: String,
        @Field("hours") hours: String,
        @Field("minutes") minutes: String,
        @Field("seconds") seconds: String,
        @Field("latitude") latitude: String,
        @Field("longitude") longitude: String,
        @Field("timezone") timezone: String,
    ): Response<DThreeChartResponse>

    @GET("match_making")
    suspend fun match_making(
        @Query("year") year : String,
        @Query("month") month: String,
        @Query("date") date: String,
        @Query("hours") hours: String,
        @Query("minutes") minutes: String,
        @Query("seconds") seconds: String,
        @Query("latitude") latitude: String,
        @Query("longitude") longitude: String,
        @Query("timezone") timezone: String,
        @Query("fyear") fyear: String,
        @Query("fmonth") fmonth: String,
        @Query("fdate") fdate: String,
        @Query("fhours") fhours: String,
        @Query("fminutes") fminutes: String,
        @Query("fseconds") fseconds: String,
        @Query("flatitude") flatitude: String,
        @Query("flongitude") flongitude: String,
        @Query("ftimezone") ftimezone: String,
    ): Response<KundliMatchMakingResponse>


    @FormUrlEncoded
    @POST("insert_recently_see_kundali")
    suspend fun insert_recently_see_kundali(
        @Header("Authorization") authorization: String,
        @Field("name") name : String,
        @Field("year") year : String,
        @Field("month") month: String,
        @Field("date") date: String,
        @Field("hours") hours: String,
        @Field("minutes") minutes: String,
        @Field("seconds") seconds: String,
        @Field("latitude") latitude: String,
        @Field("longitude") longitude: String,
        @Field("timezone") timezone: String,
        @Field("birthplace") BirthPlace: String,
    ): Response<SendKundliResponse>


    @FormUrlEncoded
    @POST("recently_see_kundali")
    suspend fun recently_see_kundali(
        @Header("Authorization") authorization: String,
        @Field("type") type: String
    ): Response<RecentSeeKundliResponse>


    @FormUrlEncoded
    @POST("insert_recently_see_match_making_kundali")
    suspend fun insert_recently_see_match_making_kundali(
        @Header("Authorization") authorization: String,
        @Field("fname") fname : String,
        @Field("fdate") fdate : String,
        @Field("fmonth") fmonth: String,
        @Field("fyear") fyear: String,
        @Field("fhours") fhours: String,
        @Field("fminutes") fminutes: String,
        @Field("fseconds") fseconds: String,
        @Field("flatitude") flatitude: String,
        @Field("flongitude") flongitude: String,
        @Field("ftimezone") ftimezone: String,
        @Field("fbirthplace") fbirthplace: String,
        @Field("mname") mname : String,
        @Field("mdate") mdate : String,
        @Field("mmonth") mmonth: String,
        @Field("myear") myear: String,
        @Field("mhours") mhours: String,
        @Field("mminutes") mminutes: String,
        @Field("mseconds") mseconds: String,
        @Field("mlatitude") mlatitude: String,
        @Field("mlongitude") mlongitude: String,
        @Field("mtimezone") mtimezone: String,
        @Field("mbirthplace") mbirthplace: String,
    ): Response<SendKundliResponse>




    @FormUrlEncoded
    @POST("chatagora")
    suspend fun chatagoraApi(
        @Header("Authorization") authorization: String,
        @Field("to_userId") to_userId: String,
        @Field("message") message: String,
        @Field("type") type: String,
    ): Response<ChatAgoraResponse>

    @GET("reason_cancel_list")
    suspend fun reason_cancel_list(
        @Header("Authorization") authorization: String,
    ): Response<CancelReasonResponse>

    @GET("cart_item_count")
    suspend fun cart_item_count(
        @Header("Authorization") authorization: String,
    ): Response<CartCountResponse>

    @GET("strologers_list")
    suspend fun strologers_list(
        @Header("Authorization") authorization: String,
    ): Response<AstrologersListViewAllResponse>


    @FormUrlEncoded
    @POST("delete_address")
    suspend fun delete_address(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<CommonResponse>


    @FormUrlEncoded
    @POST("cancel_order")
    suspend fun cancel_order(
        @Header("Authorization") authorization: String,
        @Field("order_id") order_id: String,
        @Field("product_id") product_id: String,
        @Field("reason_ids") reason_ids: String,
        @Field("write_reason") write_reason: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("call_end")
    suspend fun call_end(
        @Header("Authorization") authorization: String,
        @Field("timer") timer: String,
        @Field("from_user") from_user: String,
        @Field("to_user") to_user: String,
        @Field("caller_id") caller_id: String,
        @Field("type") type: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("chat_end")
    suspend fun chat_end(
        @Header("Authorization") authorization: String,
        @Field("timer") timer: String,
        @Field("from_user") from_user: String,
        @Field("to_user") to_user: String,
        @Field("caller_id") caller_id: String,
        @Field("type") type: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("when_call_start")
    suspend fun when_call_start(
        @Header("Authorization") authorization: String,
        @Field("astro_id") astro_id: String,
    ): Response<CallStartResponse>

    @GET("history_wallets")
    suspend fun history_wallets(
        @Header("Authorization") authorization: String,
    ): Response<TransactionHistoryResponse>

    @FormUrlEncoded
    @POST("delete_cart")
    suspend fun delete_cart(
        @Header("Authorization") authorization: String,
        @Field("cart_id") cart_id: String
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("add_money")
    suspend fun add_money(
        @Header("Authorization") authorization: String,
        @Field("amount") amount: String,
        @Field("payment_status") payment_status: String,
        @Field("transaction_id") transaction_id: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("get_report_astro_details")
    suspend fun get_report_astro_details(
        @Header("Authorization") authorization: String,
        @Field("astro_id") astro_id: String,
    ): Response<GetAstroDetailsResponse>

    @GET("get_report_astro_list")
    suspend fun get_report_astro_list(
        @Header("Authorization") authorization: String,
    ): Response<AstrologersListViewAllResponse>

    @GET("waiting_chat_list")
    suspend fun waiting_chat_list(
        @Header("Authorization") authorization: String,
    ): Response<WaitingListResponse>

    @GET("waiting_call_list")
    suspend fun waiting_call_list(
        @Header("Authorization") authorization: String,
    ): Response<WaitingListResponse>

    @FormUrlEncoded
    @POST("chat_cancel_by_user")
    suspend fun chat_cancel_by_user(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("call_cancel_by_user")
    suspend fun call_cancel_by_user(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<CommonResponse>

    @GET("chat_accepted")
    suspend fun chat_accepted(
        @Header("Authorization") authorization: String,
    ): Response<ChatAcceptedResponse>

    @GET("call_accepted")
    suspend fun call_accepted(
        @Header("Authorization") authorization: String,
    ): Response<ChatAcceptedResponse>

    @GET("requests_wait_delete")
    suspend fun requests_wait_delete(
        @Header("Authorization") authorization: String,
    ): Response<CommonResponse>

    @FormUrlEncoded
    @POST("view_report_doc_upload")
    suspend fun view_report_doc_upload(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
    ): Response<ViewReportResponse>


    @FormUrlEncoded
    @POST("call_ring")
    suspend fun call_ring(
        @Header("Authorization") authorization: String,
        @Field("astro_id") astro_id: String,
        @Field("user_id") user_id: String,
        @Field("request_id") request_id: String,
    ): Response<CallRingResponse>


    @FormUrlEncoded
    @POST("call_recieved")
    suspend fun call_received(
        @Header("Authorization") authorization: String,
        @Field("unique_id") unique_id: String,
    ): Response<CommonResponse>


//    @GET("aggregate-match?")
//    fun users_about_us(
//        @Field("boy_dob")boy_dob:String,
//        @Field("boy_tob")boy_tob:String,
//        @Field("boy_tz")boy_tz:String,
//        @Field("boy_lat")boy_lat:String,
//        @Field("boy_lon")boy_lon:String,
//        @Field("girl_dob")girl_dob:String,
//        @Field("girl_tob")girl_tob:String,
//        @Field("girl_tz")girl_tz:String,
//        @Field("girl_lat")girl_lat:String,
//        @Field("girl_lon")girl_lon:String,
//        @Field("api_key")api_key:String,
//        @Field("lang")lang:String,
//    ): Call<JsonObject>

    @GET("aggregate-match?")
    fun users_about_us(
        @Query("boy_dob")boy_dob:String,
        @Query("boy_tob")boy_tob:String,
        @Query("boy_tz")boy_tz:String,
        @Query("boy_lat")boy_lat:String,
        @Query("boy_lon")boy_lon:String,
        @Query("girl_dob")girl_dob:String,
        @Query("girl_tob")girl_tob:String,
        @Query("girl_tz")girl_tz:String,
        @Query("girl_lat")girl_lat:String,
        @Query("girl_lon")girl_lon:String,
        @Query("api_key")api_key:String,
        @Query("lang")lang:String,
    ): Call<JsonObject>

    @FormUrlEncoded
    @POST("chart-asc")
    fun achart_asc(
        @Field("d")d:String,
        @Field("t")t:String,
        @Field("lat")lat:String,
        @Field("lon")lon:String,
        @Field("tz")tz:String,
        @Field("userid")userid:String,
        @Field("authcode")authcode:String,
    ): Call<JsonObject>


    @FormUrlEncoded
    @POST("chart-d9")
    fun chart_d9(
        @Field("d")d:String,
        @Field("t")t:String,
        @Field("lat")lat:String,
        @Field("lon")lon:String,
        @Field("tz")tz:String,
        @Field("userid")userid:String,
        @Field("authcode")authcode:String,
    ): Call<JsonObject>



}