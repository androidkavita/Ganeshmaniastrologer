package com.callastrouser.ui.fragments

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.fragment.app.viewModels
import com.airbnb.lottie.LottieAnimationView
import com.bumptech.glide.Glide
import com.callastro.baseClass.BaseFragment
import com.callastrouser.R
import com.callastrouser.adapter.Astroid
import com.callastrouser.adapter.ChatAdapter
import com.callastrouser.adapter.expertizeAdapter
import com.callastrouser.databinding.FragmentChatBinding
import com.callastrouser.model.ChatFragmentResponseData
import com.callastrouser.model.ExpertizeResponseData
import com.callastrouser.ui.activities.AstrologerProfileActivity
import com.callastrouser.ui.activities.ChatActivity
import com.callastrouser.ui.activities.IntakeMatchMakingFormActivity
import com.callastrouser.ui.activities.PaymentInformation
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.HomeViewModel
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.maxtra.astrorahi.interfaces.CallChat
import dagger.hilt.android.AndroidEntryPoint
import de.hdodenhof.circleimageview.CircleImageView

@AndroidEntryPoint
class Chat : BaseFragment(), CallChat, Astroid {
    lateinit var binding : FragmentChatBinding
    private val viewModel: HomeViewModel by viewModels()
    lateinit var adapter : expertizeAdapter
    lateinit var adapter2 : ChatAdapter
    var Listdata: ArrayList<ExpertizeResponseData> = ArrayList()
    var Listdata2: ArrayList<ChatFragmentResponseData> = ArrayList()
    lateinit var bottomdialog: BottomSheetDialog
    lateinit var dialogs: Dialog
    lateinit var StartChatdialog: Dialog
    lateinit var id:String
    lateinit var names:String
    lateinit var charges:String
    lateinit var times:String
    lateinit var profiles:String
    lateinit var profiles2:String
    lateinit var user_name:String
    lateinit var caller_id:String
    var scpflag: String = ""
    lateinit var astroid:String
    lateinit var astro_name:String
    lateinit var astroProfile:String
    var shahbaz:Boolean = false
    var expertiesdata :String = ""
    var filterdatadata :String = ""
    val handlerStatusCheck = Handler(Looper.getMainLooper())
    var runnableStatusCheck: Runnable? = null
    private var vib: Vibrator? = null
    var mMediaPlayer: MediaPlayer? = null
    val handlerStatus1Check = Handler(Looper.getMainLooper())
    var runnableStatus1Check: Runnable? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentChatBinding.inflate(inflater, container, false)

        bottomdialog = BottomSheetDialog(requireContext())
        dialogs = Dialog(requireContext())
        StartChatdialog = Dialog(requireContext(), android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        binding.filter.setOnClickListener {
            Filter()
        }
        viewModel.waiting_chat_list(
            "Bearer "+userPref.getToken().toString()
        )
        binding.swipeRefreshlayout.setOnRefreshListener {
            if (CommonUtils.isInternetAvailable(requireContext())) {
                viewModel.Expertize(
                    "Bearer "+userPref.getToken().toString()
                )
                viewModel.Chat(
                    "Bearer "+userPref.getToken().toString(),expertiesdata,filterdatadata
                )

            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast("Please check internet connection.")
            }
            binding.swipeRefreshlayout.isRefreshing = false
        }

        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.Expertize(
                "Bearer "+userPref.getToken().toString()
            )
            viewModel.Chat(
                "Bearer "+userPref.getToken().toString(),expertiesdata,filterdatadata
            )
            handlerStatusCheck.postDelayed(Runnable { //do something
                handlerStatusCheck.postDelayed(runnableStatusCheck!!, 5000)
                viewModel.chat_accepted(
                    "Bearer "+userPref.getToken().toString()
                )
            }.also { runnableStatusCheck = it }, 0)
        } else {
            toast("Please check internet connection.")
        }
        viewModel.chatResponse.observe(viewLifecycleOwner){
            if (it?.status == 1){
//                toast(it.message.toString())
                Listdata2.clear()
                Listdata2.addAll(it.data!!)
                adapter2 = ChatAdapter(requireContext(), Listdata2,this)
                binding.rvAstrologers.adapter =adapter2
                adapter2.notifyDataSetChanged()
            }else{
                toast(it.message.toString())
            }
        }
//        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
//            if (it) {
//                showProgressDialog()
//            } else {
//                hideProgressDialog()
//            }
//        }

        viewModel.expertizeResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
//                toast(it.message.toString())
                Listdata.clear()
                Listdata.addAll(it.data!!)
                adapter = expertizeAdapter(requireContext(), Listdata,this)
                binding.rvSuggestionsList.adapter =adapter
            } else {
//                toast(it.message.toString())
            }
        }


        viewModel.waitingResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                id = it.data?.id.toString()
                names = it.data?.name.toString()
                charges = "₹ ${it.data?.callingCharg.toString()}/min"
                times = it.data?.time.toString()
                profiles = it.data?.profile.toString()
                user_name = it.data?.user_name.toString()
                caller_id =it.data?.unique_id.toString()
                WaitList()
                WaitingDialog(requireContext())
            } else {
//                toast(it.message.toString())
                bottomdialog.dismiss()
                dialogs?.dismiss()
            }
        }
        viewModel.cancelResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                bottomdialog.dismiss()
                dialogs?.dismiss()
                StartChatdialog?.dismiss()
//                WaitingDialog(requireContext())
//                replaceFragment(Chat())
            } else {
                bottomdialog.dismiss()
                dialogs?.dismiss()
//                toast(it.message.toString())
            }
        }



        viewModel.chatacceptedResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                astroid = it.data?.astro_id.toString()
                astro_name = it.data?.astroName.toString()
                astroProfile = it.data?.astroProfile.toString()
                if (shahbaz == false){
                    if (it.data?.request_status!!.equals(2)){
                        StartChatDialog(requireContext())
                    }else{
                        bottomdialog.dismiss()
                        dialogs.dismiss()

                    }

                }
                bottomdialog.dismiss()
                dialogs.dismiss()
            }else if (it.status==0){

            }
//            else if(it?.status == 2) {
//                StartChatDialog(requireContext())
//            }

            binding.tvSearch.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

                }

                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

                }

                override fun afterTextChanged(text: Editable?) {
                    filterData(text.toString(), scpflag)
                }

            })
        }
        return binding.root
    }

    fun Filter() {
        // on below line we are creating a new bottom sheet dialog.
        bottomdialog = BottomSheetDialog(requireContext(),R.style.AppBottomSheetDialogTheme)
        // on below line we are inflating a layout file which we have created.
        val view = layoutInflater.inflate(R.layout.filter_layout, null)
        val metrics = DisplayMetrics()
        activity?.windowManager?.defaultDisplay?.getMetrics(metrics)
        bottomdialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
//        this.bottomdialog.getWindow()?.setBackgroundDrawableResource(R.drawable.lowerborder2);
        bottomdialog.behavior.peekHeight = metrics.heightPixels
        var cross = view.findViewById<ImageView>(R.id.cross)
        var radio1 = view.findViewById<Button>(R.id.radio1)
        var radio2 = view.findViewById<Button>(R.id.radio2)
        var radio3 = view.findViewById<Button>(R.id.radio3)
        var radio4 = view.findViewById<Button>(R.id.radio4)


        radio1.setOnClickListener {
            filterdatadata = "1"
            if (CommonUtils.isInternetAvailable(requireContext())) {
                viewModel.Chat(
                    "Bearer "+userPref.getToken().toString(),expertiesdata,filterdatadata
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast("Please check internet connection.")
            }
            bottomdialog.dismiss()
            dialogs?.dismiss()
        }
        radio2.setOnClickListener {
            filterdatadata = "2"
            if (CommonUtils.isInternetAvailable(requireContext())) {
                viewModel.Chat(
                    "Bearer "+userPref.getToken().toString(),expertiesdata,filterdatadata
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast("Please check internet connection.")
            }
            bottomdialog.dismiss()
            dialogs?.dismiss()
        }
        radio3.setOnClickListener {
            filterdatadata = "3"
            if (CommonUtils.isInternetAvailable(requireContext())) {
                viewModel.Chat(
                    "Bearer "+userPref.getToken().toString(),expertiesdata,filterdatadata
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast("Please check internet connection.")
            }
            bottomdialog.dismiss()
            dialogs?.dismiss()
        }
        radio4.setOnClickListener {
            filterdatadata = "4"
            if (CommonUtils.isInternetAvailable(requireContext())) {
                viewModel.Chat(
                    "Bearer "+userPref.getToken().toString(),expertiesdata,filterdatadata
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast("Please check internet connection.")
            }
            bottomdialog.dismiss()
            dialogs?.dismiss()
        }



        cross.setOnClickListener {
            bottomdialog.dismiss()
            dialogs?.dismiss()
        }
        // below line is use to set cancelable to avoid
        // closing of dialog box when clicking on the screen.
        bottomdialog.setCancelable(false)

        // on below line we are setting
        // content view to our view.
        bottomdialog.setContentView(view)

        // on below line we are calling
        // a show method to display a dialog.
        bottomdialog.show()
    }

    private fun filterData(searchText: String, scpflag: String) {
        var filteredStateList: java.util.ArrayList<ChatFragmentResponseData> = java.util.ArrayList()

        for (item in Listdata2) {
            try {
                if (item.name!!.toLowerCase().contains(searchText.toLowerCase())) {
                    filteredStateList.add(item)
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }


        try {

            adapter2?.filterList(filteredStateList)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    fun playSound() {
//            if (mMediaPlayer == null) {
        mMediaPlayer = MediaPlayer.create(requireContext(), R.raw.notification)
        vib = activity?.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vib!!.vibrate(1000)
        mMediaPlayer!!.isLooping = false
        mMediaPlayer!!.start()
//            } else mMediaPlayer!!.start()
    }
    override fun callchatLL(linear: LinearLayoutCompat, id: String, name:String, click: LinearLayout) {
//        linear.setOnClickListener {
//            startActivity(Intent(requireContext(),ChatActivity::class.java)
//                .putExtra("astroid",id)
//                .putExtra("request_type","1"))
//                .putExtra("astroid",id.toString())
//                .putExtra("astroname",name.toString()))
//        }

        linear.setOnClickListener {
            startActivity(Intent(requireContext(), IntakeMatchMakingFormActivity::class.java).putExtra("id",id).putExtra("request_type","1"))
        }
        click.setOnClickListener {
            startActivity(Intent(requireContext(), AstrologerProfileActivity::class.java).putExtra("id",id))
        }
    }
    fun WaitList() {
        // on below line we are creating a new bottom sheet dialog.

        // on below line we are inflating a layout file which we have created.
        val view = layoutInflater.inflate(R.layout.connection_schedule, null)
        val metrics = DisplayMetrics()
        activity?.windowManager?.defaultDisplay?.getMetrics(metrics)
        bottomdialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomdialog.behavior.peekHeight = metrics.heightPixels
        var name = view.findViewById<TextView>(R.id.name)
        var charge = view.findViewById<TextView>(R.id.charges)
        var time = view.findViewById<TextView>(R.id.time)
        var image = view.findViewById<CircleImageView>(R.id.image)
        var cancel = view.findViewById<LinearLayoutCompat>(R.id.cancel_ll)
        name.text = user_name.toString()
        charge.text = charges.toString()
        time.text = times.toString()
        Glide.with(requireContext()).load(profiles).into(image)
        cancel.setOnClickListener{

            if (CommonUtils.isInternetAvailable(requireContext())) {
                viewModel.chat_cancel_by_user(
                    "Bearer "+userPref.getToken().toString(),id
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast("Please check internet connection.")
            }




        }
//        var btnNo = view.findViewById<Button>(R.id.btnNo)
//        btnLogout.setOnClickListener {
//            userPref.clearPref()
//            startActivity(Intent(this, LoginActivity::class.java))
//            finishAffinity()
//            bottomdialog.dismiss()
//        }
//        btnNo.setOnClickListener {
//            bottomdialog.dismiss()
//        }
        // below line is use to set cancelable to avoid
        // closing of dialog box when clicking on the screen.
        bottomdialog.setCancelable(false)

        // on below line we are setting
        // content view to our view.
        bottomdialog.setContentView(view)
        // on below line we are calling
        // a show method to display a dialog.
        bottomdialog.show()
    }



    fun WaitingDialog(context: Context)
    {
        dialogs.setContentView(R.layout.connectingpopup)
        val lottie =dialogs.findViewById<LottieAnimationView>(R.id.personal_edit_info_loader)
        lottie.initLoader(true)
        val circleimage1 = dialogs.findViewById<CircleImageView>(R.id.circleimage1)
        val circleimage2 = dialogs.findViewById<CircleImageView>(R.id.circleimage2)
        val name1 = dialogs.findViewById<TextView>(R.id.name2)
        val name2 = dialogs.findViewById<TextView>(R.id.name1)
        val btnSendOtp = dialogs.findViewById<TextView>(R.id.btnSendOtp)
        name1.text = user_name
        name2.text = names
        Glide.with(context).load(profiles).into(circleimage2)
        Glide.with(context).load(userPref.getProfile().toString()).into(circleimage1)
        btnSendOtp.setOnClickListener {
            dialogs.dismiss()
        }
//            val noBtn = dialog.findViewById<Button>(com.moteemaids.R.id.btnCancel)
//            noBtn.setOnClickListener {
//                dialog.dismiss()
//            }
//
//        viewModel.waitingResponse.observe(viewLifecycleOwner) {
//            if (it?.status == 1) {
//                id = it.data?.id.toString()
//                names = it.data?.name.toString()
//                charges = it.data?.callingCharg.toString()+"₹/min"
//                times = it.data?.time.toString()
//                profiles = it.data?.profile.toString()
//                user_name = it.data?.user_name.toString()
//                caller_id =it.data?.unique_id.toString()
//                WaitList()
//                WaitingDialog(requireContext())
//            } else {
////                toast(it.message.toString())
//                bottomdialog.dismiss()
//                dialog?.dismiss()
//            }
//        }

        dialogs.setCancelable(false)
        dialogs.show()
        val window = dialogs.window
        window?.setLayout(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayoutCompat.LayoutParams.WRAP_CONTENT
        )
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }
    fun LottieAnimationView.initLoader(isLoading: Boolean) {
        if (isLoading) {
            playAnimation()

            visibility = View.VISIBLE
        } else {
            pauseAnimation()
            animation?.reset()

            visibility = View.GONE
        }
    }

    fun StartChatDialog(context: Context) {
        StartChatdialog.setContentView(R.layout.start_chatdialog)
//        val lottie = dialog.findViewById<LottieAnimationView>(R.id.personal_edit_info_loader)
//        lottie.initLoader(true)
        playSound()
        val lp = WindowManager.LayoutParams()
        lp.copyFrom(StartChatdialog.getWindow()?.getAttributes())
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.MATCH_PARENT
        StartChatdialog.show()
        StartChatdialog.getWindow()?.setAttributes(lp)
        StartChatdialog.setCancelable(true)
        shahbaz = true
//        val window = dialog.window
//        window?.setLayout(
//            LinearLayout.LayoutParams.MATCH_PARENT,
//            LinearLayoutCompat.LayoutParams.WRAP_CONTENT
//        )
//        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val circleimagechat = StartChatdialog.findViewById<CircleImageView>(R.id.circleimagechat)
        val btnstartchat = StartChatdialog.findViewById<Button>(R.id.btnstartchat)
        val namechat = StartChatdialog.findViewById<TextView>(R.id.namechat)
        val rejectrequest = StartChatdialog.findViewById<TextView>(R.id.rejectrequest)
        namechat.text = astro_name
        Glide.with(context).load(astroProfile).into(circleimagechat)
        btnstartchat.setOnClickListener {
            StartChatdialog.dismiss()
            viewModel.requests_wait_delete(
                "Bearer "+userPref.getToken().toString()
            )
            var intent = Intent(context, ChatActivity::class.java)
                .putExtra("type","1")
                .putExtra("astroid",astroid.toString())
                .putExtra("astroname",astro_name.toString())
                .putExtra("caller_id",caller_id.toString())
            context.startActivity(intent)
        }

        rejectrequest.setOnClickListener {
            viewModel.chat_cancel_by_user(
                "Bearer "+userPref.getToken().toString(),id
            )
        }



    }

    override fun id(id: String) {
        expertiesdata = id

        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.Chat(
                "Bearer "+userPref.getToken().toString(),expertiesdata,""
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }
    }
}