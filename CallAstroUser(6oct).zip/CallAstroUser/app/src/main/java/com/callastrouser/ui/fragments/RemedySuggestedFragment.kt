package com.callastrouser.ui.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.SuggestedAdapter
import com.callastrouser.databinding.FragmentRemedySuggestedBinding
import com.callastrouser.model.RemedySuggestedData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.RemedyViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class RemedySuggestedFragment : BaseFragment() {
    lateinit var binding: FragmentRemedySuggestedBinding
    lateinit var adapter: SuggestedAdapter
    private val viewModel: RemedyViewModel by viewModels()
    var Listdata: ArrayList<RemedySuggestedData> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentRemedySuggestedBinding.inflate(inflater,container,false)
        binding.swipeRefreshlayout.setOnRefreshListener {
            if (CommonUtils.isInternetAvailable(requireContext())) {
                viewModel.RemedySuggested(
                    "Bearer "+userPref.getToken().toString()
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast("Please check internet connection.")
            }


            binding.swipeRefreshlayout.isRefreshing = false
        }
        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.RemedySuggested(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.remedysuggestedResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                toast(it.message.toString())
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = SuggestedAdapter(requireContext(), Listdata)
                binding.rvAstrologers.adapter =adapter
            } else {
                toast(it.message.toString())
            }
        }

        return binding.rvAstrologers
    }

}