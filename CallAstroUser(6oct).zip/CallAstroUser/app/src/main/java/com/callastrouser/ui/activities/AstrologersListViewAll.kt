package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.LinearLayout
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.AstrologersListViewaAll
import com.callastrouser.adapter.AstrologerviewallAdapter
import com.callastrouser.databinding.ActivityAstrologersListViewAllBinding
import com.callastrouser.model.AstrologersListViewAllResponseData
import com.callastrouser.model.ChatFragmentResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.HomeViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AstrologersListViewAll : BaseActivity(), AstrologersListViewaAll {
    lateinit var binding: ActivityAstrologersListViewAllBinding
    lateinit var adapter: AstrologerviewallAdapter
    var Listdata: ArrayList<AstrologersListViewAllResponseData> = ArrayList()
    private val viewModel: HomeViewModel by viewModels()
    var scpflag: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_astrologers_list_view_all)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_astrologers_list_view_all)

        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Talk with Astrologers"
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        if (CommonUtils.isInternetAvailable(this@AstrologersListViewAll)) {
            viewModel.strologers_list(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            toast(this,"Please check internet connection.")
        }


        viewModel.astrologerviewallResponse.observe(this){
            if (it.status == 1){
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = AstrologerviewallAdapter(this,Listdata,this)
                binding.rvAstrologers.adapter = adapter
            }
        }
        binding.tvSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(text: Editable?) {
                filterData(text.toString(), scpflag)
            }

        })

    }
    private fun filterData(searchText: String, scpflag: String) {
        var filteredStateList: java.util.ArrayList<AstrologersListViewAllResponseData> = java.util.ArrayList()

        for (item in Listdata) {
            try {
                if (item.name!!.toLowerCase().contains(searchText.toLowerCase())) {
                    filteredStateList.add(item)
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }


        try {

            adapter?.filterList(filteredStateList)

        } catch (e: NullPointerException) {
            e.printStackTrace()
        }
    }
    override fun astrologer(layout: LinearLayout, id: String, name: String) {
        layout.setOnClickListener {
            var intent = Intent(this@AstrologersListViewAll, AstrologerProfileActivity::class.java)
            intent.putExtra("id",id)
            intent.putExtra("name",name)
            startActivity(intent)
        }
    }
}