package com.callastrouser.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.callastrouser.R
import com.callastrouser.adapter.ViewPagerAdapter
import com.callastrouser.databinding.FragmentHomeHistoryBinding
import com.google.android.material.tabs.TabLayout

class HomeHistoryFragment : Fragment() {
    lateinit var viewpagerAdapter: ViewPagerAdapter
    lateinit var binding : FragmentHomeHistoryBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment'
        binding = FragmentHomeHistoryBinding.inflate(inflater,container,false)

        setTab()

        return binding.root
    }
    private fun setTab() {
        viewpagerAdapter = ViewPagerAdapter(fragmentManager!!)
        binding.vpViewPagerActivity.adapter = viewpagerAdapter
        binding.tabLayout.setupWithViewPager(binding.vpViewPagerActivity)
        binding.tabLayout.setTabGravity(TabLayout.GRAVITY_CENTER);
        binding.tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);
        val tabs = binding.tabLayout.getChildAt(0) as ViewGroup
        for (i in 0 until tabs.childCount ) {
            val tab = tabs.getChildAt(i)
            val layoutParams = tab.layoutParams as LinearLayout.LayoutParams
            layoutParams.weight = 0f
            layoutParams.marginEnd = 10
            layoutParams.marginStart = 10
            layoutParams.width = 250
            tab.layoutParams = layoutParams
            binding.tabLayout.requestLayout()
        }
        binding.tabLayout.getChildAt(0)
    }
}