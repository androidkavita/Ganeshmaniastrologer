package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowChooseAddressBinding
import com.callastrouser.model.AddressListResponseData

class AddressListAdapter (val context : Context, var data: ArrayList<AddressListResponseData>, var address: Address,
var addressadd: AddressAdd,
var addressedit:EditAddress ,
) :
    RecyclerView.Adapter<AddressListAdapter.ViewHolder>() {
    private var selectedItemPosition: Int = 0
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowChooseAddressBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AddressListAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_choose_address, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: AddressListAdapter.ViewHolder, @SuppressLint("RecyclerView") position: Int) {
        val List = data[position]
        holder.binding.tvName.text = List.fullName
        holder.binding.tvPhonenumber.text = List.phoneNo.toString()
        holder.binding.tvAddress.text = "List.${List.houseNo.toString()} ${List.area.toString()}"


        holder.binding.lladdress.setOnClickListener {

            selectedItemPosition = position
            notifyDataSetChanged()
        }
        if(selectedItemPosition == position){
            holder.binding.lladdress.setBackgroundResource(R.drawable.background_lightyellow_rect)
            addressadd.addressid(List.id.toString())
        } else{
            holder.binding.lladdress.setBackgroundResource(R.drawable.background_lightwhite_rect)
        }

        if (List.addressType!!.equals(1)){
            holder.binding.tvLocationType.text = "Home Address"
            holder.binding.ivhome.setImageResource(R.drawable.ic_home_address)
        }else{
            holder.binding.tvLocationType.text = "Office Address"
            holder.binding.ivhome.setImageResource(R.drawable.color_bag)
        }


        holder.binding.ivDelete.setOnClickListener {
            address.addressid(List.id.toString(),holder.binding.ivDelete)
        }

        holder.binding.ivEdit.setOnClickListener {
            addressedit.editaddressid(List.id.toString(),holder.binding.ivEdit)
        }

    }
    override fun getItemCount(): Int {
        return data.size
    }
    interface Address {
        fun addressid(addressid :String,cross:ImageView)
    }
    interface EditAddress {
        fun editaddressid(addressid :String,edit:ImageView)
    }
    interface AddressAdd {
        fun addressid(addressid :String)
    }
}
