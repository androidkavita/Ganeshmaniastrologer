package com.callastrouser.model

import com.google.gson.annotations.SerializedName

//data class MyCartResponse(
//    @SerializedName("status"  ) var status  : Int?    = null,
//    @SerializedName("message" ) var message : String? = null,
//    @SerializedName("data"    ) var data    : MyCartData?   = MyCartData()
//)
//data class MyCartData(
//    @SerializedName("product"         ) var product        : MyCartProduct? = MyCartProduct(),
//    @SerializedName("product_price"   ) var productPrice   : String?  = null,
//    @SerializedName("shipping_chard"  ) var shippingChard  : Int?     = null,
//    @SerializedName("coupon_discount" ) var couponDiscount : Int?     = null,
//    @SerializedName("tax" ) var tax : Int?     = null,
//    @SerializedName("grand_total"     ) var grandTotal     : String?  = null
//)
//data class MyCartProduct (
//    @SerializedName("id"          ) var id          : Int?    = null,
//    @SerializedName("name"        ) var name        : String? = null,
//    @SerializedName("description" ) var description : String? = null,
//    @SerializedName("item_price"       ) var price       : String? = null,
//    @SerializedName("item_price"       ) var price       : String? = null,
//    @SerializedName("hsn_code"    ) var hsnCode     : String? = null,
//    @SerializedName("main_image"  ) var mainImage   : String? = null
//
//)
data class MyCartResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : MyCartResponseData?   = MyCartResponseData()
)
data class MyCartResponseData(

    @SerializedName("product"         ) var product        : MyCartProduct? = MyCartProduct(),
    @SerializedName("product_price"   ) var productPrice   : Int?     = null,
    @SerializedName("shipping_chard"  ) var shippingChard  : Int?     = null,
    @SerializedName("tax"             ) var tax            : Int?     = null,
    @SerializedName("coupon_discount" ) var couponDiscount : Int?     = null,
    @SerializedName("grand_total"     ) var grandTotal     : Int?     = null

)
data class MyCartProduct (
    @SerializedName("id"               ) var id             : Int?    = null,
    @SerializedName("user_id"          ) var userId         : Int?    = null,
    @SerializedName("product_id"       ) var productId      : Int?    = null,
    @SerializedName("main_image"       ) var mainImage      : String? = null,
    @SerializedName("name"             ) var name           : String? = null,
    @SerializedName("hsn_code"         ) var hsnCode        : String? = null,
    @SerializedName("description"      ) var description    : String? = null,
    @SerializedName("qty"              ) var qty            : Int?    = null,
    @SerializedName("item_price"       ) var itemPrice      : String? = null,
    @SerializedName("total_item_price" ) var totalItemPrice : String? = null,
    @SerializedName("created_at"       ) var createdAt      : String? = null,
    @SerializedName("updated_at"       ) var updatedAt      : String? = null
)