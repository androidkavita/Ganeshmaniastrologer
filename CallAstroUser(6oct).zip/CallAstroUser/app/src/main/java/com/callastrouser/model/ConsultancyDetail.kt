package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ConsultancyDetail(

    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : ConsultancyDetailData?   = ConsultancyDetailData()
)
data class ConsultancyDetailData(
    @SerializedName("id"                    ) var id                  : Int?              = null,
    @SerializedName("name"                  ) var name                : String?           = null,
    @SerializedName("profile"               ) var profile             : String?           = null,
    @SerializedName("booking_id"            ) var bookingId           : String?           = null,
    @SerializedName("cost"            ) var cost           : String?           = null,
    @SerializedName("duration"            ) var duration           : String?           = null,
    @SerializedName("astro_name"            ) var astro_name           : String?           = null,
    @SerializedName("is_live"               ) var isLive              : Int?              = null,
    @SerializedName("last_online_time"      ) var lastOnlineTime      : String?           = null,
    @SerializedName("booking_date"          ) var bookingDate         : String?           = null,
    @SerializedName("booking_status"        ) var bookingStatus       : String?           = null,
    @SerializedName("booking_complete_date" ) var bookingCompleteDate : String?           = null,
    @SerializedName("experience"            ) var experience          : String?           = null,
    @SerializedName("price"            ) var price          : String?           = null,
    @SerializedName("expertise"             ) var expertise           : String? = null,
    @SerializedName("language"              ) var language            : String? = null
)