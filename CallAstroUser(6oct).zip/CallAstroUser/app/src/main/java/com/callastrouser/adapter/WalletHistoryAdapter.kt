package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowWalletHistoryFragmentBinding
import com.callastrouser.model.TransactionHistoryData

class WalletHistoryAdapter (val context : Context, var data: ArrayList<TransactionHistoryData>):
    RecyclerView.Adapter<WalletHistoryAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowWalletHistoryFragmentBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WalletHistoryAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_wallet_history_fragment, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: WalletHistoryAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.content.toString()
//        holder.binding.amount.text = List.amount.toString()
        holder.binding.date.text = List.createdAt
        holder.binding.time.text = List.createdTime.toString()
        if (List.type == 1){
            holder.binding.amount.text = "₹ ${List.amount}"
            holder.binding.amount.setTextColor(Color.parseColor("#28B502"))
        }else{
            holder.binding.amount.text = "₹ ${List.amount}"
            holder.binding.amount.setTextColor(Color.parseColor("#a80017"))
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }
}