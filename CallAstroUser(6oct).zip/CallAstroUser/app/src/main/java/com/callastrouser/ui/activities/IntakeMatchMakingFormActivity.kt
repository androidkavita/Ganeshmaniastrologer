package com.callastrouser.ui.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.ViewPagerIntakeMatchMakingAdapter
import com.callastrouser.databinding.ActivityIntakeMatchMakingFormBinding
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class IntakeMatchMakingFormActivity : BaseActivity() {

    private lateinit var binding : ActivityIntakeMatchMakingFormBinding
    private var intakeMatchMakingAdapter: ViewPagerIntakeMatchMakingAdapter?= null
    lateinit var astro_id:String
    lateinit var request_type:String
    lateinit var fix:String
    lateinit var sessiontype:String
    lateinit var minimumbalence:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_intake_match_making_form)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        if (intent != null){
            astro_id = intent.getStringExtra("id").toString()
            request_type = intent.getStringExtra("request_type").toString()
            fix = intent.getStringExtra("fix").toString()
            sessiontype = intent.getStringExtra("sessiontype").toString()
            minimumbalence = intent.getStringExtra("minimumbalence").toString()
        }

        binding.header.tvHeadName.text = "Please provide your details."
        binding.header.backArrow.setOnClickListener { finish() }
        setTab()

    }
    private fun setTab() {
        intakeMatchMakingAdapter = ViewPagerIntakeMatchMakingAdapter(supportFragmentManager,astro_id,request_type,fix,sessiontype,minimumbalence)
        binding.viewPager.adapter = intakeMatchMakingAdapter
        binding.tabLayout.setupWithViewPager(binding.viewPager)
        binding.tabLayout.getChildAt(0)

    }
}