package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.CancelReseonAdapter
import com.callastrouser.adapter.CheckedReason
import com.callastrouser.databinding.ActivityCancelOrderBinding
import com.callastrouser.model.CancelReasonResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.OrderDetailsViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CancelOrderActivity : BaseActivity(), CheckedReason {
    lateinit var binding: ActivityCancelOrderBinding
    lateinit var adapter: CancelReseonAdapter
    lateinit var productid:String
    lateinit var orderid:String
    private val viewModel: OrderDetailsViewModel by viewModels()
    var List :ArrayList<CancelReasonResponseData> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cancel_order)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_cancel_order)
        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Cancel Order"

        if (intent!=null){
            productid = intent.getStringExtra("id").toString()
            orderid = intent.getStringExtra("order_id").toString()
        }
        binding.btnCancel.setOnClickListener {
            finish()
        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.reason_cancel_list(
                "Bearer "+userPref.getToken().toString())
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }


        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.cancelReasonResponse.observe(this){
            if (it.status == 1){
                List.clear()
                List.addAll(it.data)
                adapter = CancelReseonAdapter(this,List,this)
                binding.rvReasons.adapter = adapter
            }else{
                snackbar(it.message.toString())
            }
        }
        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                var intent = Intent(this@CancelOrderActivity, EcommerceProductsActivity::class.java)
                    .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                toast(this@CancelOrderActivity,it.message.toString())
            }else{
                snackbar("You had already cancelled this order.")
            }
        }

    }

    override fun Reason(id:String, Reason: String) {

        binding.btnSubmit.setOnClickListener {
            if (CommonUtils.isInternetAvailable(this)) {
                viewModel.cancel_order(
                    "Bearer "+userPref.getToken().toString(),
                    orderid,
                    productid,
                    id,
                    binding.etReason.text.toString()
                )
            } else {
                toast(this,"Please check internet connection.")
            }


        }



    }
}