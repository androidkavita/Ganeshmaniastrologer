package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.callastrouser.R
import com.callastrouser.databinding.ActivityViewMyProfileBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.ProfileViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ViewMyProfile : BaseActivity() {
    lateinit var binding: ActivityViewMyProfileBinding
    private val viewModel: ProfileViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_my_profile)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_view_my_profile)

        binding.backArrow.setOnClickListener {
            finish()
        }
        binding.llEditProfile.setOnClickListener {
            var intent = Intent(this@ViewMyProfile,EditProfile::class.java)
            startActivity(intent)
        }

        binding.myreviews.setOnClickListener {
            var intent = Intent(this@ViewMyProfile,MyReview::class.java)
            startActivity(intent)
        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.ViewProfile(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }


        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.viewProfileResponse.observe(this) {
            if (it?.status == 1) {
                binding.tvFullName.text = it.data?.name.toString()
//                binding.tvGender.text = it.data?.gender.toString()
                binding.tvPhone.text = it.data?.mobileNo.toString()
                binding.tvEmailid.text = it.data?.email.toString()
                binding.tvDateOfBirth.text = it.data?.dob.toString()
                binding.tvTimeOfBirth.text = it.data?.birthTime.toString()
                binding.tvPlaceOfBirth.text = it.data?.birthPlace.toString()
                Glide.with(this@ViewMyProfile).load(it.data?.profile).apply(RequestOptions.placeholderOf(droidninja.filepicker.R.drawable.image_placeholder)).into(binding.ivPict)
                userPref.setName(it.data?.name!!)
                userPref.setEmail(it.data!!.email)
                userPref.setProfile(it.data!!.profile.toString())
                if (it.data?.gender.toString() == "1"){
                    binding.tvGender.setText("Male")
                }else if(it.data?.gender.toString() == "2"){
                    binding.tvGender.setText("Female")
                }else {
                    binding.tvGender.setText("Other")
                }
            }else{
                snackbar(it.message.toString())
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.ViewProfile(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

    }
}