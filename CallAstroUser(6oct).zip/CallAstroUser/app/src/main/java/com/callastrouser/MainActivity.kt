package com.callastrouser

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.databinding.DataBindingUtil
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.callastrouser.adapter.MenuListAdapter
import com.callastrouser.databinding.ActivityMainBinding
import com.callastrouser.databinding.DialogLogoutBinding
import com.callastrouser.ui.activities.AboutUs
import com.callastrouser.ui.activities.AudioCallActivity
import com.callastrouser.ui.activities.ConsultancyOrdersActivity
import com.callastrouser.ui.activities.Customer_Support
import com.callastrouser.ui.activities.EcommerceProductsActivity
import com.callastrouser.ui.activities.FAQ
import com.callastrouser.ui.activities.GetDetailsReports
import com.callastrouser.ui.activities.LiveAstrologersList
import com.callastrouser.ui.activities.LoginActivity
import com.callastrouser.ui.activities.MyCartListCheckout
import com.callastrouser.ui.activities.Notification
import com.callastrouser.ui.activities.Remedy
import com.callastrouser.ui.activities.ViewMyProfile
import com.callastrouser.ui.activities.WalletActivity
import com.callastrouser.ui.fragments.*
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.toast
import com.callastrouser.viewModel.WalletViewModel
import com.google.android.gms.wallet.Wallet
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.navigation.NavigationView
import com.maxtra.callastro.baseClass.BaseActivity
import com.maxtra.callastro.prefs.UserPref
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : BaseActivity() ,  NavigationView.OnNavigationItemSelectedListener,
    BottomNavigationView.OnNavigationItemSelectedListener {
    private lateinit var binding : ActivityMainBinding
//    private val viewModel: HomeViewModel by viewModels()
    // private var menuList: ArrayList<DashboardMenuModel>?  = null
    lateinit var mfragment: Fragment
    private var menuListAdapter: MenuListAdapter? =  null
    lateinit var profilepic: ImageView
    lateinit     var tvUserName: TextView
    lateinit      var tv_email: TextView
    lateinit var bottomSheetLogout: BottomSheetDialog
    private val PERMISSION_REQ_ID = 22
    private val viewModel : WalletViewModel by viewModels()

    private val REQUESTED_PERMISSIONS= arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA,
        Manifest.permission.READ_PHONE_STATE
    )
    val handlerStatusCheck = Handler(Looper.getMainLooper())
    var runnableStatusCheck: Runnable? = null
    var home:Int = 0
    private var exit: Boolean = false
    private fun checkSelfPermission(): Boolean {
        return !(ContextCompat.checkSelfPermission(
            this,
            REQUESTED_PERMISSIONS[0]
        ) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    this,
                    REQUESTED_PERMISSIONS[1]
                ) != PackageManager.PERMISSION_GRANTED)
    }
    override fun onStart() {
        super.onStart()
        //binding.bottomNav.menu.clear()
        setNavigationData()
        // setNavigationBar()
        // initializeUsersBnv()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.bottomNavigationView.setOnNavigationItemSelectedListener(this);
        binding.bottomNavigationView.setSelectedItemId(R.id.navigation_home);
        replaceFragment(HomeFragment())
        userPref= UserPref(this)
        mfragment = HomeFragment()
        if (!checkSelfPermission()) {
            ActivityCompat.requestPermissions(this, REQUESTED_PERMISSIONS, PERMISSION_REQ_ID);
        }

        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.wallet(
                "Bearer "+userPref.getToken().toString()
            )

            viewModel.ViewProfile(
                "Bearer "+userPref.getToken().toString()
            )

            //        handlerStatusCheck.postDelayed(Runnable {
//            handlerStatusCheck.postDelayed(runnableStatusCheck!!, 5000)
            viewModel.active_home(
                "Bearer "+userPref.getToken().toString()
            )
//        }.also { runnableStatusCheck = it }, 5000)
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

        viewModel.walletResponse.observe(this){
            if (it.status == 1){
//                binding.name.text = it.data?.name.toString()
                binding.drawerToolbar.wallet.text = "₹"+it.data?.wallet.toString()
            }
        }

        binding.drawerToolbar.walletLL.setOnClickListener {
            startActivity(Intent(this@MainActivity,WalletActivity::class.java))
        }




//        viewModel.progressBarStatus.observe(this) {
//            if (it) {
//                showProgressDialog()
//            } else {
//                hideProgressDialog()
//            }
//        }




        binding.drawerToolbar.ivHeaderpic.setOnClickListener {
            startActivity(Intent(this@MainActivity, ViewMyProfile::class.java))
        }

        viewModel.activeHomeResponse.observe(this){
            if (it.status == 1){
                if (it.data?.home == 0){
                    home = 0
//                    if (home != it.data?.home)
                    binding.bottomNavigationView.setSelectedItemId(R.id.navigation_home);
                    replaceFragment(HomeFragment())
                }else if (it.data?.home == 1){
                    home = it.data?.home!!
                    binding.bottomNavigationView.setSelectedItemId(R.id.navigation_chat);
                    replaceFragment(Chat())
                }else if (it.data?.home == 2){
                    home = it.data?.home!!
                    binding.bottomNavigationView.setSelectedItemId(R.id.navigation_call);
                    replaceFragment(Call())

                }
//                binding.name.text = it.data?.name.toString()
//                binding.drawerToolbar.wallet.text = "₹"+it.data?.wallet.toString()
            }
        }

        viewModel.notificationcountresponseResponse.observe(this){
            if (it.status == 1){
//                if (it.data!!.equals(0)){
//                    countlayout.visibility = View.GONE
//                }else{
//                    countlayout.visibility = View.GONE
                    userPref.setNotificationCount(it.data.toString())
//                }

            }
        }

        viewModel.viewProfileResponse.observe(this) {
            if (it?.status == 1) {
                userPref.setName(it.data?.name!!)
                userPref.setEmail(it.data!!.email)
                userPref.setProfile(it.data!!.profile.toString())
                Glide.with(this).load(userPref.getProfile()).apply(RequestOptions.placeholderOf(R.drawable.user_image_place_holder)).into(binding.drawerToolbar.ivHeaderpic)

            }else{
                snackbar(it.message.toString())
            }
        }

//        WaitingDialog(this)
        //  menuList = ArrayList<DashboardMenuModel>()

        /*   binding.drawerLayout.addDrawerListener(object : DrawerLayout.DrawerListener {
               override fun onDrawerSlide(drawerView: View, slideOffset: Float) {

               }
               override fun onDrawerOpened(drawerView: View) {

                   //setNavigationData();
               }
               override fun onDrawerClosed(drawerView: View) {

               }
               override fun onDrawerStateChanged(newState: Int) {

               }
           })
           binding.drawerLayout.addDrawerListener(object : DrawerLayout.DrawerListener {
               override fun onDrawerSlide(drawerView: View, slideOffset: Float) {

               }
               override fun onDrawerOpened(drawerView: View) {

                   //setNavigationData();
               }
               override fun onDrawerClosed(drawerView: View) {

               }
               override fun onDrawerStateChanged(newState: Int) {

               }
           })*/

        Glide.with(this).load(userPref.getProfile()).apply(RequestOptions.placeholderOf(R.drawable.user_image_place_holder)).into(binding.drawerToolbar.ivHeaderpic)
        binding.drawerToolbar.ivMenu.setOnClickListener {
            // open drawer here
            binding.drawerLayout.openDrawer(GravityCompat.START)
            Glide.with(this).load(userPref.getProfile()).apply(RequestOptions.placeholderOf(R.drawable.user_image_place_holder)).into(profilepic)
            viewModel.notification_count(
                "Bearer "+userPref.getToken().toString()
            )
        }
        //  setNavigationBar()
        //  prepareNavMenuList()
        //   navMenuClickListener()

        val navView: NavigationView = binding.nvView
        val header: View = navView.getHeaderView(0)
        profilepic =header.findViewById(R.id.imgUser)
        tv_email= header.findViewById(R.id.tv_email)
        tvUserName= header.findViewById(R.id.tvUserName)
        tvUserName.text = userPref.getName().toString()
        tv_email.text = userPref.getEmail().toString()
        Glide.with(this).load(userPref.getProfile()).apply(RequestOptions.placeholderOf(R.drawable.user_image_place_holder)).into(profilepic)

        var nav_myprofile: RelativeLayout = header.findViewById(R.id.rl_myprofile)
        var nav_myorder: RelativeLayout = header.findViewById(R.id.rl_myorders)
        var nav_wallet: RelativeLayout = header.findViewById(R.id.rl_wallet)
        var nav_cart: RelativeLayout = header.findViewById(R.id.rl_cart)
        var nav_customersupport: RelativeLayout = header.findViewById(R.id.rl_customersupport)
        var nav_aboutus: RelativeLayout = header.findViewById(R.id.rl_aboutus)
        var nav_faq: RelativeLayout = header.findViewById(R.id.rl_faq)
        var nav_getreport: RelativeLayout = header.findViewById(R.id.rl_getreport)
        var nav_rateapp: RelativeLayout = header.findViewById(R.id.rl_rateapp)
        var nav_shareapp: RelativeLayout = header.findViewById(R.id.rl_shareapp)
        var nav_notification: RelativeLayout = header.findViewById(R.id.rl_notification)
        var nav_notification_count: TextView = header.findViewById(R.id.count)
        var countlayout: RelativeLayout = header.findViewById(R.id.count_layout)
        var nav_remedy: RelativeLayout = header.findViewById(R.id.rl_remedy)
        var nav_logout: RelativeLayout = header.findViewById(R.id.rl_logout)
//        var nav_requestreport: RelativeLayout = header.findViewById(R.id.rl_request_report)

        var iv_arrowup: ImageView = header.findViewById(R.id.iv_arrowup)
        var iv_arrowdown: ImageView = header.findViewById(R.id.iv_arrowdown)
        var ll_Order: LinearLayout = header.findViewById(R.id.ll_Order)

        var rl_ecommerce: RelativeLayout = header.findViewById(R.id.rl_ecommerce)
        var rl_consultancy: RelativeLayout = header.findViewById(R.id.rl_consultancy)



        var flag = false
//        nav_requestreport.setOnClickListener {
//            binding.drawerLayout.closeDrawer(GravityCompat.START)
//            var intent = Intent(this@MainActivity,RequestforReport::class.java)
//            startActivity(intent)
//        }
        nav_cart.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, MyCartListCheckout::class.java)
            startActivity(intent)
        }
        nav_wallet.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, WalletActivity::class.java)
            startActivity(intent)
        }
        nav_remedy.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, Remedy::class.java)
            startActivity(intent)
        }
        nav_getreport.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, GetDetailsReports::class.java)
            startActivity(intent)
        }
        nav_myprofile.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, ViewMyProfile::class.java)
            startActivity(intent)
        }
        nav_faq.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, FAQ::class.java)
            startActivity(intent)
        }
        nav_notification.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, Notification::class.java)
            startActivity(intent)
        }
        nav_aboutus.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, AboutUs::class.java)
            startActivity(intent)
        }
        nav_customersupport.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, Customer_Support::class.java)
            startActivity(intent)
        }


        nav_myorder.setOnClickListener {
            if (flag == false){
                iv_arrowdown.visibility = View.VISIBLE
                iv_arrowup.visibility = View.GONE
                ll_Order.visibility = View.VISIBLE
                flag = true
            }else{
                iv_arrowdown.visibility = View.GONE
                iv_arrowup.visibility = View.VISIBLE
                ll_Order.visibility = View.GONE
                flag = false
            }
        }



        nav_logout.setOnClickListener {
            binding.drawerLayout.closeDrawer(GravityCompat.START);
            logout()
        }

        rl_ecommerce.setOnClickListener{
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, EcommerceProductsActivity::class.java)
            startActivity(intent)

        }

        rl_consultancy.setOnClickListener{
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            var intent = Intent(this@MainActivity, ConsultancyOrdersActivity::class.java)
            startActivity(intent)
        }

//        viewModel.notificationcountresponseResponse.observe(this){
//            if (it.status == 1){
                if (userPref.getNotificationCount() == "0"){
                    countlayout.visibility = View.GONE
                }else{
                    countlayout.visibility = View.GONE
                    nav_notification_count.setText(userPref.getNotificationCount())


                }

//            }
//        }
        nav_notification_count.setText(userPref.getNotificationCount())

        Glide.with(this@MainActivity).load(userPref.getProfile()).apply(RequestOptions.placeholderOf(R.drawable.user_image_place_holder)).into(binding.drawerToolbar.ivHeaderpic)

//        printProcessInfo()
    }

    override fun onResume() {
        super.onResume()
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.wallet(
                "Bearer "+userPref.getToken().toString()
            )

            viewModel.ViewProfile(
                "Bearer "+userPref.getToken().toString()
            )
            viewModel.notification_count(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

    }
    private fun logout() {
        val cDialog = Dialog(this)
        val bindingDialog: DialogLogoutBinding = DataBindingUtil.inflate(
            LayoutInflater.from(this),
            R.layout.dialog_logout,
            null,
            false
        )
        cDialog.setContentView(bindingDialog.root)
        cDialog.setCancelable(false)
        cDialog.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        cDialog.show()
        bindingDialog.btnCancel.setOnClickListener {
            cDialog.dismiss()
        }
        bindingDialog.btnLogout.setOnClickListener {
            userPref.clearPref()
            startActivity(Intent(this, LoginActivity::class.java))
            finishAffinity()
            cDialog.dismiss()
        }
    }





    @SuppressLint("SetTextI18n")
    private fun setNavigationData() {
        //   binding.header.tvUserName.text = userPref.getName()
        //   binding.header.tvEmail.text = userPref.getEmail()

        /*if (!userPref.getUserProfileImage().isNullOrBlank()) {
            Glide.with(this).load(Uri.parse(userPref.getUserProfileImage()))
                .apply(RequestOptions.placeholderOf(droidninja.filepicker.R.drawable.image_placeholder))
                .apply(RequestOptions.errorOf(R.drawable.image_placeholder))
                .into(binding.header.imgUser)
        }*/
    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.navigation_home -> {
                supportFragmentManager.beginTransaction().replace(R.id.flContent, HomeFragment())
                    .commit()
                return true
            }
            R.id.navigation_chat -> {
                supportFragmentManager.beginTransaction().replace(R.id.flContent, Chat())
                    .commit()
                return true
            }
            R.id.navigation_call -> {
                supportFragmentManager.beginTransaction().replace(R.id.flContent, Call())
                    .commit()
                return true
            }
            R.id.navigation_golive -> {
                supportFragmentManager.beginTransaction().replace(R.id.flContent, LiveAstrologersList())
                    .commit()
                return true
            }
            R.id.navigation_notification -> {
                supportFragmentManager.beginTransaction().replace(R.id.flContent, HomeHistoryFragment())
                    .commit()
                return true
            }

        }
        return true
    }
    override fun onBackPressed() {
        if (binding!!.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START)
            binding!!.bottomNavigationView.menu.getItem(0).isChecked = true
            mfragment = HomeFragment()
            CommonUtils.setFragment(mfragment, false, this, R.id.flContent)
        } else {
            if (mfragment is HomeFragment) {
                if (exit) {
                    super.onBackPressed()
                    finishAffinity()
                    //finish() // finish activity
                } else {
                    Handler().postDelayed({
                        replaceFragment(HomeFragment())
                        binding.bottomNavigationView.setSelectedItemId(R.id.navigation_home);
                        toast(getString(R.string.pressbackagain))
                        exit = true

                    }, 3 * 100)
                }
            }
        }
        }
    /* private fun setNavigationBar() {
         binding.nvView.setNavigationItemSelectedListener(this)

         val toggle = ActionBarDrawerToggle(
             this,
             binding.drawerLayout,
             R.string.navigation_drawer_open,
             R.string.navigation_drawer_close
         )

         binding.drawerLayout.addDrawerListener(toggle)
         toggle.syncState()
        // prepareNavMenuList()
        // navMenuClickListener()

         binding.drawerToolbar.toolbar.setNavigationOnClickListener {
             if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                 binding.drawerLayout.closeDrawer(GravityCompat.START)
             } else {
                 binding.drawerLayout.openDrawer(GravityCompat.START)
             }
         }

         binding.drawerLayout.addDrawerListener(object : DrawerLayout.DrawerListener {
             override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
             }

             override fun onDrawerOpened(drawerView: View) {
             }

             override fun onDrawerClosed(drawerView: View) {

             }

             override fun onDrawerStateChanged(newState: Int) {

             }
         })
     }*/
    /* private fun prepareNavMenuList() {

         menuList!!.clear()
         menuList!!.add(DashboardMenuModel(this.getString(R.string.myprofile), R.drawable.ic_profile))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.myorders), R.drawable.ic_myorders))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.wallet), droidninja.filepicker.R.drawable.ic_camera))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.customersupport), droidninja.filepicker.R.drawable.ic_camera))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.aboutus), droidninja.filepicker.R.drawable.ic_camera))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.faq), droidninja.filepicker.R.drawable.ic_camera))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.rateapp), droidninja.filepicker.R.drawable.ic_camera))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.shareapp), droidninja.filepicker.R.drawable.ic_camera))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.notification), droidninja.filepicker.R.drawable.ic_camera))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.remedy), droidninja.filepicker.R.drawable.ic_camera))
         menuList!!.add(DashboardMenuModel(this.getString(R.string.logout), droidninja.filepicker.R.drawable.ic_camera))

         menuListAdapter = MenuListAdapter(this, menuList!!)
         binding.listVideMenu.adapter = menuListAdapter
     }*/

    /*  private fun navMenuClickListener() {

          binding.listVideMenu.onItemClickListener =
              AdapterView.OnItemClickListener { parent, view, position, id ->
                  when (position) {
                      0 -> {
                          //val intent = Intent(this, MyProfileActivity::class.java)
                          //startActivity(intent)
                      }
                      1 -> {
                         // val intent = Intent(this, MySubscriptionOffer::class.java)
                         // startActivity(intent)
                      }
                      2 -> {
                         // val intent = Intent(this, MyPaymentsActivity::class.java)
                         // startActivity(intent)
                      }
                      3 -> {
                         // val intent = Intent(this, SettingActivity::class.java)
                         // startActivity(intent)
                      }
                      4 -> {
                         // val intent = Intent(this, NotificationActivity::class.java)
                         // startActivity(intent)
                      }
                      5 -> {
                          //val intent = Intent(this, Aboutus::class.java)
                         // startActivity(intent)
                      }
                      6 -> {
                         // val intent = Intent(this, WhyUs::class.java)
                         // startActivity(intent)
                      }
                      7 -> {
                         // val intent = Intent(this, Contactus::class.java)
                        //  startActivity(intent)
                      }
                      8 -> {
                         // logoutDialog()
                      }
                  }
                  closeDrawer()
              }
      }*/
    private fun closeDrawer() {
        val drawer: DrawerLayout = findViewById(R.id.drawer_layout)
        drawer.closeDrawer(GravityCompat.START)
    }

    private fun setupDrawerToggle(): ActionBarDrawerToggle? {
        return ActionBarDrawerToggle(this, binding.drawerLayout,
            R.string.drawer_open, R.string.drawer_close
        )
    }




    /* private fun logoutDialog() {
         val dialogBinding = LayoutInflater
             .from(this).inflate(R.layout.dialog_logout, null)
         bottomSheetLogout = BottomSheetDialog(this)
         bottomSheetLogout.setContentView(dialogBinding)

         bottomSheetLogout.setOnShowListener { dia ->
             val bottomSheetDialog = dia as BottomSheetDialog
             val bottomSheetInternal: FrameLayout =
                 bottomSheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet)!!
             bottomSheetInternal.setBackgroundResource(R.drawable.ic_launcher_background)
         }
         bottomSheetLogout.setCancelable(true)

         val btnclose: Button = bottomSheetLogout.findViewById(R.id.btnCancel)!!
         val btnlogout: Button = bottomSheetLogout.findViewById(R.id.btnLogout)!!



         btnclose.setOnClickListener {
             bottomSheetLogout.dismiss()
         }
         btnlogout.setOnClickListener {
             userPref.isLogin=false
             userPref.clearPref()
             finishAffinity()
             startActivity(Intent(this, LoginActivity::class.java))
             bottomSheetLogout.dismiss()
         }

         bottomSheetLogout.show()

     }*/
//    fun printProcessInfo(){
//        val myProcess = ActivityManager.RunningAppProcessInfo()
//        ActivityManager.getMyMemoryState(myProcess)
//        val isInBackground = myProcess.importance != ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND
//        toast(this,isInBackground.toString())
//        Log.i("activitystate", "isInBackground: $isInBackground")
//        Log.i("activitystate", "Process: ${myProcess.importance}")
//    }

}