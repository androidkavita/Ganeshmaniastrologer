package com.callastro.data


import com.callastrouser.model.LoginResponse
import com.callastrouser.model.LoginverificationResponse
import com.callastrouser.model.RegistrationResponse
import com.callastrouser.model.AboutUsResponse
import com.callastrouser.model.ActiveHomeResponse
import com.callastrouser.model.AddAddressResponse
import com.callastrouser.model.AddressListResponse
import com.callastrouser.model.AgoraCreateUserResponse
import com.callastrouser.model.AgoraGenerateTokenResponse
import com.callastrouser.model.AstrologersListViewAllResponse
import com.callastrouser.model.AstrorahiResponse
import com.callastrouser.model.AvailabilityResponse
import com.callastrouser.model.BannerResponse
import com.callastrouser.model.BlogListResponse
import com.callastrouser.model.BookingDetailsResponse
import com.callastrouser.model.CallHistoryResponse
import com.callastrouser.model.CallRingResponse
import com.callastrouser.model.CallStartResponse
import com.callastrouser.model.CallendbyuserResponse
import com.callastrouser.model.CancelReasonResponse
import com.callastrouser.model.CartCountResponse
import com.callastrouser.model.CartListResponse
import com.callastrouser.model.CartPlaceOrderResponse
import com.callastrouser.model.CategoryProductResponse
import com.callastrouser.model.ChatAgoraResponse
import com.callastrouser.model.ChatFragmentResponse
import com.callastrouser.model.ChatHistoryResponse
import com.callastrouser.model.ChatListMessageResponse
import com.callastrouser.model.CheckChatEndResponse
import com.callastrouser.model.CityList
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.ConsultancyDetail
import com.callastrouser.model.ConsultancyOrderResponse
import com.callastrouser.model.EmailUs_Response
import com.callastrouser.model.ExpertizeResponse
import com.callastrouser.model.FAQResponse
import com.callastrouser.model.GetAstroDetailsResponse
import com.callastrouser.model.GetIntakeResponse
import com.callastrouser.model.GiveReviewResponse
import com.callastrouser.model.HistoryProductSuggestedResponse
import com.callastrouser.model.HistoryWallet
import com.callastrouser.model.IntakeResponse
import com.callastrouser.model.LanguageResponse
import com.callastrouser.model.LiveAstrologerResponse
import com.callastrouser.model.LiveastrologerviewallResponse
import com.callastrouser.model.MaritalStatusList
import com.callastrouser.model.MatchMakingResponse
import com.callastrouser.model.MissedCallChatResponse
import com.callastrouser.model.MyCartResponse
import com.callastrouser.model.MyOrdersEcommersProductResponse
import com.callastrouser.model.MyReviewsResponse
import com.callastrouser.model.NotificationResponse
import com.callastrouser.model.PlaceOrderResponse
import com.callastrouser.model.ProductResponse
import com.callastrouser.model.RechargeAmountDiscountResponse
import com.callastrouser.model.RemedyProductResponse
import com.callastrouser.model.RemedySuggestedResponse
import com.callastrouser.model.ReportIntakeDetail
import com.callastrouser.model.ReportsHistoryResponse
import com.callastrouser.model.ShopwithusViewallResponse
import com.callastrouser.model.StateList
import com.callastrouser.model.TransactionHistoryResponse
import com.callastrouser.model.ViewProfile
import com.callastrouser.model.ViewReportResponse
import com.callastrouser.model.WaitingListResponse
import com.callastrouser.model.WalletResponse
import com.callastrouser.model.ChatAcceptedResponse
import com.callastrouser.model.ChatCallCancelReasonResponse
import com.callastrouser.model.ChatRequestCancelResponse
import com.callastrouser.model.DThreeChartResponse
import com.callastrouser.model.EditAddressResponse
import com.callastrouser.model.GetAddressResponse
import com.callastrouser.model.GetAstroSlotsResponse
import com.callastrouser.model.GetBlogDetailResponse
import com.callastrouser.model.GetCustomerSupportChat
import com.callastrouser.model.GetGiftResponse
import com.callastrouser.model.GiveGiftResponse
import com.callastrouser.model.KundliMatchMakingResponse
import com.callastrouser.model.LiveCommentsModelClass
import com.callastrouser.model.MakeKundaliResponse
import com.callastrouser.model.NavmsaResponse
import com.callastrouser.model.Notiffication_Count_Response
import com.callastrouser.model.PlanetsResponse
import com.callastrouser.model.RecentSeeKundliResponse
import com.callastrouser.model.RemedyPoojaResponse
import com.callastrouser.model.SendKundliResponse
import com.callastrouser.model.UserAstroConnectStatusResponse
import com.callastrouser.model.call_ring_status_save_Response
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Field
import retrofit2.http.Header
import javax.inject.Inject

class MainRepositoryImpl @Inject constructor(private val apiService: ApiService) : MainRepository {


    override suspend fun login(
        country_code: String,
        mobile: String,
        device_id: String,
        device_type: String,
        device_name: String,
        device_token: String
    ):
            Response<LoginResponse> =
        apiService.login(country_code,mobile, device_id, device_type, device_name, device_token)

    override suspend fun loginverification(id: String, otp: String):
            Response<LoginverificationResponse> = apiService.login_verification(id, otp)

    override suspend fun recent_otp(mobile_no: String,type: String):
            Response<LoginResponse> = apiService.recent_otp(mobile_no,type)

    override suspend fun notification_count(token: String):
            Response<Notiffication_Count_Response> = apiService.notification_count(token)



    override suspend fun Registration(
        id: String,
        name: String,
        dob: String,
        address: String,
        gender: String,
        birth_time: String,
        email: String,
//        mobile_no: String
    ):
            Response<RegistrationResponse> =
        apiService.Registration(id, name, dob, address, gender, birth_time,email)

    override suspend fun add_comment(
        token: String,
        message: String,
        channel_name: String,
        astro_id: String,
    ): Response<CommonResponse> =
        apiService.add_comment(token, message,channel_name,astro_id)

    override suspend fun kundli_match(
        token: String,
        boy_name: String,
        boy_birth_date: String,
        boy_birth_time: String,
        boy_birth_place: String,
        girl_name: String,
        girl_birth_date: String,
        girl_birth_time: String,
        girl_birth_place: String,
    ):
            Response<MakeKundaliResponse> =
        apiService.kundli_match(token,boy_name, boy_birth_date, boy_birth_time, boy_birth_place, girl_name, girl_birth_date,girl_birth_time,girl_birth_place)


    override suspend fun live_end(token:String,timer:String,from_user: String,to_user: String,type: String):
            Response<CommonResponse> = apiService.live_end(token,timer,from_user,to_user,type)

    override suspend fun liveAstrologers(token: String):
            Response<LiveAstrologerResponse> = apiService.liveAstrologers(token)

    override suspend fun banner(token: String):
            Response<BannerResponse> = apiService.banner(token)

    override suspend fun EmailUs(token: String):
            Response<EmailUs_Response> = apiService.EmailUs(token)

    override suspend fun Wallet(token: String):
            Response<WalletResponse> = apiService.Wallet(token)


    override suspend fun active_home(token: String):
            Response<ActiveHomeResponse> = apiService.active_home(token)

    override suspend fun get_blog_list(token: String):
            Response<BlogListResponse> = apiService.get_blog_list(token)

    override suspend fun get_blog_detail(token: String,id: String):
            Response<GetBlogDetailResponse> = apiService.get_blog_detail(token,id)


    override suspend fun AddressList(token: String):
            Response<AddressListResponse> = apiService.AddressList(token)

    override suspend fun get_address(token: String,id: String,):
            Response<GetAddressResponse> = apiService.get_address(token,id)


    override suspend fun strologer_details(
        token: String,
        id: String,

        ):
            Response<AstrorahiResponse> =
        apiService.strologer_details(token,id)


    override suspend fun strologer_availability(
        token: String,
        id: String,

        ):
            Response<AvailabilityResponse> =
        apiService.strologer_availability(token,id)

    override suspend fun get_live_comments(
        token: String,
        channel_name: String,

        ):
            Response<LiveCommentsModelClass> =
        apiService.get_live_comments(token,channel_name)





    override suspend fun missed_requests(
        token: String,

        ): Response<MissedCallChatResponse> =
        apiService.missed_requests(token)

    override suspend fun recharg_amount_list(
        token: String,

        ): Response<RechargeAmountDiscountResponse> =
        apiService.recharg_amount_list(token)




    override suspend fun MatchMaking(
        token: String,
        boy_name: String,
        dob_boy: String,
        birth_time_boy: String,
        place_birth_boy: String,
        occupation_boy: String,
//        maritial_status_boy: String,
//        topic_consultation_boy: String,
        girl_name: String,
        dob_girl: String,
        birth_time_girl: String,
        place_birth_girl: String,
        occupation_girl: String,
//        maritial_status_girl: String,
//        topic_consultation_girl: String,
        request_type: String,
        astro_id: String,
        language_id: String
    ): Response<MatchMakingResponse> = apiService.MatchMaking(
        token,
        boy_name,
        dob_boy,
        birth_time_boy,
        place_birth_boy,
        occupation_boy,
//        maritial_status_boy,
//        topic_consultation_boy,
        girl_name,
        dob_girl,
        birth_time_girl,
        place_birth_girl,
        occupation_girl,
//        maritial_status_girl,
//        topic_consultation_girl,
        request_type,
        astro_id,
        language_id
    )





    override suspend fun AddAddress(
        token: String,
        full_name: String,
        phone_no: String,
        house_no: String,
        area: String,
//        state: String,
//        city: String,
        pincode: String,
        address_type: String,
    ): Response<AddAddressResponse> = apiService.AddAddress(
        token,
        full_name,
        phone_no,
        house_no,
        area,
//        state,
//        city,
        pincode,
        address_type
    )



    override suspend fun UpdateAddress(
        token: String,
        address_id: String,
        full_name: String,
        phone_no: String,
        house_no: String,
        area: String,
//        state: String,
//        city: String,
        pincode: String,
        address_type: String,
    ): Response<EditAddressResponse> = apiService.UpdateAddress(
        token,
        address_id,
        full_name,
        phone_no,
        house_no,
        area,
//        state,
//        city,
        pincode,
        address_type
    )




    override suspend fun help(
        token: String,
        astro_id: String,
        message: String,
        booking_id: String
    ):
            Response<CommonResponse> = apiService.help(
        token,
        astro_id,
        message,
                booking_id

        )

    override suspend fun add_user_details_first(
        token: String,
        name: String,
        dob: String,
        birth_time: String,
        place_birth: String,
        occupation: String,
        maritial_status: String,
        topic_consultation: String,
        language_id: String,
        astro_id: String,
        request_type: String,
//        state: String,
//        city: String,
        gender: String,
        fixed_session :String,
        fixed_session_type :String,
        slot_date :String,
        slot_time :String,
    ):
            Response<IntakeResponse> = apiService.add_user_details_first(
        token,
        name,
        dob,
        birth_time,
        place_birth,
        occupation,
        maritial_status,
        topic_consultation,
        language_id,
        astro_id,
        request_type,
//        state,
//        city,
        gender,
        fixed_session,fixed_session_type,slot_date,
        slot_time,
    )


    override suspend fun request_for_report(
        token: String,
        dob: String,
        birth_time: String,
        place_birth: String,
        occupation: String,
        maritial_status: String,
        topic_consultation: String,
        astro_id: String,
    ):
            Response<CommonResponse> = apiService.request_for_report(
        token,
        dob,
        birth_time,
        place_birth,
        occupation,
        maritial_status,
        topic_consultation,
        astro_id,
    )

    override suspend fun report_intake_detail(
        token: String,
        id: String
    ): Response<ReportIntakeDetail> = apiService.report_intake_detail(
        token,
        id
    )



    override suspend fun add_report_intake(
        token: String,
        astro_id: String,
        report_id: String,
        full_name: String,
        gender: String,
        dob: String,
        birth_time: String,
        place_birth: String,
        occupation: String,
        maritial_status: String,
        topic_consultation: String,
        language_id: String,
    ):
            Response<CommonResponse> = apiService.add_report_intake(
        token,
        astro_id,
        report_id,
        full_name,
        gender,
        dob,
        birth_time,
        place_birth,
        occupation,
        maritial_status,
        topic_consultation,
        language_id
    )


    override suspend fun send_chat_with_us(token:String,message:String):
            Response<CommonResponse> = apiService.send_chat_with_us(token,message)

    override suspend fun get_chat_with_us(token:String):
            Response<GetCustomerSupportChat> = apiService.get_chat_with_us(token)

    override suspend fun call_ring_status_save(token:String,channel_name: String):
            Response<call_ring_status_save_Response> = apiService.call_ring_status_save(token,channel_name)

    override suspend fun call_ring_end(token:String,channel_name: String):
            Response<CommonResponse> = apiService.call_ring_end(token,channel_name)


    override suspend fun Language(token:String):
            Response<LanguageResponse> = apiService.Language(token)

    override suspend fun callback_apply(token: String, mobile: String, discription: String):
            Response<CommonResponse> = apiService.callback_apply(token, mobile, discription)

    override suspend fun aboutus(token: String):
            Response<AboutUsResponse> = apiService.AboutUs(token)

    override suspend fun notification(token: String):
            Response<NotificationResponse> = apiService.Notification(token)

    override suspend fun faq(token: String):
            Response<FAQResponse> = apiService.FAQ(token)

    override suspend fun ViewProfile(token: String):
            Response<ViewProfile> = apiService.ViewProfile(token)

    override suspend fun Expertize(token: String):
            Response<ExpertizeResponse> = apiService.Expertize(token)

    override suspend fun ShopwithusViewall(token: String):
            Response<ShopwithusViewallResponse> = apiService.Shopwithusviewall(token)

    override suspend fun Liveastrologersviewall(token: String):
            Response<LiveastrologerviewallResponse> = apiService.Liveastrologersviewall(token)

    override suspend fun RemedySuggested(token: String):
            Response<RemedySuggestedResponse> = apiService.remedysuggested(token)

    override suspend fun RemedyProduct(token: String):
            Response<RemedyProductResponse> = apiService.remedyproduct(token)

    override suspend fun Chat(token: String,expertise_id: String,sort_filter: String):
            Response<ChatFragmentResponse> = apiService.ChatList(token,expertise_id,sort_filter)

    override suspend fun Call(token: String,expertise_id: String,sort_filter: String):
            Response<ChatFragmentResponse> = apiService.CallList(token,expertise_id,sort_filter)

    override suspend fun add_to_cart(token: String,product_id: String,type: String):
            Response<CommonResponse> = apiService.add_to_cart(token,product_id,type)

    override suspend fun cart_lists(token: String,coupon_code: String,address_id: String):
            Response<CartListResponse> = apiService.cart_lists(token,coupon_code,address_id)

    override suspend fun cart_place_order(token: String,address_id: String,payment_status: String,payment_type:String,transaction_id:String,orderfrom: String,product_id: String,coupon_discount: String,qty: String,):
            Response<CartPlaceOrderResponse> = apiService.cart_place_order(token,address_id,payment_status,payment_type,transaction_id,orderfrom,product_id,coupon_discount,qty)




    override suspend fun HistoryWallet(token: String):
            Response<HistoryWallet> = apiService.HistoryWallet(token)

    override suspend fun history_call(token: String):
            Response<CallHistoryResponse> = apiService.history_call(token)

    override suspend fun history_chat(token: String):
            Response<ChatHistoryResponse> = apiService.history_chat(token)

    override suspend fun history_reports(token: String):
            Response<ReportsHistoryResponse> = apiService.history_reports(token)

    override suspend fun check_chat_end(token:String,caller_id: String):
            Response<CheckChatEndResponse> = apiService.check_chat_end(token,caller_id)

    override suspend fun user_my_reveiw(token: String):
            Response<MyReviewsResponse> = apiService.user_my_reveiw(token)

    override suspend fun call_end_by_status(token:String,caller_id: String):
            Response<CallendbyuserResponse> = apiService.call_end_by_status(token,caller_id)

    override suspend fun live_astrologer_user(token:String,astro_id: String,channel_name: String,status: String):
            Response<CommonResponse> = apiService.live_astrologer_user(token,astro_id,channel_name,status)

    override suspend fun Notification_Read(token:String):
            Response<CommonResponse> = apiService.Notification_Read(token)


        override suspend fun user_astro_connect_status(token:String,channel_name: String):
            Response<UserAstroConnectStatusResponse> = apiService.user_astro_connect_status(token,channel_name)

    override suspend fun history_products(token: String,type:String):
            Response<HistoryProductSuggestedResponse> = apiService.history_products(token,type)

    override suspend fun my_orders(token: String,type:String):
            Response<MyOrdersEcommersProductResponse> = apiService.my_orders(token,type)

    override suspend fun get_intake_report(token: String):
            Response<GetIntakeResponse> = apiService.get_intake_report(token)



    override suspend fun booking_detail(token: String,order_id:String,product_id: String,):
            Response<BookingDetailsResponse> = apiService.booking_detail(token,order_id,product_id)

    override suspend fun consultancy_order(token: String):
            Response<ConsultancyOrderResponse> = apiService.consultancy_order(token)

    override suspend fun consultancy_order_detail(token: String, id: String):
            Response<ConsultancyDetail> = apiService.consultancy_order_detail(token, id)

    override suspend fun user_give_review(token: String,astro_id: String,rating: String,review: String,caller_id: String,type: String):
            Response<GiveReviewResponse> = apiService.user_give_review(token, astro_id,rating,review,caller_id,type)

    override suspend fun product_give_review(token: String,product_id: String,rating: String,review: String,):
            Response<GiveReviewResponse> = apiService.product_give_review(token, product_id,rating,review)

    override suspend fun call_request_cancel_api(token:String,id:String,reason:String,comment:String,action_by:String):
            Response<ChatRequestCancelResponse> = apiService.call_request_cancel_api(token,id,reason,comment,action_by)

    override suspend fun chatcallReasonCancelListApi(token:String):
            Response<ChatCallCancelReasonResponse> = apiService.chatcallReasonCancelListApi(token)


    override suspend fun gifts(token:String):
            Response<GetGiftResponse> = apiService.gifts(token)

    override suspend fun CategoryList(token: String, id: String):
            Response<CategoryProductResponse> = apiService.CategoryList(token, id)

    override suspend fun ProductDetails(token: String, id: String):
            Response<ProductResponse> = apiService.ProductDetails(token, id)


    override suspend fun EditProfile(
        token: String,
        name: RequestBody,
        mobile_no: RequestBody,
        email: RequestBody,
        dob: RequestBody,
        address: RequestBody,
        birth_time: RequestBody,
        gender: RequestBody,
//        state: RequestBody,
//        city: RequestBody,
        profile: MultipartBody.Part
    ):
            Response<CommonResponse> = apiService.Editprofile(
        token,
        name,
        mobile_no,
        email,
        dob,
        address,
        birth_time,
        gender,
        /*state,
        city,*/
        profile
    )

//    override suspend fun StateList(): Response<StateList> = apiService.StateList()
    override suspend fun maritials_list(token:String): Response<MaritalStatusList> = apiService.maritials_list(token)


    override suspend fun user_send_gifts(
        token: String,
        id: String,
        astro_id: String,
        channel_name: String
    ): Response<GiveGiftResponse> = apiService.user_send_gifts(token, id, astro_id,channel_name)

//    override suspend fun CityList(id: Int): Response<CityList> = apiService.CityList(id)

    override suspend fun OrderDetails(
        token: String,
        product_id: String,
        address_id: String,
        type: String,
        coupon_code: String,
    ): Response<MyCartResponse> = apiService.OrderDetails(token, product_id, address_id,type,coupon_code)

    override suspend fun OrderPlaced(
        token: String,
        product_id: String,
        product_price: String,
        shipping_chard: String,
        coupon_discount: String,
        grand_total: String,
        coupon_code: String,
        address_id: String,
        qty: String,
        transaction_id: String,
        payment_status: String,
        payment_type: String,
    ): Response<PlaceOrderResponse> = apiService.PlaceOrder(
        token, product_id, product_price, shipping_chard, coupon_discount,
        grand_total, coupon_code, address_id, qty, transaction_id, payment_status, payment_type
    )

    override suspend fun get_puja_list(
        token: String,

        ):Response<RemedyPoojaResponse> =
        apiService.get_puja_list(token)

    override suspend fun agora_generate_tokenApi(token:String,  astro_id: String, call_type: String):
            Response<AgoraGenerateTokenResponse> = apiService.agora_generate_tokenApi(token, astro_id, call_type)


    override suspend fun agora_create_userApi(token:String, to_userId:String, nickname:String):
            Response<AgoraCreateUserResponse> = apiService.agora_create_userApi(token, to_userId, nickname)

    override suspend fun chat_list_MessageApi(token:String,  to_id: String):
            Response<ChatListMessageResponse> = apiService.chat_list_MessageApi(token, to_id)

    override suspend fun get_astro_slot(token:String,date: String,astro_id:String):
            Response<GetAstroSlotsResponse> = apiService.get_astro_slot(token, date,astro_id)

    override suspend fun planets(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String
    ): Response<PlanetsResponse> = apiService.planets(
        year,
        month,
        date,
        hours,
        minutes,
        seconds,
        latitude,
        longitude,
        timezone
            )

    override suspend fun navamsa_chart(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String
    ): Response<NavmsaResponse> = apiService.navamsa_chart(
        year,
        month,
        date,
        hours,
        minutes,
        seconds,
        latitude,
        longitude,
        timezone
    )


    override suspend fun dThreechart(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String
    ): Response<DThreeChartResponse> = apiService.dThreechart(
        year,
        month,
        date,
        hours,
        minutes,
        seconds,
        latitude,
        longitude,
        timezone
    )



    override suspend fun match_making(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String,
        fyear: String,
        fmonth: String,
        fdate: String,
        fhours: String,
        fminutes: String,
        fseconds: String,
        flatitude: String,
        flongitude: String,
        ftimezone: String,
    ): Response<KundliMatchMakingResponse> = apiService.match_making(
        year,
        month,
        date,
        hours,
        minutes,
        seconds,
        latitude,
        longitude,
        timezone,
        fyear,
        fmonth,
        fdate,
        fhours,
        fminutes,
        fseconds,
        flatitude,
        flongitude,
        ftimezone,
    )



    override suspend fun insert_recently_see_kundali(
        token:String,
        name : String,
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String,
        BirthPlace: String,
    ): Response<SendKundliResponse> = apiService.insert_recently_see_kundali(
        token,
        name,
        year,
        month,
        date,
        hours,
        minutes,
        seconds,
        latitude,
        longitude,
        timezone,
        BirthPlace

    )


    override suspend fun recently_see_kundali(
        token:String,
        type: String
    ): Response<RecentSeeKundliResponse> = apiService.recently_see_kundali(
        token,
        type,)

    override suspend fun insert_recently_see_match_making_kundali(
        token:String,
        fname : String,
        fdate : String,
        fmonth: String,
        fyear: String,
        fhours: String,
        fminutes: String,
        fseconds: String,
        flatitude: String,
        flongitude: String,
        ftimezone: String,
        fbirthplace: String,
        mname : String,
        mdate : String,
        mmonth: String,
        myear: String,
        mhours: String,
        mminutes: String,
        mseconds: String,
        mlatitude: String,
        mlongitude: String,
        mtimezone: String,
        mbirthplace: String,
    ): Response<SendKundliResponse> = apiService.insert_recently_see_match_making_kundali(
        token,fname, fdate, fmonth, fyear, fhours, fminutes, fseconds, flatitude, flongitude, ftimezone, fbirthplace, mname, mdate, mmonth, myear, mhours, mminutes, mseconds, mlatitude, mlongitude, mtimezone, mbirthplace)



    override suspend fun chatagoraApi(token:String,  to_userId: String, message: String, type: String):
            Response<ChatAgoraResponse> = apiService.chatagoraApi(token, to_userId, message, type)

    override suspend fun reason_cancel_list(token: String):
            Response<CancelReasonResponse> = apiService.reason_cancel_list(token)


    override suspend fun cart_item_count(token: String):
            Response<CartCountResponse> = apiService.cart_item_count(token)




    override suspend fun strologers_list(token: String):
            Response<AstrologersListViewAllResponse> = apiService.strologers_list(token)

    override suspend fun delete_address(token:String,id:String):
            Response<CommonResponse> = apiService.delete_address(token,id)

    override suspend fun cancel_order(token:String,order_id: String,id:String,reason_ids: String,write_reason: String,):
            Response<CommonResponse> = apiService.cancel_order(token,order_id,id,reason_ids,write_reason)

    override suspend fun call_end(token:String,timer:String,from_user: String,to_user: String,caller_id:String,type:String):
            Response<CommonResponse> = apiService.call_end(token,timer,from_user,to_user,caller_id,type)

    override suspend fun chat_end(token:String,timer:String,from_user: String,to_user: String,caller_id:String,type: String):
            Response<CommonResponse> = apiService.chat_end(token,timer,from_user,to_user,caller_id,type)



    override suspend fun when_call_start(token:String,astro_id: String):
            Response<CallStartResponse> = apiService.when_call_start(token,astro_id)

    override suspend fun history_wallets(token:String):
            Response<TransactionHistoryResponse> = apiService.history_wallets(token)

    override suspend fun delete_cart(token:String,cart_id: String):
            Response<CommonResponse> = apiService.delete_cart(token,cart_id)



    override suspend fun add_money(token:String,amount: String,payment_status: String,transaction_id: String,):
            Response<CommonResponse> = apiService.add_money(token,amount,payment_status,transaction_id)


    override suspend fun get_report_astro_list(token: String):
            Response<AstrologersListViewAllResponse> = apiService.get_report_astro_list(token)

    override suspend fun get_report_astro_details(token: String,astro_id:String):
            Response<GetAstroDetailsResponse> = apiService.get_report_astro_details(token,astro_id)

    override suspend fun waiting_chat_list(token: String):
            Response<WaitingListResponse> = apiService.waiting_chat_list(token)

    override suspend fun waiting_call_list(token: String):
            Response<WaitingListResponse> = apiService.waiting_call_list(token)

    override suspend fun chat_cancel_by_user(token: String,id: String):
            Response<CommonResponse> = apiService.chat_cancel_by_user(token,id)

    override suspend fun call_cancel_by_user(token: String,id: String):
            Response<CommonResponse> = apiService.call_cancel_by_user(token,id)


    override suspend fun chat_accepted(token:String):
            Response<ChatAcceptedResponse> = apiService.chat_accepted(token)



    override suspend fun call_accepted(token:String):
            Response<ChatAcceptedResponse> = apiService.call_accepted(token)

    override suspend fun requests_wait_delete(token: String):
            Response<CommonResponse> = apiService.requests_wait_delete(token)


    override suspend fun view_report_doc_upload(token: String,id:String):
            Response<ViewReportResponse> = apiService.view_report_doc_upload(token,id)

    override suspend fun call_ring(token: String,astro_id:String,user_id:String,request_id: String):
            Response<CallRingResponse> = apiService.call_ring(token,astro_id,user_id,request_id)


    override suspend fun call_received(token: String,unique_id:String):
            Response<CommonResponse> = apiService.call_received(token,unique_id)



}