package com.callastrouser.ui.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.MissedAdapter
import com.callastrouser.databinding.FragmentMissedCallChatBinding
import com.callastrouser.model.MissedCallChatResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.DashboardHistoryWalletViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MissedCallChat : BaseFragment() {
    lateinit var binding: FragmentMissedCallChatBinding
    lateinit var adapter : MissedAdapter
    private val viewModel: DashboardHistoryWalletViewModel by viewModels()
    var List :ArrayList<MissedCallChatResponseData> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentMissedCallChatBinding.inflate(inflater,container,false)

        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.missed_requests("Bearer "+userPref.getToken().toString())
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

        viewModel.missedCallChatResponse.observe(viewLifecycleOwner){
            if (it.status == 1){
                binding.rvwallethistory.visibility = View.VISIBLE
                binding.nodatatext.visibility = View.GONE
                List.clear()
                List.addAll(it.data)
                adapter = MissedAdapter(requireContext(),List)
                binding.rvwallethistory.adapter = adapter
            }else{
                binding.rvwallethistory.visibility = View.VISIBLE
                binding.nodatatext.visibility = View.GONE
            }
        }

        return binding.root
    }


}