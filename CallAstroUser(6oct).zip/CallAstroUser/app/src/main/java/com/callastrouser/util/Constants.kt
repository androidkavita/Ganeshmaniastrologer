package com.callastrouser.util

object Constants {


}