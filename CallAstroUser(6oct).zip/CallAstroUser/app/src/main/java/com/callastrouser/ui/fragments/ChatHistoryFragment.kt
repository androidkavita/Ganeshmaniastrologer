package com.callastrouser.ui.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.ChatHistoryAdapter
import com.callastrouser.databinding.FragmentChatHistoryBinding
import com.callastrouser.model.ChatHistoryResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.DashboardHistoryWalletViewModel
import com.maxtra.astrorahi.interfaces.Chats
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ChatHistoryFragment : BaseFragment(), Chats {
    lateinit var binding: FragmentChatHistoryBinding
    private val viewModel: DashboardHistoryWalletViewModel by viewModels()
    lateinit var adapter: ChatHistoryAdapter
    var List:ArrayList<ChatHistoryResponseData> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        binding = FragmentChatHistoryBinding.inflate(inflater, container, false)

        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.history_chat(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }




        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.historyChatResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                List.clear()
                List.addAll(it.data)
                adapter = ChatHistoryAdapter(requireContext(), List,this)
                binding.rvwallethistory.adapter = adapter
            } else {
                toast(it.message.toString())
//                snackbar(it?.message!!)
            }
        }
        return binding.root
    }

    override fun callchatLL(linear: LinearLayout, id: String,name:String) {
        linear.setOnClickListener {
//            startActivity(
//                Intent(requireContext(), ChatActivity::class.java)
//                    .putExtra("type","1")
//                    .putExtra("astroid",id.toString())
//                    .putExtra("astroname",name.toString())
//            )
        }
    }

}