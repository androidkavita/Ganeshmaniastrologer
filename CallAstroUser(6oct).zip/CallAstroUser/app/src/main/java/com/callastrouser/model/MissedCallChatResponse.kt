package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class MissedCallChatResponse (
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<MissedCallChatResponseData> = arrayListOf()
)
data class MissedCallChatResponseData (
    @SerializedName("type"          ) var type         : Int?    = null,
    @SerializedName("astro_name"    ) var astroName    : String? = null,
    @SerializedName("astro_profile" ) var astroProfile : String? = null,
    @SerializedName("created_at"    ) var createdAt    : String? = null,
    @SerializedName("request_date"  ) var requestDate  : String? = null,
    @SerializedName("request_time"  ) var requestTime  : String? = null
)