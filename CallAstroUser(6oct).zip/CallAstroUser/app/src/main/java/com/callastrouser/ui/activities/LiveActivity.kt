package com.callastrouser.ui.activities

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.SurfaceView
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.MainActivity
import com.callastrouser.R
import com.callastrouser.adapter.GiftListAdapter
import com.callastrouser.adapter.GoLiveAdapter
import com.callastrouser.databinding.ActivityLiveBinding
import com.callastrouser.model.GetGiftResponse
import com.callastrouser.model.GetGiftResponseData
import com.callastrouser.model.LiveCommentsModelClassData
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.Constant
import com.callastrouser.viewModel.CustomerViewModel
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import de.hdodenhof.circleimageview.CircleImageView
import io.agora.rtc2.ChannelMediaOptions
import io.agora.rtc2.Constants
import io.agora.rtc2.IRtcEngineEventHandler
import io.agora.rtc2.RtcEngine
import io.agora.rtc2.RtcEngineConfig
import io.agora.rtc2.video.VideoCanvas
import java.text.DecimalFormat
import java.util.Timer
import java.util.TimerTask

@AndroidEntryPoint
class LiveActivity : BaseActivity(), GiftListAdapter.Click, View.OnClickListener {
    lateinit var binding: ActivityLiveBinding
    private val PERMISSION_REQ_ID = 22
    private val REQUESTED_PERMISSIONS = arrayOf<String>(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA
    )
    var end :String = "1"
    lateinit var bottomdialog: BottomSheetDialog
    private var callTimerText: TextView? = null
    private var callTimer: Timer? = null
    private var counter = 0
    var offline: String = ""
    lateinit var adapter: GoLiveAdapter
    var list: ArrayList<LiveCommentsModelClassData> = arrayListOf()
    var giftList: ArrayList<GetGiftResponseData> = arrayListOf()
    private var WalletMoney: Int = 0
    private var CallingCharge: Int = 0
    private var Calculatetime: Int = 0
    private var Minimumbalence: Int = 0
    lateinit var giftListAdapter: GiftListAdapter
    private val viewModel: CustomerViewModel by viewModels()
    private fun checkSelfPermission(): Boolean {
        return if (ContextCompat.checkSelfPermission(
                this,
                REQUESTED_PERMISSIONS[0]
            ) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this,
                REQUESTED_PERMISSIONS[1]
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            false
        } else true
    }

    fun showMessage(message: String?) {
        runOnUiThread {
            Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    var flag :Boolean = false

    // Fill the App ID of your project generated on Agora Console.
    private val appId = "5d6b6fe592ec4b1db67bb7ad5a6454a0"

    // Fill the channel name.
//    private val channelName = "MNC"
    private lateinit var channelName: String
    private var mMuted = false

    // Fill the temp token generated on Agora Console.
//    private val token = "007eJxTYJhyYtrTjBmJdQc2/ZRNyTqiPYtPM27VuSZHLu8JLv2nS0UVGExTzJLM0lJNLY1Sk02SDFOSzMyTkswTU0wTzUxMTRINMgIUUxoCGRkCV5UyMEIhiM/M4OvnzMAAAD03Hjc="
    private lateinit var token: String
    private lateinit var name: String
    lateinit var names: TextView
    private lateinit var profile: String
    lateinit var expertise: TextView
    lateinit var language: TextView
    lateinit var experience: TextView
    lateinit var image: CircleImageView
    private lateinit var calling_charg: String
    private lateinit var astro_id: String

    // An integer that identifies the local user.
    private val uid = 0
    private var isJoined = false
    private var agoraEngine: RtcEngine? = null

    //SurfaceView to render local video in a Container.
    private var localSurfaceView: SurfaceView? = null

    //SurfaceView to render Remote video in a Container.
    private var remoteSurfaceView: SurfaceView? = null
    val handlerStatusCheck = Handler(Looper.getMainLooper())
    var runnableStatusCheck: Runnable? = null

    val handlerStatusCheck1 = Handler(Looper.getMainLooper())
    var runnableStatusCheck1: Runnable? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_live)

//        binding.header.tvHeadName.text = "Live Streaming"
//        binding.header.backArrow.setOnClickListener { finish() }
        callTimerText = findViewById(R.id.time)


//        if (!checkSelfPermission()) {
//            ActivityCompat.requestPermissions(requireActivity(), REQUESTED_PERMISSIONS, PERMISSION_REQ_ID);
//        }
        try {
            channelName = ""
            token = ""
            astro_id = ""
//            if (requireArguments().getString("channelname") != null) {
//                channelName = requireArguments().getString("channelname").toString()
//            }
//            if (requireArguments().getString("agora_token") != null) {
//                token = requireArguments().getString("agora_token").toString()
//            }
//            if (requireArguments().getString("astro_id") != null) {
//                astro_id = requireArguments().getString("astro_id").toString()
//            }

            if (intent != null) {
                channelName = intent.getStringExtra("channelname").toString()
                token = intent.getStringExtra("agora_token").toString()
                astro_id = intent.getStringExtra("id").toString()
                name = intent.getStringExtra("name").toString()
                profile = intent.getStringExtra("profile").toString()
                calling_charg = intent.getStringExtra("calling_charg").toString()
            }
            binding.connect.visibility = View.VISIBLE
//            binding.time.visibility = View.VISIBLE
            binding.leave.visibility = View.GONE
            binding.tvPersonName.text = name
            binding.chargeCalling.text = "₹ $calling_charg /min"
            Glide.with(this@LiveActivity).load(profile).into(binding.profilesphoto)
            setupVideoSDKEngine();
            binding.buttonSwitchCamera.setOnClickListener(this)
            binding.videoBtn.setOnClickListener(this)
            binding.buttonMute.setOnClickListener(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        handlerStatusCheck.postDelayed(Runnable {
            handlerStatusCheck.postDelayed(runnableStatusCheck!!, 5000)
            viewModel.get_live_comments(
                "Bearer " + userPref.getToken().toString(), channelName
            )
            viewModel.live_astrologer_user(
                "Bearer " + userPref.getToken().toString(), channelName
            )
            AgainAndAgain()
//            viewModel.when_call_start_again(
//                "Bearer " + userPref.getToken().toString(),
//                astro_id.toString()
//                /* userPref.getChannelName().toString()*/
//            )
        }.also { runnableStatusCheck = it }, 0)

        if (channelName.isNullOrEmpty() || token.isNullOrEmpty()) {
            setupVideoSDKEngine();
            toast(this, "Any Astrologer is not live.")
        } else {
            setupVideoSDKEngine();
            joinChannel()
        }
            viewModel.when_call_start_again(
                "Bearer " + userPref.getToken().toString(),
                astro_id.toString()
                /* userPref.getChannelName().toString()*/
            )
//        viewModel.get_live_comments(
//            "Bearer "+userPref.getToken().toString(),channelName
//        )
        viewModel.astrorahiResponse.observe(this) {
            if (it.status == 1) {
                names.text = it.data?.name.toString()
                expertise.text = it.data?.expertise.toString()
                language.text = it.data?.language.toString()
                experience.text = "Exp: " + it.data?.experence.toString()
                Glide.with(this).load(it.data?.profile).into(image)
            }
        }


        viewModel.userAstroConnectStatusResponse.observe(this@LiveActivity) {
            if (it.status == 1) {
                if (it.data?.status == 1) {
                    binding.connect.visibility = View.GONE
//                    binding.time.visibility = View.GONE
                } else {
                    binding.connect.visibility = View.VISIBLE
//                    binding.time.visibility = View.VISIBLE
                }
            }
        }

        viewModel.liveCommentsModelClass.observe(this) {
            if (it?.status == 1) {
                list.clear()
                list.addAll(it.data)
                adapter = GoLiveAdapter(this, list)
                binding.comment.adapter = adapter
            } else {

            }
        }
        binding.imageCommentSend.setOnClickListener {
            viewModel.add_comment(
                "Bearer " + userPref.getToken().toString(),
                binding.etSend.text.toString(),
                channelName,
                astro_id
            )
        }
        viewModel.commonResponse.observe(this) {
            if (it.status == 1) {
                binding.etSend.setText("")
            }
        }
        viewModel.commonssResponse.observe(this) {
            if (it.status == 1) {
                try {
                    binding.frameLayoutLocalVideo.visibility = View.GONE
                    leaveChannel()
                    agoraEngine!!.stopPreview()
                    agoraEngine!!.leaveChannel()
                    // Destroy the engine in a sub-thread to avoid congestion
                    Thread {
                        RtcEngine.destroy()
                        agoraEngine = null
                    }.start()
                    ReviewAndRating()
                }catch (e:Exception){
                    e.printStackTrace()
                }

            }
        }
        viewModel.commonssResponses.observe(this) {
            if (it.status == 1) {

            }
        }

        viewModel.callStartResponse.observe(this) {
            if (it.status == 1) {
                WalletMoney = it.data?.wallet!!.toInt()
                CallingCharge = it.data?.callingCharg!!.toInt()
                Calculatetime = (WalletMoney / CallingCharge) * 60
                Minimumbalence = CallingCharge * 5
                binding.chargeCalling.text = "₹ $calling_charg /min"

                if (WalletMoney < Minimumbalence) {
                    Alertdialog()
//                    finish()
//                    LiveEnd()
//                    viewModel.live_astrologer_user("Bearer "+userPref.getToken().toString(),astro_id,channelName,"0")
//                    leaveChannel()
                } else {
                    joinChannelss(token.toString(), channelName.toString())
                    binding.frameLayoutLocalVideo.visibility = View.VISIBLE
                    viewModel.live_astrologer_user(
                        "Bearer " + userPref.getToken().toString(),
                        astro_id,
                        channelName,
                        "1"
                    )
                    callTimer = Timer()
                    startCallTimer()
                }
            }
        }

        viewModel.callStartResponseagain.observe(this) {
            if (it.status == 1) {
                WalletMoney = it.data?.wallet!!.toInt()
                CallingCharge = it.data?.callingCharg!!.toInt()
                Calculatetime = (WalletMoney / CallingCharge) * 60
                Minimumbalence = CallingCharge * 5
//                toast(this,WalletMoney.toString())
//                binding.chargeCalling.text = "₹ $calling_charg /min"
//                if (flag == true){
//                    if(WalletMoney < 0){
//                        LiveEnd()
//                        viewModel.live_astrologer_user(
//                            "Bearer " + userPref.getToken().toString(),
//                            astro_id,
//                            channelName,
//                            "0"
//                        )
//                        leaveChannel()
//                    }
//                }

//                else{
//                    joinChannelss(token.toString(),channelName.toString())
//                    binding.frameLayoutLocalVideo.visibility = View.VISIBLE
//                    viewModel.live_astrologer_user("Bearer "+userPref.getToken().toString(),astro_id,channelName,"1")
//                    callTimer = Timer()
//                    startCallTimer()
//                }
            }
        }


        viewModel.callStartResponseagainandagain.observe(this) {
            if (it.status == 1) {
                WalletMoney = it.data?.wallet!!.toInt()
                CallingCharge = it.data?.callingCharg!!.toInt()
                Calculatetime = (WalletMoney / CallingCharge) * 60
                Minimumbalence = CallingCharge * 5
//                toast(this,WalletMoney.toString())
//                binding.chargeCalling.text = "₹ $calling_charg /min"
//                if (flag == true){
//                    if(WalletMoney < 0){
//                        LiveEnd()
//                        viewModel.live_astrologer_user(
//                            "Bearer " + userPref.getToken().toString(),
//                            astro_id,
//                            channelName,
//                            "0"
//                        )
//                        leaveChannel()
//                    }
//                }

//                else{
//                    joinChannelss(token.toString(),channelName.toString())
//                    binding.frameLayoutLocalVideo.visibility = View.VISIBLE
//                    viewModel.live_astrologer_user("Bearer "+userPref.getToken().toString(),astro_id,channelName,"1")
//                    callTimer = Timer()
//                    startCallTimer()
//                }
            }
        }


//        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
//            if (it) {
//                showProgressDialog()
//            } else {
//                hideProgressDialog()
//            }
//        }
//        viewModel.CommonResponse.observe(this){
//            if (it.status == 1){
//                toast(this,it.message.toString())
//                binding.etSend.setText("")
//                viewModel.get_live_comments(
//                    userPref.getToken().toString(),channelName
//                )
//            }
//        }

        binding.connect.setOnClickListener {
            flag = true
            agoraEngine!!.leaveChannel()
            LiveStart()
            handlerStatusCheck.postDelayed(Runnable {
                handlerStatusCheck.postDelayed(runnableStatusCheck!!, 5000)
                viewModel.when_call_start_again(
                    "Bearer " + userPref.getToken().toString(),
                    astro_id.toString()
                    /* userPref.getChannelName().toString()*/
                )
//                    viewModel.when_call_start_again(
//                        "Bearer " + userPref.getToken().toString(),
//                        astro_id.toString()
//                        /* userPref.getChannelName().toString()*/
//                    )
            }.also { runnableStatusCheck = it }, 0)
        }

        binding.gift.setOnClickListener {
            giftbottomsheet()
        }

        binding.leave.setOnClickListener {
            flag = false
            LiveEnd()
            viewModel.live_astrologer_user(
                "Bearer " + userPref.getToken().toString(),
                astro_id,
                channelName,
                "0"
            )
            leaveChannel()
        }


        viewModel.givegiftResponse.observe(this) {
            if (it.status == 1) {
//                toast(this@LiveActivity, it.message.toString())
                bottomdialog.dismiss()
            }
        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.videoBtn -> {
                val btn = v as ImageView
                if (btn.isSelected) {
                    btn.isSelected = false
                    btn.clearColorFilter()
                    btn.setImageResource(R.drawable.ic_video_cross_y)
                } else {
                    btn.isSelected = true
                    btn.setImageResource(R.drawable.ic_video_cross_y)
                }
                agoraEngine?.muteLocalVideoStream(btn.isSelected)
                if (btn.isSelected) {
//                    binding.localVideoView.visibility = View.GONE
                    binding.frameLayoutLocalVideo.setBackgroundColor(R.color.localBackground)
                    binding.frameLayoutLocalVideo.background =
                        ContextCompat.getDrawable(this, R.drawable.ic_video_cross_y)
                    btn.setImageResource(R.drawable.ic_video_cross_y)
                } else {
                    binding.frameLayoutLocalVideo.visibility = View.VISIBLE
                    btn.setImageResource(R.drawable.videocamcolored)
                }
                val videoSurface = binding.frameLayoutLocalVideo.getChildAt(0) as SurfaceView?
                videoSurface?.setZOrderMediaOverlay(!btn.isSelected)
                videoSurface?.visibility = if (btn.isSelected) View.GONE else View.VISIBLE
            }
//            R.id.buttonCall->{
////                CallEnd()
//                if (!isJoined) {
//                    showMessage("Join a channel first")
//
//                } else {
////                    finish()
//                    stopSound()
////                    viewCallStatusApi()
//                    agoraEngine?.leaveChannel()
//                    showMessage("You left the channel")
//                    // Stop remote video rendering.
//                    if (remoteSurfaceView != null) remoteSurfaceView?.visibility = View.GONE
//                    // Stop local video rendering.
//                    if (localSurfaceView != null) localSurfaceView?.visibility = View.GONE
//                    isJoined = false
//                }
//            }
            R.id.buttonMute -> {
                mMuted = !mMuted
                agoraEngine?.muteLocalAudioStream(mMuted)
                val res: Int = if (mMuted) {
                    R.drawable.ic_mute
                } else {
                    R.drawable.ic_unmute
                }

                binding.buttonMute.setImageResource(res)
                onRemoteUserVideoMuted(uid, mMuted)
            }

            R.id.buttonSwitchCamera -> {
                agoraEngine?.switchCamera()

            }
        }
    }

    private fun onRemoteUserVideoMuted(uid: Int, muted: Boolean) {
        val surfaceView = binding.frameLayoutRemoteVideo.getChildAt(0) as SurfaceView?

        val tag = surfaceView?.tag
        if (tag != null && tag as Int == uid) {
            surfaceView.visibility = if (muted) View.GONE else View.VISIBLE
        }
    }

    fun AgainAndAgain(){
        viewModel.when_call_start_again_and_again( "Bearer " + userPref.getToken().toString(),astro_id.toString())
    }

    @SuppressLint("MissingInflatedId")
    fun giftbottomsheet() {
        // on below line we are creating a new bottom sheet dialog.
        bottomdialog = BottomSheetDialog(this, R.style.AppBottomSheetDialogTheme)
        // on below line we are inflating a layout file which we have created.
        val view = layoutInflater.inflate(R.layout.gift, null)
        val metrics = DisplayMetrics()
        windowManager?.defaultDisplay?.getMetrics(metrics)
        bottomdialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomdialog.behavior.peekHeight = metrics.heightPixels
        var cross = view.findViewById<ImageView>(R.id.cross)
        var rvgift = view.findViewById<RecyclerView>(R.id.rvgift)

        viewModel.gifts("Bearer " + userPref.getToken().toString())
        viewModel.getgiftResponse.observe(this) {
            if (it.status == 1) {
                giftList.clear()
                giftList.addAll(it.data)
                giftListAdapter = GiftListAdapter(this@LiveActivity, giftList, this)
                rvgift.adapter = giftListAdapter
                giftListAdapter.notifyDataSetChanged()

            }
        }

        cross.setOnClickListener {
            bottomdialog.dismiss()
        }
        // below line is use to set cancelable to avoid
        // closing of dialog box when clicking on the screen.
        bottomdialog.setCancelable(true)

        // on below line we are setting
        // content view to our view.
        bottomdialog.setContentView(view)

        // on below line we are calling
        // a show method to display a dialog.
        bottomdialog.show()
    }


    private fun startCallTimer() {
//        if (counter< Calculatetime){
        callTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                if (++counter == Calculatetime) counter =
                    0 // for the taluxi app a call must not be longer than 1h.
                val formatter = DecimalFormat("00")
                val timerText =
                    formatter.format((counter / 60).toLong()) + ":" + formatter.format((counter % 60).toLong())
                runOnUiThread {
                    if (Calculatetime == 0) {
                        LiveEnd()
                        viewModel.live_astrologer_user(
                            "Bearer " + userPref.getToken().toString(),
                            astro_id,
                            channelName,
                            "0"
                        )
                        if (isJoined) {
//                    viewCallStatusApi()
                            showMessage("You left the channel")
                            agoraEngine?.leaveChannel()
                            finish()
                            isJoined = false
                            sendBroadcast(Intent(Constant.ACTION_HANG_UP_ANSWERED_CALL))
                        } else {
//                    showMessage("Join a channel first")
                        }
                    } else {
                        callTimerText?.text = timerText
                    }
                }
                Thread.sleep(1000);
            }
        }, 0, 1000)
//        }else{
//            snackbar("you don't have enough balence.")
//        }

    }

    fun Alertdialog() {
        val buinder = AlertDialog.Builder(this)

        buinder.setMessage(
            "Your wallet balance is Rs $WalletMoney. " +
                    "Minimum balance required Rs $Minimumbalence " +
                    "to connect Astrologer $name Recharge now with following balance"
        )
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Recharge Now!!")

        buinder.setPositiveButton("OK") { dialogInterface, which ->
            LiveEnd()
            viewModel.live_astrologer_user(
                "Bearer " + userPref.getToken().toString(),
                astro_id,
                channelName,
                "0"
            )
            leaveChannel()
            finish()
        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(true)
        alertDialog.show()
    }

    private fun setupVideoSDKEngine() {
        try {
            val config = RtcEngineConfig()
            config.mContext = this
            config.mAppId = appId
            config.mEventHandler = mRtcEventHandler
            agoraEngine = RtcEngine.create(config)
            // By default, the video module is disabled, call enableVideo to enable it.
            agoraEngine!!.enableVideo()
        } catch (e: Exception) {
            showMessage(e.toString())
        }
    }

    private val mRtcEventHandler: IRtcEngineEventHandler = object : IRtcEngineEventHandler() {
        // Listen for the remote host joining the channel to get the uid of the host.
        override fun onUserJoined(uid: Int, elapsed: Int) {
//            showMessage("Remote user joined $uid")
            return runOnUiThread {
                setupRemoteVideo(uid)
//                binding.connect.visibility = View.GONE
                /*binding.leave.visibility = View.VISIBLE*/
            }!!
            /*if (!audienceRole!!.isChecked)*/
            // Set the remote video view
        }

        override fun onJoinChannelSuccess(channel: String, uid: Int, elapsed: Int) {
            isJoined = true
//            showMessage("Joined Channel $channel")
        }

        override fun onUserOffline(uid: Int, reason: Int) {
//            showMessage("Remote user offline $uid $reason")
            offline = "1"
            runOnUiThread {
                remoteSurfaceView!!.visibility = View.GONE
                if (offline == "1") {
                    AstroOffline()
                    LiveEnd()
                    viewModel.live_astrologer_user(
                        "Bearer " + userPref.getToken().toString(),
                        astro_id,
                        channelName,
                        "0"
                    )
                }
            }
        }

        override fun onRemoteVideoStateChanged(uid: Int, state: Int, reason: Int, elapsed: Int) {
            super.onRemoteVideoStateChanged(uid, state, reason, elapsed)
            runOnUiThread { onRemoteUserVideoToggle(uid, state) }
        }

    }

    private fun onRemoteUserVideoToggle(uid: Int, state: Int) {

        val videoSurface = binding.frameLayoutRemoteVideo.getChildAt(0) as SurfaceView
        videoSurface.visibility = if (state == 0) View.GONE else View.VISIBLE

        // add an icon to let the other user know remote video has been disabled
        if (state == 0) {
            val noCamera = ImageView(this)
            noCamera.setImageResource(R.drawable.ic_video_cross_y)
            binding.frameLayoutRemoteVideo.addView(noCamera)
        } else {
            try {
                val noCamera = binding.frameLayoutRemoteVideo.getChildAt(1) as ImageView?
                if (noCamera != null) {
                    binding.frameLayoutRemoteVideo.removeView(noCamera)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun AstroOffline() {
        offline = ""
        val buinder = AlertDialog.Builder(this)
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Offline")
        buinder.setMessage("Astrologer has offline.")
        buinder.setPositiveButton("OK") { dialogInterface, which ->
//            finish()
            ReviewAndRating()
        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    private fun setupRemoteVideo(uid: Int) {
//        val container = view?.findViewById<FrameLayout>(R.id.remote_video_view_container)
//        var container = activity?.findViewById<FrameLayout>(R.id.frame_layout_local_video)
        remoteSurfaceView = SurfaceView(this)
        remoteSurfaceView!!.setZOrderMediaOverlay(true)
        binding.frameLayoutRemoteVideo.addView(remoteSurfaceView)
        agoraEngine!!.setupRemoteVideo(
            VideoCanvas(
                remoteSurfaceView,
                VideoCanvas.RENDER_MODE_HIDDEN,
                uid
            )
        )
        // Display RemoteSurfaceView.
        remoteSurfaceView!!.setVisibility(View.VISIBLE)
    }

    private fun setupLocalVideo() {
//        val container = view?.findViewById<FrameLayout>(R.id.local_video_view_container)
        // Create a SurfaceView object and add it as a child to the FrameLayout.
        localSurfaceView = SurfaceView(this)
        binding.frameLayoutLocalVideo?.addView(localSurfaceView)
        // Call setupLocalVideo with a VideoCanvas having uid set to 0.
        setupVideoSDKEngine()
        agoraEngine!!.setupLocalVideo(
            VideoCanvas(
                localSurfaceView,
                VideoCanvas.RENDER_MODE_HIDDEN,
                0
            )
        )
    }

    fun joinChannel() {
        if (checkSelfPermission()) {
            val options = ChannelMediaOptions()
            // For Live Streaming, set the channel profile as LIVE_BROADCASTING.
            options.channelProfile = Constants.CHANNEL_PROFILE_LIVE_BROADCASTING
            // Set the client role as BROADCASTER or AUDIENCE according to the scenario.
//            if (audienceRole!!.isChecked) { //Audience
            options.clientRoleType = Constants.CLIENT_ROLE_AUDIENCE
//            }
//            else { //Host
//                options.clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
//                // Display LocalSurfaceView.
////                setupLocalVideo()
//                localSurfaceView!!.visibility = View.VISIBLE
//                // Start local preview.
//                agoraEngine!!.startPreview()
//            }
//            audienceRole!!.isEnabled = false // Disable the switch
            // Join the channel with a temp token.
            // You need to specify the user ID yourself, and ensure that it is unique in the channel.
            agoraEngine!!.joinChannel(token, channelName, 0, options)
        } else {
            Toast.makeText(this, "Permissions was not granted", Toast.LENGTH_SHORT)
                .show()
        }
    }

    private fun joinChannelss(token: String, channelName: String) {
        if (checkSelfPermission()) {
            val options = ChannelMediaOptions()

            // For a Video call, set the channel profile as COMMUNICATION.
            options.channelProfile = io.agora.rtc2.Constants.CHANNEL_PROFILE_COMMUNICATION
            // Set the client role as BROADCASTER or AUDIENCE according to the scenario.
            options.clientRoleType = io.agora.rtc2.Constants.CLIENT_ROLE_BROADCASTER
            // Display LocalSurfaceView.
            setupLocalVideo()
            localSurfaceView?.visibility = View.VISIBLE
            // Start local preview.
            agoraEngine?.startPreview()
            // Join the channel with a temp token.
            // You need to specify the user ID yourself, and ensure that it is unique in the channel.
            agoraEngine?.joinChannel(token, channelName, uid, options)
            binding.connect.visibility = View.GONE
//            binding.time.visibility = View.GONE
            binding.leave.visibility = View.VISIBLE
            binding.controls.visibility = View.VISIBLE
        } else {
            Toast.makeText(applicationContext, "Permissions was not granted", Toast.LENGTH_SHORT)
                .show()
        }
    }

    fun ReviewAndRating() {
        // on below line we are creating a new bottom sheet dialog.
        bottomdialog = BottomSheetDialog(this)
        // on below line we are inflating a layout file which we have created.
        val view = layoutInflater.inflate(R.layout.astro_review_and_rating, null)
        val metrics = DisplayMetrics()
        windowManager?.defaultDisplay?.getMetrics(metrics)
        bottomdialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomdialog.behavior.peekHeight = metrics.heightPixels

        names = view.findViewById(R.id.name)
        expertise = view.findViewById(R.id.expertise)
        language = view.findViewById(R.id.language)
        experience = view.findViewById(R.id.experience)
        image = view.findViewById(R.id.iv_image)
        var btnSubmit = view.findViewById<AppCompatButton>(R.id.btnSubmit)
        var rating_complete = view.findViewById<RatingBar>(R.id.rating_complete)
        var etReason = view.findViewById<EditText>(R.id.etReason)
        var cancel = view.findViewById<ImageView>(R.id.cancel)
//        name.text = user_name.toString()
//        charge.text = charges.toString()
//        time.text = times.toString()
//        Glide.with(requireContext()).load(profiles).into(image)


        if (CommonUtils.isInternetAvailable(this@LiveActivity)) {
            viewModel.strologer_details(
                "Bearer " + userPref.getToken().toString(),
                astro_id.toString()
            )

        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this@LiveActivity, "Please check internet connection.")
        }

        cancel.setOnClickListener {
            bottomdialog.dismiss()
            finish()
        }
        viewModel.astrorahiResponse.observe(this) {
            if (it.status == 1) {
                names.text = it.data?.name.toString()
                expertise.text = it.data?.expertise.toString()
                language.text = it.data?.language.toString()
                experience.text = "Exp: " + it.data?.experence.toString()
                Glide.with(this).load(it.data?.profile).into(image)
            }
        }
        viewModel.givereviewResponse.observe(this) {
            if (it.status == 1) {
                finish()
            } else {
                snackbar(it.message.toString())
            }
        }

        btnSubmit.setOnClickListener {
            if (rating_complete.rating.toInt().equals(0)){
                toast(this@LiveActivity,"Please rate to our astrologer.")
            }else {
                if (CommonUtils.isInternetAvailable(this@LiveActivity)) {
                    viewModel.user_give_review(
                        "Bearer " + userPref.getToken().toString(),
                        astro_id.toString(),
                        rating_complete.rating.toString(),
                        etReason.text.toString(),
                    )

                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this@LiveActivity, "Please check internet connection.")
                }
            }


        }
        bottomdialog.setCancelable(false)

        // on below line we are setting
        // content view to our view.
        bottomdialog.setContentView(view)

        // on below line we are calling
        // a show method to display a dialog.
        bottomdialog.show()


    }

    fun leaveChannel() {
//        if (!isJoined) {
//            showMessage("Join a channel first")
//        } else {
        try{
            agoraEngine!!.leaveChannel()
//            finish()
            showMessage("You left the channel")
            // Stop remote video rendering.
            if (remoteSurfaceView != null) remoteSurfaceView!!.visibility = View.GONE
            // Stop local video rendering.
            if (localSurfaceView != null) localSurfaceView!!.visibility = View.GONE
            isJoined = false
        }catch (e:Exception){
            e.printStackTrace()
        }

//        finish()
//        }
//        audienceRole!!.isEnabled = true // Enable the switch
    }

    override fun onDestroy() {
        super.onDestroy()
        setupVideoSDKEngine()
        LiveEnd()
        if (CommonUtils.isInternetAvailable(this@LiveActivity)) {
            viewModel.live_astrologer_user(
                "Bearer " + userPref.getToken().toString(),
                astro_id,
                channelName,
                "0"
            )
        } else {
            toast(this@LiveActivity, "Please check internet connection.")
        }
        leaveChannel()
    }
    private fun LiveStart() {
        viewModel.when_call_start(
            "Bearer " + userPref.getToken().toString(),
            astro_id.toString()
            /* userPref.getChannelName().toString()*/
        )
    }

    private fun LiveEnd() {

        if (CommonUtils.isInternetAvailable(this@LiveActivity)) {
            viewModel.live_end(
                "Bearer " + userPref.getToken().toString(),
                callTimerText?.text.toString(), astro_id, userPref.getid().toString(), "live"
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this@LiveActivity, "Please check internet connection.")
        }


    }

    override fun onBackPressed() {
        super.onBackPressed()
        setupVideoSDKEngine()
        LiveEnd()
        if (CommonUtils.isInternetAvailable(this@LiveActivity)) {
            viewModel.live_astrologer_user(
                "Bearer " + userPref.getToken().toString(),
                astro_id,
                channelName,
                "0"
            )
        } else {
            toast(this@LiveActivity, "Please check internet connection.")
        }
        leaveChannel()
    }

    override fun OnItemClick(position: Int, id: String, price: String) {
//        toast(this@LiveActivity,WalletMoney.toString())
        if (flag == true){
            if (WalletMoney < price.toInt()) {
                toast(this@LiveActivity, "You have not sufficient balence. Please recharge.")
            } else {
                if (CommonUtils.isInternetAvailable(this@LiveActivity)) {
                    var Calculatetime1 = Calculatetime - (price.toInt() / calling_charg.toInt())
                    if (Calculatetime1 > 0) {
                        Calculatetime = Calculatetime1
//                        toast(this,Calculatetime.toString())
                        viewModel.user_send_gifts(
                            "Bearer " + userPref.getToken().toString(),
                            id.toString(),
                            astro_id,
                            channelName
                        )
                    } else {
                        toast(this@LiveActivity, "You have not sufficient balence. Please recharge.")
                    }
                } else {
                    toast(this@LiveActivity, "Please check internet connection.")
                }
            }
        }else{
            if (WalletMoney > price.toInt()) {
                viewModel.user_send_gifts(
                    "Bearer " + userPref.getToken().toString(),
                    id.toString(),
                    astro_id,
                    channelName
                )
            } else {
                toast(this@LiveActivity, "You have not sufficient balence. Please recharge.")
            }
        }
    }

//    override fun onStop() {
//        super.onStop()
//        LiveEnd()
//    }
}