package com.callastrouser.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.KundaliListAdapter
import com.callastrouser.adapter.ViewPagerKundliAdapter
import com.callastrouser.databinding.ActivityKundaliListBinding
import com.callastrouser.databinding.FragmentGoLiveBinding
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class KundaliList : BaseActivity() {
    lateinit var binding: ActivityKundaliListBinding
    lateinit var adapter:KundaliListAdapter
    lateinit var kundali:String
    private var kundliviewpagerAdapter: ViewPagerKundliAdapter?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kundali_list)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_kundali_list)

        if (intent!=null){
            kundali= intent.getStringExtra("kundli").toString()
        }

        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Kundli Form"
        setTab()
    }
    private fun setTab() {
        kundliviewpagerAdapter = ViewPagerKundliAdapter(supportFragmentManager)
        binding.viewPager.adapter = kundliviewpagerAdapter
        binding.tabLayout.setupWithViewPager(binding.viewPager)
        binding.tabLayout.getChildAt(0)
    }
}