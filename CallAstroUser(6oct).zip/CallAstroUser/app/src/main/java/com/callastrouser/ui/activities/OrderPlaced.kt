package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.callastrouser.MainActivity
import com.callastrouser.R
import com.callastrouser.databinding.ActivityOrderPlacedBinding
import com.maxtra.callastro.baseClass.BaseActivity

class OrderPlaced : BaseActivity() {
    lateinit var orderid :String
    lateinit var productName :String
    lateinit var totalItem :String
    lateinit var expactDeliveryDate :String
    lateinit var orderStatus :String
    lateinit var binding: ActivityOrderPlacedBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_placed)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_order_placed)

        if (intent != null){
            orderid = intent.getStringExtra("orerid").toString()
            productName = intent.getStringExtra("productname").toString()
            totalItem = intent.getStringExtra("totalitems").toString()
            expactDeliveryDate = intent.getStringExtra("expactDeliveryDate").toString()
            orderStatus= intent.getStringExtra("orderstatus").toString()
        }
        binding.orderid.text = orderid
        binding.productname.text = productName
        binding.totalItems.text = totalItem
        binding.estimateddate.text = expactDeliveryDate
        if (orderStatus == "1"){
            binding.orderstatus.text = "Order Placed"
        }else if (orderStatus == "2"){
            binding.orderstatus.text = "Accepted"
        }else if (orderStatus == "3"){
            binding.orderstatus.text = "Cancel"
        }else if (orderStatus == "4"){
            binding.orderstatus.text = "Out for delivery"
        }else if (orderStatus == "5"){
            binding.orderstatus.text = "Pending"
        }else if (orderStatus == "6"){
            binding.orderstatus.text = "Delivered"
        }else if (orderStatus == "7"){
            binding.orderstatus.text = "Rejected"
        }
        binding.stackclear.setOnClickListener {
            var intent = Intent(this@OrderPlaced, MainActivity::class.java)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }
}