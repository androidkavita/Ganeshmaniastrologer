package com.callastrouser.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.GiftBinding
import com.callastrouser.databinding.GiftLayoutBinding
import com.callastrouser.databinding.LivecommentBinding
import com.callastrouser.model.GetGiftResponse
import com.callastrouser.model.GetGiftResponseData
import com.callastrouser.model.LiveCommentsModelClassData
import com.maxtra.callastro.prefs.UserPref

class GiftListAdapter (
    var context: Context, var arrayList:ArrayList<GetGiftResponseData>,var click:Click
) :
    RecyclerView.Adapter<GiftListAdapter.Holder>() {
    lateinit var thelastmessage:String
    lateinit var userPref: UserPref
    var lastmessage=""
    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        var binding: GiftLayoutBinding = DataBindingUtil.bind(itemView)!!
//        var card_item_click = itemView.card_item_click
//        var tv_name_person = itemView.tv_name_person
//        var person_image = itemView.person_image
//        var message = itemView.message

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.gift_layout, parent, false)
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val list=arrayList[position]
        holder.binding.productname.text = list.name
        holder.binding.productprise.text = "₹"+list.price
        Glide.with(context).load(list.image).into(holder.binding.ivImage)
        holder.binding.mainItem.setOnClickListener {
            click.OnItemClick(position,list.id.toString(),list.price.toString())
        }

    }

    override fun getItemCount(): Int {
        return arrayList.size
    }


    interface Click {
        fun OnItemClick(position: Int,id:String,price:String)
    }


}