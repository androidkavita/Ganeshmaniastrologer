package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.AstrorahiResponse
import com.callastrouser.model.AvailabilityResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AstrologerViewModel  @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    val _progressBarVisibility = MutableLiveData<Int>()
    val astrorahiResponse = MutableLiveData<AstrorahiResponse>()
    val availabilityResponse = MutableLiveData<AvailabilityResponse>()


    fun strologer_details(
        token:String,
        id:String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.strologer_details(token,id)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    astrorahiResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
    }

    fun strologer_availability(
        token:String,
        id:String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.strologer_availability(token,id)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    availabilityResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
    }


}