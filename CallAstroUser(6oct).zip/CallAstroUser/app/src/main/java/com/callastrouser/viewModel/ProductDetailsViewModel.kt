package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.CartCountResponse
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.ProductResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProductDetailsViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {

    val progressBarStatus = MutableLiveData<Boolean>()
    val commonResponse = MutableLiveData<CommonResponse>()
    val cartcountResponse = MutableLiveData<CartCountResponse>()
    val ProductResponse = MutableLiveData<ProductResponse>()

    fun ProductDetails(
        token: String,
        id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.ProductDetails(token,id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                ProductResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun cart_item_count(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.cart_item_count(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                cartcountResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun add_to_cart(
        token: String,
        product_id: String,
        type: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.add_to_cart(token,product_id,type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }


    }


}