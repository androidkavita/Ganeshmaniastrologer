package com.callastrouser.ui.activities

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.adapter.AvailabilityAdapter
import com.callastrouser.databinding.ActivityAvailabilityBinding
import com.callastrouser.model.CalendarAvailability
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.AstrologerViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AvailabilityActivity :  BaseActivity() {
    private lateinit var binding : ActivityAvailabilityBinding
    val viewModel : AstrologerViewModel by viewModels()
    lateinit var astrologerid:String
    lateinit var adapter : AvailabilityAdapter
    var List:ArrayList<CalendarAvailability> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_availability)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        if (intent!=null){
            astrologerid = intent.getStringExtra("astrologerid").toString()
        }
        binding.header.tvHeadName.text = "Availability"
        binding.header.backArrow.setOnClickListener {
            finish()
        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.strologer_availability(
                "Bearer " + userPref.getToken().toString(),
                astrologerid
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.availabilityResponse.observe(this){
            if (it.status == 1){
                Glide.with(this@AvailabilityActivity).load(it.data?.profile?.profile).into(binding.Image)
                binding.name.text = it.data?.profile?.name
                List.clear()
                List.addAll(it.data!!.calendarAvailability)
                adapter = AvailabilityAdapter(this@AvailabilityActivity,List)
                binding.rvMypayments.adapter = adapter
            }
        }
    }
}