package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class IntakeResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : IntakeResponseData?   = IntakeResponseData()
)
data class IntakeResponseData(
    @SerializedName("type"               ) var type              : Int?    = null,
    @SerializedName("user_id"            ) var userId            : Int?    = null,
    @SerializedName("dob"                ) var dob               : String? = null,
    @SerializedName("birth_time"         ) var birthTime         : String? = null,
    @SerializedName("place_birth"        ) var placeBirth        : String? = null,
    @SerializedName("occupation"         ) var occupation        : String? = null,
    @SerializedName("maritial_status"    ) var maritialStatus    : String? = null,
    @SerializedName("topic_consultation" ) var topicConsultation : String? = null
)