package com.callastrouser.ui.activities

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.ActivityViewReportBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.GetReportViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ViewReport : BaseActivity() {
    lateinit var binding: ActivityViewReportBinding
    lateinit var id:String
    private val viewModel: GetReportViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_report)

        binding = DataBindingUtil.setContentView(this,R.layout.activity_view_report)
        binding.header.tvHeadName.text = "View Report"
        binding.header.backArrow.setOnClickListener { finish() }

        if (intent !=null){
            id = intent.getStringExtra("id").toString()
        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.view_report_doc_upload(
                "Bearer "+userPref.getToken().toString(),id
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.reportsHistoryResponse.observe(this){
            if (it.status == 1){
                binding.rawdata.text = it.data.text
                Glide.with(this@ViewReport).load(it.data.profile).into(binding.ivImage)
                binding.tvName.text = it.data.name

                var startDate: String = it.data.created_at.toString()
                var splitLink = startDate.split(" ").toTypedArray()
                var start = splitLink[0]
                var end = splitLink[1]
                var link = it.data.file
                binding.date.text = start
                binding.download.setOnClickListener {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                }

//                Listdata.clear()
//                Listdata.addAll(it.data)
//                adapter = GetDetailsReportAdapter(this@SelectReportType,Listdata,this)
//                binding.rvAstrologers.adapter = adapter
            }
        }


    }
}