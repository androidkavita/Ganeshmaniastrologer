package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class WalletResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : WalletResponseData?   = WalletResponseData()
)
data class WalletResponseData(
    @SerializedName("name"                ) var name               : String? = null,
    @SerializedName("wallet"              ) var wallet             : String? = null,
    @SerializedName("transaction_history" ) var transactionHistory : String? = null

)