package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.AstrologersListViewAllResponse
import com.callastrouser.model.BannerResponse
import com.callastrouser.model.CategoryProductResponse
import com.callastrouser.model.ChatAcceptedResponse
import com.callastrouser.model.ChatFragmentResponse
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.ExpertizeResponse
import com.callastrouser.model.LiveAstrologerResponse
import com.callastrouser.model.LiveastrologerviewallResponse
import com.callastrouser.model.ShopwithusViewallResponse
import com.callastrouser.model.ViewProfile
import com.callastrouser.model.WaitingListResponse
import com.callastrouser.util.NoInternetException
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    val loginAstrologersResponse = MutableLiveData<LiveAstrologerResponse>()
    val bannerResponse = MutableLiveData<BannerResponse>()
    val expertizeResponse = MutableLiveData<ExpertizeResponse>()
    val chatResponse = MutableLiveData<ChatFragmentResponse>()
    val shopwithusviewallResponse = MutableLiveData<ShopwithusViewallResponse>()
    val liveastrologersviewallResponse = MutableLiveData<LiveastrologerviewallResponse>()
    val categoryproductResponse = MutableLiveData<CategoryProductResponse>()
    val astrologerviewallResponse = MutableLiveData<AstrologersListViewAllResponse>()
    val waitingResponse = MutableLiveData<WaitingListResponse>()
    val commonResponse = MutableLiveData<CommonResponse>()
    val cancelResponse = MutableLiveData<CommonResponse>()
    val chatacceptedResponse = MutableLiveData<ChatAcceptedResponse>()
    val viewProfileResponse = MutableLiveData<ViewProfile>()
    fun LiveAstrologers(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.liveAstrologers(token)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    loginAstrologersResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }


        }

    }

    fun add_to_cart(
        token: String,
        product_id: String,
        type: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            try {
                val response =
                    mainRepository.add_to_cart(token,product_id,type)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    commonResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }


    }


    fun ViewProfile(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.ViewProfile(token)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    viewProfileResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }


    }

    fun Banner(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.banner(token)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    bannerResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }

    }


    fun Expertize(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.Expertize(token)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    expertizeResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }

    }


    fun Shopwithusviewall(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.ShopwithusViewall(token)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    shopwithusviewallResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }

    }


    fun Liveastrologersviewall(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.Liveastrologersviewall(token)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    liveastrologersviewallResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }

    }


    fun Chat(
        token: String,
        expertise_id: String,
        sort_filter: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {

                val response =
                    mainRepository.Chat(token,expertise_id,sort_filter)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    chatResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }

    }


    fun Call(
        token: String,
        expertise_id: String,
        sort_filter: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.Call(token,expertise_id,sort_filter)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    chatResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }

    }

    fun CategoryList(
        token: String,
        id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.CategoryList(token, id)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    categoryproductResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }
        }
    }

    fun strologers_list(
        token: String,
        ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.strologers_list(token)
            try {
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    astrologerviewallResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }
    }

    fun waiting_chat_list(
        token: String,
    ) {
//        progressBarStatus.value = true
        viewModelScope.launch {

            try {
                val response =
                    mainRepository.waiting_chat_list(token)
                if (response.isSuccessful) {
//                    progressBarStatus.value = false
                    waitingResponse.postValue(response.body())
                } else {
//                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }
    }

    fun waiting_call_list(
        token: String,
    ) {
//        progressBarStatus.value = true
        viewModelScope.launch {

            try {
                val response =
                    mainRepository.waiting_call_list(token)
                if (response.isSuccessful) {
//                    progressBarStatus.value = false
                    waitingResponse.postValue(response.body())
                } else {
//                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }
    }

    fun chat_cancel_by_user(
        token: String,
        id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.chat_cancel_by_user(token,id)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    cancelResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }
    }

    fun call_cancel_by_user(
        token: String,
        id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            try {
                val response =
                    mainRepository.call_cancel_by_user(token,id)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    cancelResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }
    }

    fun chat_accepted(
        token: String,
    ) {
//        progressBarStatus.value = true
        viewModelScope.launch {

            try {
                val response =
                    mainRepository.chat_accepted(token)
                if (response.isSuccessful) {
//                progressBarStatus.value = false
                    chatacceptedResponse.postValue(response.body())
                } else {
//                progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }
    }


    fun call_accepted(
        token: String,
    ) {
//        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.call_accepted(token)
                if (response.isSuccessful) {
//                progressBarStatus.value = false
                    chatacceptedResponse.postValue(response.body())
                } else {
//                progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }
    }


//    suspend fun maritials_list(): Response<MaritalStatusList>




    fun requests_wait_delete(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.requests_wait_delete(token)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    commonResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }catch (e: NoInternetException) {
                e.printStackTrace()
            }

        }
    }



}