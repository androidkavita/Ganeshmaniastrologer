package com.callastrouser.ui.activities

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.ActivityGiveReviewConsultancyBinding
import com.callastrouser.model.ConsultancyDetailData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.OrderDetailsViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class GiveReviewConsultancy : BaseActivity() {
    lateinit var binding: ActivityGiveReviewConsultancyBinding
    private val viewModel: OrderDetailsViewModel by viewModels()
    lateinit var product:String
    var data : ConsultancyDetailData? = null
    lateinit var name : String
    lateinit var date : String
    lateinit var booking_id : String
    lateinit var expertise : String
    lateinit var image : String
    lateinit var experience : String
    lateinit var language : String
    lateinit var astroid : String
//    lateinit var flag:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_give_review_consultancy)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_give_review_consultancy)

        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Give Review"

    if (intent!=null){
        name = intent.getStringExtra("name").toString()
        date = intent.getStringExtra("date").toString()
        booking_id = intent.getStringExtra("bookingid").toString()
        expertise = intent.getStringExtra("experties").toString()
        image = intent.getStringExtra("image").toString()
        experience = intent.getStringExtra("experience").toString()
        language = intent.getStringExtra("language").toString()
        astroid = intent.getStringExtra("astroid").toString()
    }
    binding.name.text = name
    binding.expertise.text = expertise
    binding.language.text = language
    binding.experience.text = "Exp: $experience"
    binding.date.text = date
    binding.bookingid.text = booking_id

    Glide.with(this@GiveReviewConsultancy).load(image).into(binding.ivImage)
    binding.btnSubmit.setOnClickListener {

        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.user_give_review(
                "Bearer "+userPref.getToken().toString(),
                astroid,binding.ratingComplete.rating.toString(),binding.etReason.text.toString(),
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

    }

    viewModel.progressBarStatus.observe(this) {
        if (it) {
            showProgressDialog()
        } else {
            hideProgressDialog()
        }
    }

    viewModel.givereviewResponse.observe(this){
        if (it.status == 1){
            Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
            finish()

        }else{
            snackbar(it.message.toString())
        }
    }



    }
}