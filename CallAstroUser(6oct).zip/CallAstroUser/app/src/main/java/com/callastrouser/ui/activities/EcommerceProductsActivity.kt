package com.callastrouser.ui.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.ViewPagerEcommerceProductsAdapter
import com.callastrouser.databinding.ActivityEcommerceProductsBinding
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class EcommerceProductsActivity : BaseActivity() {
    private lateinit var binding : ActivityEcommerceProductsBinding
    private var ecommerceProductsAdapter: ViewPagerEcommerceProductsAdapter?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_ecommerce_products)
        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Ecommerce Products"
        setTab()

    }
    private fun setTab() {
        ecommerceProductsAdapter = ViewPagerEcommerceProductsAdapter(supportFragmentManager)
        binding.viewPager.adapter = ecommerceProductsAdapter
        binding.tabLayout.setupWithViewPager(binding.viewPager)
        binding.tabLayout.getChildAt(0)
    }
}