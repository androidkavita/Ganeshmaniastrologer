package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.AstrologersListViewAllResponse
import com.callastrouser.model.GetAstroDetailsResponse
import com.callastrouser.model.ViewReportResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class GetReportViewModel @Inject constructor( private val mainRepository: MainRepository):ViewModel(){

    val progressBarStatus = MutableLiveData<Boolean>()
    val astrologerviewallResponse = MutableLiveData<AstrologersListViewAllResponse>()
    val getAstroDetailsResponse = MutableLiveData<GetAstroDetailsResponse>()
    val reportsHistoryResponse = MutableLiveData<ViewReportResponse>()

    fun get_report_astro_list(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.get_report_astro_list(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                astrologerviewallResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }
    fun get_report_astro_details(
        token: String,
        id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.get_report_astro_details(token,id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                getAstroDetailsResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun view_report_doc_upload(
        token: String,
        id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.view_report_doc_upload(token,id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                reportsHistoryResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


}
