package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.MissedCallChatBinding
import com.callastrouser.model.MissedCallChatResponseData

class MissedAdapter (val context : Context, var data: ArrayList<MissedCallChatResponseData>) :
    RecyclerView.Adapter<MissedAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: MissedCallChatBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MissedAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.missed_call_chat, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MissedAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.astroName
        holder.binding.date.text = List.requestDate.toString()
        holder.binding.time.text = List.requestTime.toString()
        Glide.with(context).load(List.astroProfile).into(holder.binding.image)
        if (List.type == 1){
            holder.binding.imagemissed.visibility = View.GONE
            holder.binding.missed.text = "Chat Missed"
        }else{
            holder.binding.imagemissed.visibility = View.VISIBLE
            holder.binding.missed.text = "Call Missed"
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }

}