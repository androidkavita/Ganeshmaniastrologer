package com.callastrouser.adapter
import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowRemedySuggestedBinding
import com.callastrouser.model.RemedySuggestedData

class SuggestedAdapter (val context : Context, var data: ArrayList<RemedySuggestedData>) :
    RecyclerView.Adapter<SuggestedAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowRemedySuggestedBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SuggestedAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_remedy_suggested, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: SuggestedAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.tvHead.text = List.astroName.toString()
        holder.binding.rawdata.text = List.suggest.toString()
//        holder.binding.money.text = List.
        Glide.with(context).load(List.astroProfile).into(holder.binding.ivImage)
    }

    override fun getItemCount(): Int {
        return data.size
    }
}
