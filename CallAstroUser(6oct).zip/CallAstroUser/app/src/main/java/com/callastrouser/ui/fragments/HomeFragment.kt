package com.callastrouser.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.R
import com.callastrouser.adapter.AstrologersAdapter
import com.callastrouser.adapter.AstrologersList
import com.callastrouser.adapter.BannerAdapter
import com.callastrouser.adapter.ClickMe
import com.callastrouser.adapter.LiveAstro
import com.callastrouser.adapter.LiveAstrologerAdapter
import com.callastrouser.adapter.Shops
import com.callastrouser.adapter.ShopwithUsAdapter
import com.callastrouser.adapter.StoriesAdapter
import com.callastrouser.databinding.FragmentHomeBinding
import com.callastrouser.model.BannerResponseData
import com.callastrouser.model.Blogs
import com.callastrouser.model.LiveStrologers
import com.callastrouser.model.Shopwithus
import com.callastrouser.model.StrologersList
import com.callastrouser.ui.activities.AstrologerProfileActivity
import com.callastrouser.ui.activities.AstrologersListViewAll
import com.callastrouser.ui.activities.EnterKundaliDetails
import com.callastrouser.ui.activities.KundaliList
import com.callastrouser.ui.activities.LiveActivity
import com.callastrouser.ui.activities.LiveastrologerViewall
import com.callastrouser.ui.activities.ShopWithUsItem
import com.callastrouser.ui.activities.ShopwithUsViewall
import com.callastrouser.ui.activities.StoryView
import com.callastrouser.ui.activities.StoryViewAll
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.toast
import com.callastrouser.viewModel.HomeViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.util.ArrayList

@AndroidEntryPoint
class HomeFragment : BaseFragment(), Shops, AstrologersList, LiveAstro, ClickMe {
    lateinit var binding:FragmentHomeBinding
    private val viewModel: HomeViewModel by viewModels()
    lateinit var adapter : LiveAstrologerAdapter
    lateinit var Astrologers : AstrologersAdapter
    lateinit var ShopwithUs : ShopwithUsAdapter
    lateinit var adapter2 : BannerAdapter
    lateinit var storiesAdapter : StoriesAdapter
    var Listdata: ArrayList<LiveStrologers> = ArrayList()
    var Listdata2: ArrayList<StrologersList> = ArrayList()
    var Listdata3: ArrayList<Shopwithus> = ArrayList()
    var Listdata4: ArrayList<BannerResponseData> = ArrayList()
    var Listdata5: ArrayList<Blogs> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentHomeBinding.inflate(inflater,container,false)

        binding.tvLiveAstrologersViewall.setOnClickListener {
            var intent = Intent(requireContext(), LiveastrologerViewall::class.java)
            startActivity(intent)
        }
        binding.tvAstrologersViewall.setOnClickListener {
            var intent = Intent(requireContext(), AstrologersListViewAll::class.java)
            startActivity(intent)
        }
        binding.tvEshopViewall.setOnClickListener {
            var intent = Intent(requireContext(), ShopwithUsViewall::class.java)
            startActivity(intent)
        }
        binding.StoriesAll.setOnClickListener {
            var intent = Intent(requireContext(), StoryViewAll::class.java)
            startActivity(intent)
        }
        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        binding.swipeRefreshlayout.setOnRefreshListener {
            if (CommonUtils.isInternetAvailable(requireContext())) {
                viewModel.LiveAstrologers(
                    "Bearer "+userPref.getToken().toString()
                )
                viewModel.Banner(
                    "Bearer "+userPref.getToken().toString()
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
//                snackBar(binding.root,"Please check internet connection.")
                toast("Please check internet connection.")
            }

            binding.swipeRefreshlayout.isRefreshing = false
        }




        viewModel.bannerResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                Listdata4.clear()
//                Listdata4.addAll(it.data!!)
                for (i in 0 until it.data.size){
                    Listdata4.add(it.data[i])
                }
                adapter2 = BannerAdapter(Listdata4)
                binding.imageSlider.setSliderAdapter(adapter2)
            } else {
//                toast(it.message.toString())
            }
        }

        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.LiveAstrologers(
                "Bearer "+userPref.getToken().toString()
            )
            viewModel.Banner(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
//            snackBar(binding.root,"Please check internet connection.")
            toast("Please check internet connection.")
        }


        viewModel.loginAstrologersResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                Listdata.clear()
                Listdata2.clear()
                Listdata3.clear()
                Listdata5.clear()
                Listdata.addAll(it.data!!.liveStrologers)
                Listdata2.addAll(it.data!!.strologersList)
                Listdata3.addAll(it.data!!.shopwithus)
                Listdata5.addAll(it.data!!.blogs)
                adapter = LiveAstrologerAdapter(requireContext(), Listdata,this)
                binding.rvLiveAstrologers.adapter =adapter
                Astrologers= AstrologersAdapter(requireContext(), Listdata2,this)
                binding.rvAstrologers.adapter =Astrologers
                ShopwithUs= ShopwithUsAdapter(requireContext(), Listdata3,this)
                binding.rvTrendMostbuyList.adapter =ShopwithUs
                storiesAdapter = StoriesAdapter(requireContext(),Listdata5,this)
                binding.rvStories.adapter = storiesAdapter
                userPref.setProfile(it.data!!.profile.toString())
                userPref.setName(it.data!!.name.toString())
            } else {
//                toast(it.message.toString())
            }
        }

        binding.matchkindali.setOnClickListener {
            startActivity(Intent(requireContext(),KundaliList::class.java).putExtra("kundli","makekundali"))

        }

//        binding.makekindali.setOnClickListener {
//            startActivity(Intent(requireContext(), EnterKundaliDetails::class.java))
//        }
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.LiveAstrologers(
                "Bearer "+userPref.getToken().toString()
            )
            viewModel.Banner(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
//            snackBar(binding.root,"Please check internet connection.")
            toast("Please check internet connection.")
        }
    }

    override fun layoutid(layout: LinearLayout, id: String, name: String) {
        layout.setOnClickListener {
            var intent = Intent(requireContext(), ShopWithUsItem::class.java)
            intent.putExtra("id",id)
            intent.putExtra("name",name)
            startActivity(intent)
        }
    }

    override fun astrologer(layout: LinearLayout, id: String, name: String) {
        layout.setOnClickListener {
            var intent = Intent(requireContext(), AstrologerProfileActivity::class.java)
            intent.putExtra("id",id)
            intent.putExtra("name",name)
            startActivity(intent)
        }
    }

    override fun Click(layout: LinearLayout, id: String, channelName: String, agoraToken: String,name:String,Profile:String,calling_charg:String) {
        layout.setOnClickListener {
//            val bundle = Bundle()
//            bundle.putString("channelname",channelName)
//            bundle.putString("agora_token",agoraToken)
//            val fragobj = GoLiveFragment()
//            fragobj.setArguments(bundle)
//            fragmentManager?.beginTransaction()?.replace(
//                R.id.flContent,
//                fragobj, "Payment"
//            )?.addToBackStack(null)?.commit()

            startActivity(Intent(requireContext(),LiveActivity::class.java)
                .putExtra("channelname",channelName)
                .putExtra("agora_token",agoraToken)
                .putExtra("name",name)
                .putExtra("id",id)
                .putExtra("profile",Profile)
                .putExtra("calling_charg",calling_charg)

//                .putExtra("channelname",channelName)
            )
        }


    }

    override fun layoutclick(linear: LinearLayout, id: String) {
        linear.setOnClickListener{
        startActivity(Intent(requireContext(), StoryView::class.java).putExtra("id",id))
        }
    }
}