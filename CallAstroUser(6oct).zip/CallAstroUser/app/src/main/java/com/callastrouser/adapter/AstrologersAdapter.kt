package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowAstrologersBinding
import com.callastrouser.model.StrologersList

class AstrologersAdapter (val context : Context, var data: ArrayList<StrologersList>, var transfer: AstrologersList) :
    RecyclerView.Adapter<AstrologersAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowAstrologersBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AstrologersAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_astrologers, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: AstrologersAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.name.toString()
        holder.binding.charge.text = "₹${List.calling_charg.toString()}/min"

        if (List.request!!.equals(2)){
            holder.binding.busy.text = "Online(Busy)"
            holder.binding.busy.setTextColor(Color.parseColor("#d32f2f"))
            holder.binding.ivDot.setImageResource(R.drawable.red_dot)
        }else{
            holder.binding.busy.text = "Online"
            holder.binding.busy.setTextColor(Color.parseColor("#145901"))
            holder.binding.ivDot.setImageResource(R.drawable.ic_dot)
        }
//        holder.binding.language.text = List.language.toString()
//        holder.binding.experience.text = List.experence.toString()
//        holder.binding.money.text = List.
        Glide.with(context).load(List.profile).into(holder.binding.image)
        transfer.astrologer(holder.binding.linearItem,List.id.toString(),List.name.toString())
    }

    override fun getItemCount(): Int {
        return data.size
    }
}
interface AstrologersList{
    fun astrologer(layout: LinearLayout, id:String, name:String)
}