package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowPoojaLayoutBinding
import com.callastrouser.model.RemedyPoojaResponseData


class RemedyPoojaAdapter (val context : Context, var data: ArrayList<RemedyPoojaResponseData>/*, var linear:ClickReport*/) :
    RecyclerView.Adapter<RemedyPoojaAdapter.ViewHolder>() {
    lateinit var file :String
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowPoojaLayoutBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RemedyPoojaAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_pooja_layout, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RemedyPoojaAdapter.ViewHolder, position: Int) {
        val List = data[position]
        try {
            holder.binding.name.text = List.title
            Glide.with(context).load(List.thumbNail).into(holder.binding.image)
            holder.binding.description.text = List.description

            holder.binding.download.setOnClickListener {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(List.video)))
            }
        }catch (e:Exception){
            e.printStackTrace()
        }


    }

    override fun getItemCount(): Int {
        return data.size
    }
}