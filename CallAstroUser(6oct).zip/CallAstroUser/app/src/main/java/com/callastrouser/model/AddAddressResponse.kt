package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class AddAddressResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : AddAddressResponseData?   = AddAddressResponseData()
)
data class AddAddressResponseData(
    @SerializedName("id"           ) var id          : Int?    = null,
    @SerializedName("user_id"      ) var userId      : Int?    = null,
    @SerializedName("address_type" ) var addressType : Int?    = null,
    @SerializedName("full_name"    ) var fullName    : String? = null,
    @SerializedName("phone_no"     ) var phoneNo     : String? = null,
    @SerializedName("house_no"     ) var houseNo     : String? = null,
    @SerializedName("area"         ) var area        : String? = null,
    @SerializedName("state"        ) var state       : Int?    = null,
    @SerializedName("city"         ) var city        : Int?    = null,
    @SerializedName("pincode"      ) var pincode     : String? = null,
    @SerializedName("created_at"   ) var createdAt   : String? = null,
    @SerializedName("updated_at"   ) var updatedAt   : String? = null

)