package com.callastrouser.model

data class DThreeChartResponse(
    val output: DThreeChartResponseOutput,
    val statusCode: Int
)

data class DThreeChartResponseOutput(
    val `0`: DThreeChartResponseOutputX0,
    val `1`: DThreeChartResponseOutputX0,
    val `10`: DThreeChartResponseOutputX0,
    val `11`: DThreeChartResponseOutputX0,
    val `12`: DThreeChartResponseOutputX0,
    val `2`: DThreeChartResponseOutputX0,
    val `3`: DThreeChartResponseOutputX0,
    val `4`: DThreeChartResponseOutputX0,
    val `5`: DThreeChartResponseOutputX0,
    val `6`: DThreeChartResponseOutputX0,
    val `7`: DThreeChartResponseOutputX0,
    val `8`: DThreeChartResponseOutputX0,
    val `9`: DThreeChartResponseOutputX0
)

data class DThreeChartResponseOutputX0(
    val current_sign: Int,
    val isRetro: String,
    val name: String
)