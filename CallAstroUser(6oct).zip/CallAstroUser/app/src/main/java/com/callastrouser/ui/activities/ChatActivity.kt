package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.AppCompatButton
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.adapter.ChatAdapter2
import com.callastrouser.databinding.ActivityChatBinding
import com.callastrouser.model.ChatListMessageData
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.toast
import com.callastrouser.viewModel.VideoCallViewModel
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import de.hdodenhof.circleimageview.CircleImageView
import java.text.DecimalFormat
import java.util.*

@AndroidEntryPoint
class ChatActivity : BaseActivity(), View.OnClickListener {
    private lateinit var binding : ActivityChatBinding
    private val  viewModel: VideoCallViewModel by viewModels()
    private val messageList: ArrayList<ChatListMessageData> = ArrayList<ChatListMessageData>()
    private val SPLASH_TIMEOUT: Long = 1000
    val handlerStatusCheck = Handler(Looper.getMainLooper())
    var runnableStatusCheck: Runnable? = null
    var chatAdapter: ChatAdapter2? = null
    var userId = ""
    var astroname = ""
    var appid = ""
    var token = ""
    private var callTimer: Timer? = null
    private var callTimerText: TextView? = null
    private var counter = 0
    var channel_name = ""
    var isscrollable = false
    lateinit var apitimer :String
    var astroid: String? = null
    private var WalletMoney: Int = 0
    private var CallingCharge: Int = 0
    private var Calculatetime: Int = 0
    private var Minimumbalence: Int = 0
    var count :Int = 0
    var caller_id: String? = null
//    private var callTimer: Timer? = null
    val handlerCallEndStatusCheck = Handler(Looper.getMainLooper())
    var runnableCallEndStatusCheck: Runnable? = null
//    private var counter = 0
    var finalstate:String = "1"
    lateinit var bottomdialog: BottomSheetDialog
    lateinit var name :TextView
    lateinit var expertise :TextView
    lateinit var language :TextView
    lateinit var experience :TextView
    lateinit var image :CircleImageView
    var isclick:Boolean = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_chat)
        callTimer = Timer()
        if (intent != null) {
            userId = intent.getStringExtra("astroid").toString()
            appid = intent.getStringExtra("app_id").toString()
            token = intent.getStringExtra("agora_token").toString()
            channel_name = intent.getStringExtra("channel_name").toString()
            astroname = intent.getStringExtra("astroname").toString()
            caller_id = intent.getStringExtra("caller_id")
            astroid = intent.getStringExtra("astroid")

        }
        userPref.setmessageContain("MESSAGE")
        binding.backArrow.setOnClickListener {
//            chat_end()
            AlertdialogExit()
        }
        binding.tvHeadName.text = astroname
        binding.rvUserChat.isVerticalScrollBarEnabled = isscrollable != false
        isscrollable = true
        moveForward()
        messageList()
        CallStart()
        handlerCallEndStatusCheck.postDelayed(Runnable { //do // something
            if (CommonUtils.isInternetAvailable(this@ChatActivity)) {
                handlerCallEndStatusCheck.postDelayed(runnableCallEndStatusCheck!!, 5000)
                viewModel.check_chat_end(
                    "Bearer "+userPref.getToken().toString(), caller_id.toString()
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast(this,"Please check internet connection.")
            }
        }.also { runnableCallEndStatusCheck = it }, 0)
        viewModel.callStartResponse.observe(this){
            if (it.status == 1){
                WalletMoney = it.data?.wallet!!.toInt()
                CallingCharge = it.data?.callingCharg!!.toInt()
                Calculatetime = (WalletMoney/CallingCharge)*60
                Minimumbalence = CallingCharge*5
                if(WalletMoney < Minimumbalence){
//                    toast(this@AudioCallActivity,"you don't have enough balence.")
                    Alertdialog()
                }else{
                    startCallTimer()
                    messagedata()
//                    joinChannel(token.toString(),channelName.toString())
                }
            }
        }
        viewModel.agoraChatListMessageResponse.observe(this) {
            if (it.status == 1) {
                isscrollable = false
                messageList.clear()
                messageList.addAll(it.data)
                chatAdapter = ChatAdapter2(this, messageList)
                if (count == 0){
                    binding.rvUserChat.adapter = chatAdapter
                    binding.rvUserChat.scrollToPosition(messageList.size - 1);
                    binding.rvUserChat.smoothScrollToPosition(binding.rvUserChat.adapter!!.itemCount)
                    binding.rvUserChat.stopScroll()
                    chatAdapter!!.notifyDataSetChanged()
                    count = messageList.size
                }else if (count < messageList.size){
                    binding.rvUserChat.adapter = chatAdapter
                    binding.rvUserChat.scrollToPosition(messageList.size - 1);
                    binding.rvUserChat.smoothScrollToPosition(binding.rvUserChat.adapter!!.itemCount)
                    chatAdapter?.notifyDataSetChanged()
                    count = messageList.size
                }
            } else {
                snackbar(it?.message!!)
            }
        }
        binding.ivChatSend.setOnClickListener(this)
        binding.endchat.setOnClickListener(this)

        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                toast(it.message.toString())
                userPref.setmessageContain("")
                ReviewAndRating()
            }
        }


        viewModel.givereviewResponse.observe(this){
            if (it.status == 1){
                finish()
            }else{
                snackbar(it.message.toString())
            }
        }
        viewModel.checkChatEndResponse.observe(this){
            if (it.status == 1){
                if (it.data.is_chat_end == 1){
                    if (finalstate == "1"){
                        chat_end()
                        if (it.data.user_type == 1){
                            Alertdialog1()
                            binding.tvTime.visibility = View.GONE
                        }
                        finalstate = "2"
                    }
                }
            }
        }


        viewModel.astrorahiResponse.observe(this) {
            if (it.status == 1) {
                name.text = it.data?.name.toString()
                expertise.text = it.data?.expertise.toString()
                language.text = it.data?.language.toString()
                experience.text = "Exp: "+it.data?.experence.toString()
                Glide.with(this).load(it.data?.profile).into(image)

            }
        }

    }
    fun ReviewAndRating() {
        // on below line we are creating a new bottom sheet dialog.
        bottomdialog = BottomSheetDialog(this)
        // on below line we are inflating a layout file which we have created.
        val view = layoutInflater.inflate(R.layout.astro_review_and_rating, null)
        val metrics = DisplayMetrics()
        windowManager?.defaultDisplay?.getMetrics(metrics)
        bottomdialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomdialog.behavior.peekHeight = metrics.heightPixels
        name = view.findViewById(R.id.name)
        expertise = view.findViewById(R.id.expertise)
        language = view.findViewById(R.id.language)
        experience = view.findViewById(R.id.experience)
        image = view.findViewById(R.id.iv_image)
        var btnSubmit = view.findViewById<AppCompatButton>(R.id.btnSubmit)
        var rating_complete = view.findViewById<RatingBar>(R.id.rating_complete)
        var etReason = view.findViewById<EditText>(R.id.etReason)
        var cancel = view.findViewById<ImageView>(R.id.cancel)
//        name.text = user_name.toString()
//        charge.text = charges.toString()
//        time.text = times.toString()
//        Glide.with(requireContext()).load(profiles).into(image)

        viewModel.strologer_details(
            "Bearer " + userPref.getToken().toString(),
            astroid.toString()
        )

        cancel.setOnClickListener{
            bottomdialog.dismiss()
            finish()
        }

        btnSubmit.setOnClickListener{
            if (rating_complete.rating.toInt().equals(0)){
                toast(this@ChatActivity,"Please rate to our astrologer.")
            }else {
                if (CommonUtils.isInternetAvailable(this@ChatActivity)) {
                    viewModel.user_give_review(
                        "Bearer " + userPref.getToken().toString(),
                        astroid.toString(),
                        rating_complete.rating.toString(),
                        etReason.text.toString(),
                        caller_id.toString(),
                        "1"
                    )
                } else {
                    toast(this, "Please check internet connection.")
                }
            }

        }
//        var btnNo = view.findViewById<Button>(R.id.btnNo)
//        btnLogout.setOnClickListener {
//            userPref.clearPref()
//            startActivity(Intent(this, LoginActivity::class.java))
//            finishAffinity()
//            bottomdialog.dismiss()
//        }
//        btnNo.setOnClickListener {
//            bottomdialog.dismiss()
//        }
        // below line is use to set cancelable to avoid
        // closing of dialog box when clicking on the screen.
        bottomdialog.setCancelable(false)

        // on below line we are setting
        // content view to our view.
        bottomdialog.setContentView(view)

        // on below line we are calling
        // a show method to display a dialog.
        bottomdialog.show()



    }

    fun AlertdialogExit() {
        val buinder = AlertDialog.Builder(this)

        buinder.setMessage("Are you sure, You want to leave chat.")
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Chat End")
        buinder.setPositiveButton("Yes") { dialogInterface, which ->
            chat_end()
        }
        buinder.setNegativeButton("No") { dialogInterface, which ->
        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(true)
        alertDialog.show()
    }

    fun Alertdialog1(){
        val buinder = AlertDialog.Builder(this)
        buinder.setMessage("Chat has been closed")
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Chat Closed!!")
        buinder.setPositiveButton("OK") { dialogInterface, which ->
//                        val intent = Intent(this, CreateOrder::class.java)
//                        intent.putExtra("POPUP_FLAG", "yes")
//                        startActivity(intent)
            ReviewAndRating()
        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
    fun Alertdialog(){
        val buinder = AlertDialog.Builder(this)
        buinder.setMessage("Your wallet balance is Rs $WalletMoney " +
                "Minimum balance required Rs $Minimumbalence " +
                "To connect Astrologer $astroname Recharge now with following balance")
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Recharge Now!!")
        buinder.setPositiveButton("OK") { dialogInterface, which ->
                        val intent = Intent(this, WalletMoney::class.java)
                        intent.putExtra("POPUP_FLAG", "yes")
                        startActivity(intent)
//            finish()
        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
    private fun startCallTimer() {
//        if (counter< Calculatetime){
        callTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                if (++counter == Calculatetime) counter =
                    0 // for the taluxi app a call must not be longer than 1h.
                val formatter = DecimalFormat("00")
                val timerText =
                    formatter.format((counter / 60).toLong()) + ":" + formatter.format((counter % 60).toLong())
                runOnUiThread {
                    if (counter == 0){
                        if (CommonUtils.isInternetAvailable(this@ChatActivity)) {
                            chat_end()
                        } else {
                            Log.d("TAG", "onCreate: " + "else part")
                            toast(this@ChatActivity,"Please check internet connection.")
                        }

//                        finish()
//                        if (isJoined) {
////                    viewCallStatusApi()
//                            showMessage("You left the channel")
//                            agoraEngine?.leaveChannel()
//                            finish()
//                            isJoined = false
//                            sendBroadcast(Intent(Constant.ACTION_HANG_UP_ANSWERED_CALL))
//
//                        } else {
////                    showMessage("Join a channel first")
//
//                        }
                    }else{
                        apitimer = timerText
                        binding.tvTime.text = timerText
                    }
                }
                Thread.sleep(1000);
            }
        }, 0, 1000)
//        }else{
//            snackbar("you don't have enough balence.")
//        }

    }
    private fun CallStart() {
        if (CommonUtils.isInternetAvailable(this@ChatActivity)) {
            viewModel.when_call_start(
                "Bearer "+userPref.getToken().toString(),
                astroid.toString()
                /* userPref.getChannelName().toString()*/
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

    }
    private fun chat_end() {
        if (CommonUtils.isInternetAvailable(this@ChatActivity)) {
            viewModel.chat_end(
                "Bearer "+userPref.getToken().toString(),
                apitimer,astroid.toString(),userPref.getUserId().toString(),/*caller_id.toString()*/caller_id.toString(),"1"
                /* userPref.getChannelName().toString()*/
            )
        } else {
            toast(this,"Please check internet connection.")
        }


    }
    private fun moveForward() {
        handlerStatusCheck.postDelayed(Runnable { //do // something
            handlerStatusCheck.postDelayed(runnableStatusCheck!!, 5000)
            messageList()
        }.also { runnableStatusCheck = it }, 0)
    }

    fun messageList() {
        if (CommonUtils.isInternetAvailable(this@ChatActivity)) {
            viewModel.chat_list_MessageApi("Bearer "+userPref.getToken().toString(), userId.toString())
        } else {
            toast(this,"Please check internet connection.")
        }

    }
    fun messagedata() {
        viewModel.chatAgoraSendResponse.observe(this) {
            if (it.status == 1) {
                isclick = false
                binding.etChatMsg.setText("")
                messageList()
            } else {
                binding.etChatMsg.setText("")
            }
        }
    }
    private fun viewChatAgoraTestResponse() {
        if (CommonUtils.isInternetAvailable(this@ChatActivity)) {
            viewModel.chatagoraApi("Bearer "+userPref.getToken().toString()
                ,userId.toString(),
                binding.etChatMsg.text.toString(),
                "3")
        } else {
            toast(this,"Please check internet connection.")
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        chat_end()
    }

    override fun onDestroy() {
        super.onDestroy()
        chat_end()
    }
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.ivChatSend -> {
                if (binding.etChatMsg.text.toString() == "") {
                    toast(this,"Pls enter text")
                } else {
                    if (isclick == false){
                        viewChatAgoraTestResponse()
                        isclick = true
                    }

                }
            }
            R.id.endchat -> {
                handlerCallEndStatusCheck.removeCallbacks(runnableCallEndStatusCheck!!)
                binding.tvTime.visibility = View.GONE
//                chat_end()
                AlertdialogExit()
//                finish()
            }
        }
    }
}