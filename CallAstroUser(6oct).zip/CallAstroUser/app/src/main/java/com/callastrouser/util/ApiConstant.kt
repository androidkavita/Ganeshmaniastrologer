package com.callastrouser.util

object ApiConstant {

        //Live server url
//        const val BASE_URL = "http://172.16.0.233/~maxdevcallastro/call_astro/api/"
        const val BASE_URL = "http://103.154.2.116/~maxdevcallastro/call_astro/api/"
        const val BASE_URL2 = "https://api.kundli.click/v0.4/"
//        const val BASE_URL = "http://172.16.0.238/~apitest/transport/public/api/"

}
