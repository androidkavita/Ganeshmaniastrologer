package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class LiveAstrologerResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : LiveAstrologerResponseData?   = LiveAstrologerResponseData()
)
data class LiveAstrologerResponseData(
    @SerializedName("id"              ) var id             : Int?                      = null,
    @SerializedName("name"            ) var name           : String?                   = null,
    @SerializedName("profile"         ) var profile        : String?                   = null,
    @SerializedName("live_strologers" ) var liveStrologers : ArrayList<LiveStrologers> = arrayListOf(),
    @SerializedName("strologers_list" ) var strologersList : ArrayList<StrologersList> = arrayListOf(),
    @SerializedName("shopwithus"      ) var shopwithus     : ArrayList<Shopwithus>     = arrayListOf(),
    @SerializedName("blogs"           ) var blogs          : ArrayList<Blogs>          = arrayListOf()
)
data class LiveStrologers(
    @SerializedName("id"      ) var id      : Int?    = null,
    @SerializedName("name"    ) var name    : String? = null,
    @SerializedName("topic"    ) var topic    : String? = null,
    @SerializedName("profile" ) var profile : String? = null,
    @SerializedName("agora_token" ) var agora_token : String? = null,
    @SerializedName("channel_name" ) var channel_name : String? = null,
    @SerializedName("calling_charg" ) var calling_charg : String? = null,
)
data class StrologersList(
    @SerializedName("id"           ) var id          : Int?              = null,
    @SerializedName("name"         ) var name        : String?           = null,
    @SerializedName("experence_id" ) var experenceId : Int?              = null,
    @SerializedName("request" ) var request : Int?              = null,
    @SerializedName("profile"      ) var profile     : String?           = null,
    @SerializedName("expertise"    ) var expertise   : String? = null,
    @SerializedName("calling_charg"    ) var calling_charg   : String? = null,
    @SerializedName("language"     ) var language    : String? = null,
    @SerializedName("experence"    ) var experence   : String?           = null
)
data class Shopwithus(
    @SerializedName("id"             ) var id            : Int?    = null,
    @SerializedName("category_name"  ) var categoryName  : String? = null,
    @SerializedName("category_image" ) var categoryImage : String? = null
)
data class Blogs (

    @SerializedName("id"          ) var id          : Int?    = null,
    @SerializedName("title"       ) var title       : String? = null,
    @SerializedName("description" ) var description : String? = null,
    @SerializedName("image"       ) var image       : String? = null,
    @SerializedName("status"      ) var status      : Int?    = null,
    @SerializedName("created_at"  ) var createdAt   : String? = null,
    @SerializedName("updated_at"  ) var updatedAt   : String? = null

)