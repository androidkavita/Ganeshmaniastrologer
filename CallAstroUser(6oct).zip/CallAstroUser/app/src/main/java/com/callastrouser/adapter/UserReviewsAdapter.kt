package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowCustomerTestimonialsBinding
import com.callastrouser.model.AstroRatingReview

class UserReviewsAdapter(val context : Context, var data: ArrayList<AstroRatingReview>) :
    RecyclerView.Adapter<UserReviewsAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowCustomerTestimonialsBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserReviewsAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_customer_testimonials, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: UserReviewsAdapter.ViewHolder, position: Int) {
        val List = data[position]
        Glide.with(context).load(List.profile).into(holder.binding.ivImage)
        holder.binding.tvName.text = List.name.toString()
        holder.binding.tvDetail.text = List.reveiw.toString()
        holder.binding.tvDetail.text = List.reveiw.toString()
        holder.binding.rating.rating = (List.rating!!.toString()).toFloat()
    }

    override fun getItemCount(): Int {
        return data.size
    }
}