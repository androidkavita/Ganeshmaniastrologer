package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowRecentlyOpenedListBinding
import com.callastrouser.model.RecentSeeKundliResponseData
import com.callastrouser.ui.activities.Kundali
import com.callastrouser.ui.activities.MatchHoroscope

class MatchMakingKundliListAdapter (val context : Context, var data: ArrayList<RecentSeeKundliResponseData>/*, var click: LiveAstro*/) :
    RecyclerView.Adapter<MatchMakingKundliListAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowRecentlyOpenedListBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_recently_opened_list, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.mname
        holder.binding.datetime.text = List.mdob+","+List.mtime_of_birth
        holder.binding.place.text = List.mplace_of_birth

        holder.binding.girlname.text = List.fname
        holder.binding.girldatetime.text = List.fdob+","+List.ftime_of_birth
        holder.binding.girlplace.text = List.fplace_of_birth

        holder.binding.linearItem.setOnClickListener(View.OnClickListener {
            context.startActivity(Intent(context, MatchHoroscope::class.java)
                .putExtra("boydob",List.mdob)
                .putExtra("boytob",List.mtime_of_birth)
                .putExtra("girldob",List.fdob)
                .putExtra("girltob",List.ftime_of_birth)
                .putExtra("picklat",List.mlatitude.toDouble())
                .putExtra("picklong",List.mlongitude.toDouble())
                .putExtra("droplat",List.flatitude.toDouble())
                .putExtra("droplong",List.flongitude.toDouble()))
        })
    }

    override fun getItemCount(): Int {
        return data.size
    }
    @SuppressLint("NotifyDataSetChanged")
    fun filterList(filteredStateList: ArrayList<RecentSeeKundliResponseData>) {
        data = filteredStateList
        notifyDataSetChanged()
    }
}