package com.callastrouser.ui.activities

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.databinding.ActivityAddAddressBinding
import com.callastrouser.model.CityListData
import com.callastrouser.model.StateListData
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.toast
import com.callastrouser.viewModel.AddressViewModel
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.google.android.material.internal.ContextUtils.getActivity
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AddAddress : BaseActivity() {
    lateinit var binding: ActivityAddAddressBinding
    private val viewModel: AddressViewModel by viewModels()
//    var statedata :ArrayList<StateListData> = arrayListOf()
//    var statenamedata :ArrayList<String> = arrayListOf()
//    var idstatedata :ArrayList<String> = arrayListOf()
//    var citydata :ArrayList<CityListData> = arrayListOf()
//    var citynamedata :ArrayList<String> = arrayListOf()
//    var idcitydata :ArrayList<String> = arrayListOf()
//    var selectedStateId= ""
    var addresstype = "1"
//    lateinit var selectedCityId :String
    var placesClient: PlacesClient? = null
    private val AUTOCOMPLETE_PLACE_REQUEST_CODE = 4
    var latLng: LatLng? = null
    var pickupLongitude = 0.0
    var pickupLatitude = 0.0
    var dropLongitude = 0.0
    var dropLatitude = 0.0
    var sourceLatLong: LatLng? = null
    var destLatLong: LatLng? = null
    var distance: Double? = null
    var distanceString: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_address)

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_add_address)
        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Add Address"

//        if (CommonUtils.isInternetAvailable(this@AddAddress)) {
//            StateAPI()
//        } else {
//            Log.d("TAG", "onCreate: " + "else part")
//            toast(this,"Please check internet connection.")
//        }

//        binding.State.onItemSelectedListener = object :
//            AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
//                selectedStateId=idstatedata[p2]
//                CityAPI()
//            }
//            override fun onNothingSelected(p0: AdapterView<*>?) {
//
//            }
//        }
//        binding.city.onItemSelectedListener = object :
//            AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
//                selectedCityId=idcitydata[p2]
//            }
//            override fun onNothingSelected(p0: AdapterView<*>?) {
//
//            }
//        }
        val apiKey = getString(R.string.api_key)
        if (!Places.isInitialized()) {
            Places.initialize(this, apiKey)
        }

        placesClient = Places.createClient(this)
        binding.area.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_PLACE_REQUEST_CODE)
        }
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.add_addressResponse.observe(this) {
            if (it.status == 1) {
                finish()
                toast(it.message.toString())
            } else {
            }
        }

        binding.homeLinear.setBackgroundResource(R.drawable.focus)
        binding.officeLinear.setBackgroundResource(R.drawable.background_focus_black)
        binding.hometext.text = "Home"
        binding.hometext.setTextColor(Color.parseColor("#742086"))
        binding.officetext.setTextColor(Color.parseColor("#FF000000"))
//            binding.homeicon.setBackgroundColor((ContextCompat.getColor(getActivity(), R.color.theme_purple))
        binding.homeicon.setImageResource(R.drawable.ic_home_address)
        binding.officeicon.setImageResource(R.drawable.office)

        binding.homeLinear.setOnClickListener {
            addresstype = "1"
            binding.homeLinear.setBackgroundResource(R.drawable.focus)
            binding.officeLinear.setBackgroundResource(R.drawable.background_focus_black)
            binding.hometext.text = "Home"
            binding.hometext.setTextColor(Color.parseColor("#742086"))
            binding.officetext.setTextColor(Color.parseColor("#FF000000"))
//            binding.homeicon.setBackgroundColor((ContextCompat.getColor(getActivity(), R.color.theme_purple))
            binding.homeicon.setImageResource(R.drawable.ic_home_address)
            binding.officeicon.setImageResource(R.drawable.office)
        }

        binding.officeLinear.setOnClickListener {
            addresstype = "2"
            binding.homeLinear.setBackgroundResource(R.drawable.background_focus_black)
            binding.officeLinear.setBackgroundResource(R.drawable.focus)
            binding.officetext.text = "Office"
            binding.officetext.setTextColor(Color.parseColor("#742086"))
            binding.hometext.setTextColor(Color.parseColor("#FF000000"))
            binding.homeicon.setImageResource(R.drawable.blackhome)
            binding.officeicon.setImageResource(R.drawable.color_bag)
        }


        binding.btnSaveContinue.setOnClickListener {
            if (binding.fullnameet.text.isNullOrEmpty()){
                snackbar("Please enter full name.")
            }else if (binding.mobile.text.isNullOrEmpty()){
                snackbar("Please enter mobile.")
            }else if (binding.mobile.text.length < 10){
                snackbar("Please enter valid mobile.")
            }else if (binding.houseno.text.isNullOrEmpty()){
                snackbar("Please enter house number.")
            }else if (binding.area.text.isNullOrEmpty()){
                snackbar("Please enter area.")
            }else if (binding.pincode.text.isNullOrEmpty()){
                snackbar("Please enter pincode.")
            }else{
                if (CommonUtils.isInternetAvailable(this@AddAddress)) {
                    viewModel.AddAddress(
                        "Bearer " + userPref.getToken().toString(),
                        binding.fullnameet.text.toString(),
                        binding.mobile.text.toString(),
                        binding.houseno.text.toString(),
                        binding.area.text.toString(),
//                        selectedStateId,
//                        selectedCityId,
                        binding.pincode.text.toString(),
                        addresstype
                    )
                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this,"Please check internet connection.")
                }

            }
        }
    }

    private fun placesAPiCall(requestCode: Int) {
        val fields = listOf(
            Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS,
            Place.Field.LAT_LNG
        )
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
            .build(this)
        startActivityForResult(intent, requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("TAG", "@@onActivityResult:")
        if (requestCode == AUTOCOMPLETE_PLACE_REQUEST_CODE) {
            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    pickupLongitude = latLng!!.longitude
                    pickupLatitude = latLng!!.latitude

//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLAT,
//                        pickupLatitude.toString()
//                    )
//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLNG,
//                        pickupLongitude.toString()
//                    )

                    binding.area.text = place.address
                    sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
                    Log.e("@@pickupLatitude", pickupLatitude.toString())
                }
                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                }
            }
            return
        }
    }


//    fun StateAPI(){
//        viewModel.StateListAPI().observe(this) {
//            if (it!!.status == 1) {
//                statedata.clear()
//                statenamedata.clear()
//                statedata.addAll(it!!.data)
//                viewModel.stateListData.value = it.data
//                for (i in 0 until it.data.size) {
//                    statenamedata.add(it.data[i].stateName.toString())
//                    idstatedata.add(it.data[i].id.toString())
//                }
//                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
//                    this,
//                    android.R.layout.simple_spinner_dropdown_item,
//                    statenamedata
//                )
//                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                binding.State.adapter = spinnerArrayAdapter
//            }
//        }
//    }
//
//    fun CityAPI(){
//        viewModel.CityListAPI(
//            selectedStateId.toInt()
//        ).observe(this) {
//            if (it!!.status == 1) {
//                citydata.clear()
//                citynamedata.clear()
//                citydata.addAll(it!!.data)
//                viewModel.citylistData.value = it.data
//                for (i in 0 until it.data.size) {
//                    citynamedata.add(it.data[i].cityName.toString())
//                    idcitydata.add(it.data[i].id.toString())
//                }
//                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
//                    this,
//                    android.R.layout.simple_spinner_dropdown_item,
//                    citynamedata
//                )
//                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                binding.city.adapter = spinnerArrayAdapter
//            }
//        }
//    }
}