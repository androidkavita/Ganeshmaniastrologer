package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class RechargeAmountDiscountResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<RechargeAmountDiscountResponseData> = arrayListOf()
)
data class RechargeAmountDiscountResponseData(
    @SerializedName("id"     ) var id     : Int?    = null,
    @SerializedName("amount" ) var amount : String? = null,
    @SerializedName("extra"  ) var extra  : String? = null
)
