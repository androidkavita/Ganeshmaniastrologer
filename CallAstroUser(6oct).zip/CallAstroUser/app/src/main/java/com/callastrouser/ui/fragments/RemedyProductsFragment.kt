package com.callastrouser.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.CategoryListAdapter
import com.callastrouser.adapter.ProductAdapter
import com.callastrouser.databinding.FragmentRemedyProductsBinding
import com.callastrouser.model.RemedyProductResponseData
import com.callastrouser.ui.activities.ShopWithUsItemDetails
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.RemedyViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class RemedyProductsFragment : BaseFragment(), ProductAdapter.ShopCategoryRemedy {
    lateinit var binding : FragmentRemedyProductsBinding
    lateinit var adapter: ProductAdapter
    private val viewModel: RemedyViewModel by viewModels()
    var Listdata: ArrayList<RemedyProductResponseData> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentRemedyProductsBinding.inflate(inflater, container, false)
        binding.swipeRefreshlayout.setOnRefreshListener {

            if (CommonUtils.isInternetAvailable(requireContext())) {
                viewModel.RemedyProduct(
                    "Bearer "+userPref.getToken().toString()
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast("Please check internet connection.")
            }

            binding.swipeRefreshlayout.isRefreshing = false
        }

        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.RemedyProduct(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.remedyproductResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                toast(it.message.toString())
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = ProductAdapter(requireContext(), Listdata,this)
                binding.rvAstrologers.adapter =adapter
            } else {
                toast(it.message.toString())
            }
        }

        return binding.root
    }

    override fun layoutid(
        layout: LinearLayout,
        id: String,
        name: String,
        minus: ImageView,
        qty: String,
        plus: ImageView
    ) {
        layout.setOnClickListener {
            var intent = Intent(requireContext(), ShopWithUsItemDetails::class.java)
            intent.putExtra("id",id)
            intent.putExtra("name",name)
            startActivity(intent)
        }
        minus.setOnClickListener {
            viewModel.add_to_cart("Bearer "+userPref.getToken().toString(),id,"2")
        }
        plus.setOnClickListener {
            viewModel.add_to_cart("Bearer "+userPref.getToken().toString(),id,"1")
        }
    }
}