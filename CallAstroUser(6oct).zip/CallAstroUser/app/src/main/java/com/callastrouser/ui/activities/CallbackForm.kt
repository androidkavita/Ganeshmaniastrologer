package com.callastrouser.ui.activities

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.databinding.ActivityCallbackFormBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.toast
import com.callastrouser.viewModel.CustomerViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CallbackForm : BaseActivity() {
    lateinit var binding: ActivityCallbackFormBinding
    private val viewModel: CustomerViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_callback_form)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_callback_form)

        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Callback Form"


        binding.submitbtn.setOnClickListener {
            if (binding.etMobile.text.isNullOrEmpty()){
                snackbar("Please enter mobile number.")
            }else if (binding.dicription.text.isNullOrEmpty()){
                snackbar("Please enter your discription.")
            }else{
                if (CommonUtils.isInternetAvailable(this)) {
                    viewModel.Callback(
                        "Bearer "+userPref.getToken().toString(),
                        binding.etMobile.text.toString(),
                        binding.dicription.text.toString()
                    )
                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this,"Please check internet connection.")
                }

            }
        }
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.commonResponse.observe(this) {
            if (it?.status == 1) {
                toast("Callback form submitted")
                finish()
            } else {
                snackbar(it?.message!!)
            }
        }
    }
}