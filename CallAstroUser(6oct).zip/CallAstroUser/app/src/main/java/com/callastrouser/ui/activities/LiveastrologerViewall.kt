package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.Click
import com.callastrouser.adapter.LiveastrologerviewallAdapter
import com.callastrouser.databinding.ActivityLiveastrologerViewallBinding
import com.callastrouser.model.LiveastrologerviewallResponseData
import com.callastrouser.ui.fragments.GoLiveFragment
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.HomeViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import kotlin.collections.ArrayList

@AndroidEntryPoint
class LiveastrologerViewall : BaseActivity(), Click {
    lateinit var binding: ActivityLiveastrologerViewallBinding
    lateinit var adapter: LiveastrologerviewallAdapter
    var Listdata: ArrayList<LiveastrologerviewallResponseData> = ArrayList()
    private val viewModel: HomeViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_liveastrologer_viewall)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_liveastrologer_viewall)


        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Live Astrologers"
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        if (CommonUtils.isInternetAvailable(this@LiveastrologerViewall)) {
            viewModel.Liveastrologersviewall(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }


        viewModel.liveastrologersviewallResponse.observe(this){
            binding.idNouser.visibility = View.GONE
            binding.rvPurchasedProducts.visibility = View.VISIBLE
            if (it.status == 1){
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = LiveastrologerviewallAdapter(this,Listdata,this)
                binding.rvPurchasedProducts.adapter = adapter
            }else{
                binding.idNouser.visibility = View.VISIBLE
                binding.rvPurchasedProducts.visibility = View.GONE
                binding.nodatatext.text = "No astrologer is live."
            }
        }
    }

    override fun liveastro(id: String, channelname: String, agora_token: String,name:String,Profile:String,calling_charg:String) {
//        supportFragmentManager.beginTransaction().replace(R.id.flContent, GoLiveFragment())
//            .addToBackStack("tag").commit();
//        val bundle = Bundle()
//        bundle.putString("astro_id",id)
//        bundle.putString("channelname",channelname)
//        bundle.putString("agora_token",agora_token)
//        val fragobj = GoLiveFragment()
//        fragobj.setArguments(bundle)
//        supportFragmentManager.beginTransaction()?.replace(
//            R.id.flContent,
//            fragobj, "Payment"
//        )?.addToBackStack(null)?.commit()

        startActivity(
            Intent(this,LiveActivity::class.java)
            .putExtra("channelname",channelname)
            .putExtra("agora_token",agora_token)
                .putExtra("name",name)
                .putExtra("profile",Profile)
                .putExtra("id",id)
                .putExtra("calling_charg",calling_charg)
        )
    }
}