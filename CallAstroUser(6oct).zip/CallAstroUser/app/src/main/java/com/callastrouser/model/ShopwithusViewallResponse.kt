package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ShopwithusViewallResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<ShopwithusViewallResponseData> = arrayListOf()

)
data class ShopwithusViewallResponseData(
    @SerializedName("id"             ) var id            : Int?    = null,
    @SerializedName("category_name"  ) var categoryName  : String? = null,
    @SerializedName("category_image" ) var categoryImage : String? = null
)