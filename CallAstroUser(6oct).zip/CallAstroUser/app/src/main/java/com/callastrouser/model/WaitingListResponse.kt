package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class WaitingListResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : WaitingListResponseData?   = WaitingListResponseData()

)

data class WaitingListResponseData(
    @SerializedName("id"            ) var id           : Int?    = null,
    @SerializedName("user_id"       ) var userId       : Int?    = null,
    @SerializedName("astro_id"      ) var astroId      : Int?    = null,
    @SerializedName("user_name"          ) var name         : String? = null,
    @SerializedName("astimate_time" ) var time         : String? = null,
    @SerializedName("astro_name") var user_name         : String? = null,
    @SerializedName("astro_profile"       ) var profile      : String? = null,
    @SerializedName("calling_charg" ) var callingCharg : Int?    = null,
    @SerializedName("unique_id" ) var unique_id : Int?    = null
)
