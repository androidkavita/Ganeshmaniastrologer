package com.callastrouser.model

data class KundliMatchMakingResponse(
    val output: KundliMatchMakingResponseOutput,
    val statusCode: Int
)

data class KundliMatchMakingResponseOutput(
    val gana_kootam: GanaKootam,
    val graha_maitri_kootam: GrahaMaitriKootam,
    val nadi_kootam: NadiKootam,
    val out_of: Int,
    val rasi_kootam: RasiKootam,
    val tara_kootam: TaraKootam,
    val total_score: Double,
    val varna_kootam: VarnaKootam,
    val vasya_kootam: VasyaKootam,
    val yoni_kootam: YoniKootam
)

data class GanaKootam(
    val bride: Bride,
    val groom: Groom,
    val out_of: Int,
    val score: Int
)

data class GrahaMaitriKootam(
    val bride: BrideX,
    val groom: GroomX,
    val out_of: Int,
    val score: Int
)

data class NadiKootam(
    val bride: BrideXX,
    val groom: GroomXX,
    val out_of: Int,
    val score: Int
)

data class RasiKootam(
    val bride: BrideXXX,
    val groom: GroomXXX,
    val out_of: Int,
    val score: Int
)

data class TaraKootam(
    val bride: BrideXXXX,
    val groom: GroomXXXX,
    val out_of: Int,
    val score: Double
)

data class VarnaKootam(
    val bride: BrideXXXXX,
    val groom: GroomXXXXX,
    val out_of: Int,
    val score: Int
)

data class VasyaKootam(
    val bride: BrideXXXXXX,
    val groom: GroomXXXXXX,
    val out_of: Int,
    val score: Int
)

data class YoniKootam(
    val bride: BrideXXXXXXX,
    val groom: GroomXXXXXXX,
    val out_of: Int,
    val score: Int
)

data class Bride(
    val bride_nadi: Int,
    val bride_nadi_name: String
)

data class Groom(
    val groom_nadi: Int,
    val groom_nadi_name: String
)

data class BrideX(
    val moon_sign: String,
    val moon_sign_lord: Int,
    val moon_sign_lord_name: String,
    val moon_sign_number: Int
)

data class GroomX(
    val moon_sign: String,
    val moon_sign_lord: Int,
    val moon_sign_lord_name: String,
    val moon_sign_number: Int
)

data class BrideXX(
    val nadi: Int,
    val nadi_name: String
)

data class GroomXX(
    val nadi: Int,
    val nadi_name: String
)

data class BrideXXX(
    val moon_sign: Int,
    val moon_sign_name: String
)

data class GroomXXX(
    val moon_sign: Int,
    val moon_sign_name: String
)

data class BrideXXXX(
    val star_name: String,
    val star_number: Int
)

data class GroomXXXX(
    val star_name: String,
    val star_number: Int
)

data class BrideXXXXX(
    val moon_sign: String,
    val moon_sign_number: Int,
    val varnam: Int,
    val varnam_name: String
)

data class GroomXXXXX(
    val moon_sign: String,
    val moon_sign_number: Int,
    val varnam: Int,
    val varnam_name: String
)

data class BrideXXXXXX(
    val bride_kootam: Int,
    val bride_kootam_name: String
)

data class GroomXXXXXX(
    val groom_kootam: Int,
    val groom_kootam_name: String
)

data class BrideXXXXXXX(
    val star: Int,
    val yoni: String,
    val yoni_number: Int
)

data class GroomXXXXXXX(
    val star: Int,
    val yoni: String,
    val yoni_number: Int
)