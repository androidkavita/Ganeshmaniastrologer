package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowQuestionAnswerBinding
import com.callastrouser.model.ProductDetails

class ProductQAAdapter (val context : Context, var data: ArrayList<ProductDetails>) :
    RecyclerView.Adapter<ProductQAAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowQuestionAnswerBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductQAAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_question_answer, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ProductQAAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.tvHead.text = List.title.toString()
        holder.binding.tvSubhead.text = List.description.toString()
//        holder.binding.money.text = List.

    }

    override fun getItemCount(): Int {
        return data.size
    }

}