package com.callastrouser.ui.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.AddressListAdapter
import com.callastrouser.databinding.ActivityAddressListBinding
import com.callastrouser.model.AddressListResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.AddressViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject
import java.util.ArrayList

@AndroidEntryPoint
class AddressList : BaseActivity(), AddressListAdapter.Address , AddressListAdapter.AddressAdd,
    AddressListAdapter.EditAddress,
    PaymentResultListener {
    lateinit var binding: ActivityAddressListBinding
    private val viewModel: AddressViewModel by viewModels()
    var Listdata: ArrayList<AddressListResponseData> = ArrayList()
    lateinit var id :String
    var addressids :String = ""
    var isPaymentDone=false
    var amount :String = ""
    var orderfrom :String = ""
    var coupon_discount: String = ""
    lateinit var adapter: AddressListAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_address_list)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_address_list)


        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Address List"
        if (intent!=null){
            id = intent.getStringExtra("id").toString()
            amount = intent.getStringExtra("amount").toString()
            orderfrom = intent.getStringExtra("bookingtype").toString()
            coupon_discount = intent.getStringExtra("coupon_discount").toString()
        }

        binding.addaddress.setOnClickListener {
            var intent = Intent(this@AddressList, AddAddress::class.java)
            startActivity(intent)
        }

        binding.Continuebtn.setOnClickListener {
            if (addressids.isNullOrEmpty()){
                toast(this@AddressList,"Please select address.")
            }else {
                if (orderfrom == "cart"){
                    startPayment(amount)
                }else{
                    var intent = Intent(this@AddressList,MyCart::class.java)
                    intent.putExtra("id",id)
                    intent.putExtra("bookingtype","booknow")
                    intent.putExtra("amount",amount)
                    intent.putExtra("addressid",addressids)
                    intent.putExtra("coupon_discount",coupon_discount)
                    startActivity(intent)
                }
//                startPayment(amount)


            }
        }
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.AddressList(
                "Bearer " + userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.addresslistResponse.observe(this) {
            if (it.status == 1) {
                binding.datalist.visibility = View.VISIBLE
                binding.idNouser.visibility = View.GONE
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = AddressListAdapter(this, Listdata,this,this,this)
                binding.rvAddress.adapter = adapter

            }else{
                binding.datalist.visibility = View.GONE
                binding.idNouser.visibility = View.VISIBLE
                binding.nodatatext.text = "No Address Found!!"

            }
        }

        viewModel.cartPlaceOrderResponse.observe(this){
            if (it.status == 1) {
                var intent = Intent(this@AddressList,OrderPlaced::class.java)
                intent.putExtra("orerid",it.data?.orderId.toString())
                intent.putExtra("productname",it.data?.productName.toString())
                intent.putExtra("totalitems",it.data?.totalItem.toString())
                intent.putExtra("expactDeliveryDate",it.data?.expactDeliveryDate.toString())
                intent.putExtra("orderstatus",it.data?.orderStatus.toString())
                startActivity(intent)
                finishAffinity()
            }
        }

        viewModel.commonResponse.observe(this) {
            if (it.status == 1) {
               toast(this@AddressList,it.message.toString())
                viewModel.AddressList(
                    "Bearer " + userPref.getToken().toString()
                )
            }
        }
    }
    override fun addressid(addressid: String,delete:ImageView) {
        addressids = addressid
//        delete.setOnClickListener {
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.DeleteAddress(
                "Bearer " + userPref.getToken().toString(),
                addressids
            )
        } else {
            toast(this,"Please check internet connection.")
        }

//        }
    }

    override fun addressid(addressid: String) {
        addressids = addressid


    }
    override fun editaddressid(addressid: String, edit: ImageView) {
        addressids = addressid
        startActivity(Intent(this@AddressList,EditAddress::class.java).putExtra("addressid",addressid))
    }
    override fun onResume() {
        super.onResume()
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.AddressList(
                "Bearer " + userPref.getToken().toString()
            )
        } else {
            toast(this,"Please check internet connection.")
        }

    }

    private fun startPayment(amt:String) {
        val activity: Activity = this
        val co = Checkout()
//        co.setKeyID("rzp_test_GtInU79qatMxhL")
        co.setKeyID("rzp_test_wUqHQQPq0YcTZ2")

        try {

            var amount=amt.toDouble()
            val options = JSONObject()
            options.put("name", "Call Astro")
            options.put("description", "s")
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("currency", "INR")
            options.put("amount",amount*100)
//            val preFill = JSONObject()
            /* preFill.put("email", userPref.getEmail())
             preFill.put("contact", userPref.getmobile())*/
            //  options.put("prefill", preFill)
            co.open(activity, options)
        } catch (e: Exception) {
            Toast.makeText(activity, "Error in payment: " + e.message, Toast.LENGTH_SHORT)
                .show()
            e.printStackTrace()
        }
    }

    override fun onPaymentSuccess(razorpayPaymentID: String) {
        try {
            //   val finalAmount  = amount/100
            Toast.makeText(this, "Payment Successful: $razorpayPaymentID", Toast.LENGTH_SHORT)
//                .show()
            isPaymentDone=true
            //callSendDetailAPI()
            paymentsuccessAPI(razorpayPaymentID)

        } catch (e: Exception) {
        }
    }
    private fun paymentsuccessAPI(razorpayPaymentID: String) {
        if (orderfrom == "cart"){
            viewModel.cart_place_order("Bearer "+userPref.getToken().toString(),addressids,"1","1",razorpayPaymentID,"cart","0",coupon_discount,"")
        }else{
            viewModel.cart_place_order("Bearer "+userPref.getToken().toString(),addressids,"1","1",razorpayPaymentID,"single",id,coupon_discount,"")
        }
    }
    override fun onPaymentError(p0: Int, p1: String?) {
        try {
            Toast.makeText(this, "Payment failed", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {

        }
    }
}