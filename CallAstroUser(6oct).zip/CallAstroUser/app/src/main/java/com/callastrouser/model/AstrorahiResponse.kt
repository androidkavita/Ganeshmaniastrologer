package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class AstrorahiResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : AstrorahiResponseData?   = AstrorahiResponseData()
)
data class AstrorahiResponseData(
    @SerializedName("id"                  ) var id                : Int?                         = null,
    @SerializedName("name"                ) var name              : String?                      = null,
    @SerializedName("experence_id"        ) var experenceId       : Int?                         = null,
    @SerializedName("about_us"            ) var aboutUs           : String?                      = null,
    @SerializedName("profile"             ) var profile           : String?                      = null,
    @SerializedName("expertise"           ) var expertise         : String?        = null,
    @SerializedName("language"            ) var language          : String?          = null,
    @SerializedName("experence"           ) var experence         : String?                      = null,
    @SerializedName("calling_charg"           ) var calling_charg         : String?                      = null,
    @SerializedName("astro_total_order"           ) var order         : Int?                      = null,
    @SerializedName("fixed_session_30min_charge"           ) var fixed_session_30min_charge         : String?                      = null,
    @SerializedName("fixed_session_60min_charge"           ) var fixed_session_60min_charge         : String?                      = null,
    @SerializedName("request"           ) var request         : Int?                      = 0,
    @SerializedName("astro_rating"        ) var astroRating       : AstroRating?                 = AstroRating(),
    @SerializedName("astro_rating_review" ) var astroRatingReview : ArrayList<AstroRatingReview> = arrayListOf(),
//    @SerializedName("session_detail"      ) var sessionDetail     : ArrayList<SessionDetail>     = arrayListOf()
)

data class AstroRating (

    @SerializedName("avg_rating" ) var avgRating : String? = null,
    @SerializedName("total"      ) var total     : Int?    = null,
    @SerializedName("five"       ) var five      : Int?    = null,
    @SerializedName("four"       ) var four      : Int?    = null,
    @SerializedName("three"      ) var three     : Int?    = null,
    @SerializedName("two"        ) var two       : Int?    = null,
    @SerializedName("one"        ) var one       : Int?    = null
)

data class AstroRatingReview (

    @SerializedName("name"    ) var name    : String? = null,
    @SerializedName("profile" ) var profile : String? = null,
    @SerializedName("rating"  ) var rating  : String? = null,
    @SerializedName("reveiw"  ) var reveiw  : String? = null,
    @SerializedName("pin"     ) var pin     : Int?    = null


)

//data class SessionDetail (
//    @SerializedName("id"         ) var id        : Int?    = null,
//    @SerializedName("time"       ) var time      : String? = null,
//    @SerializedName("price"      ) var price     : String? = null,
//    @SerializedName("status"     ) var status    : Int?    = null,
//    @SerializedName("created_at" ) var createdAt : String? = null,
//    @SerializedName("updated_at" ) var updatedAt : String? = null
//
//)