package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.ActivityConsultancyDetailsBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.OrderDetailsViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ConsultancyDetailsActivity : BaseActivity() {
    lateinit var binding: ActivityConsultancyDetailsBinding
    private val viewModel: OrderDetailsViewModel by viewModels()
    lateinit var product_id:String
    lateinit var flag:String
    lateinit var type:String
    lateinit var astroid:String
    lateinit var image:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consultancy_details)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_consultancy_details)

        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Consultancy Details"

        if (intent!=null){
            product_id = intent.getStringExtra("id").toString()
            flag = intent.getStringExtra("flag").toString()
            type = intent.getStringExtra("type").toString()
        }


//        binding.llCall.setOnClickListener {
//            startActivity(Intent(this@ConsultancyDetailsActivity,IntakeMatchMakingFormActivity::class.java).putExtra("id",product_id).putExtra("request_type","2"))
//        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.consultancy_order_detail(
                "Bearer "+userPref.getToken().toString(),
                product_id
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        binding.btnGiveReview.setOnClickListener {
            startActivity(Intent(this,GiveReviewConsultancy::class.java)
                .putExtra("name",binding.name.text.toString())
                .putExtra("date",binding.date.text.toString())
                .putExtra("bookingid",binding.bookingid.text.toString())
                .putExtra("experties",binding.experties.text.toString())
                .putExtra("image",image)
                .putExtra("experience",binding.experience.toString())
                .putExtra("language",binding.language.toString())
                .putExtra("profile",binding.language.toString())
                .putExtra("astroid",astroid)

                )
        }
        viewModel.consultancydetailResponse.observe(this){
            if (it.status == 1){
                binding.tvStoneName.text = it.data?.astro_name.toString()
                astroid = it.data?.id.toString()
                image = it.data?.profile.toString()
                Glide.with(this@ConsultancyDetailsActivity).load(it.data?.profile).into(binding.image)
                binding.date.text = it.data?.bookingDate.toString()
                binding.delieverydate.text = it.data?.bookingCompleteDate.toString()
                binding.tvPrice.text = "₹"+it.data?.price.toString()
                binding.bookingid.text = it.data?.bookingId.toString()
                binding.amtpermin.text = "₹"+it.data?.cost.toString()
                binding.duration.text = it.data?.duration.toString()
                binding.bookingstatus.text = it.data?.bookingStatus.toString()
                binding.delieverydate.text = it.data?.bookingCompleteDate.toString()
                binding.name.text = it.data?.astro_name.toString()
                binding.experties.text = it.data?.expertise.toString()
                binding.language.text = it.data?.language.toString()
                binding.experience.text = it.data?.experience.toString()
                if (type == "2"){
                    binding.callimage.setImageResource(R.drawable.ic_call)
                    binding.call.text = "Call"
                }else if (type == "1"){
                    binding.callimage.setImageResource(R.drawable.ic_chat)
                    binding.call.text = "Chat"
                }else if (type == "3"){
                    binding.callimage.setImageResource(R.drawable.
                    ic_video_call)
                    binding.call.text = "Video"
                }

            }else{
                snackbar(it.message.toString())
            }
        }

    }
}