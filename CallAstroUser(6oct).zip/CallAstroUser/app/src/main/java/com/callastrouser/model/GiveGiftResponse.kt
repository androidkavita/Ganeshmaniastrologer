package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class GiveGiftResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : GiveGiftResponseData?   = GiveGiftResponseData()
)
data class GiveGiftResponseData(
    @SerializedName("id"         ) var id        : Int?    = null,
    @SerializedName("image"      ) var image     : String? = null,
    @SerializedName("name"       ) var name      : String? = null,
    @SerializedName("price"      ) var price     : String? = null,
    @SerializedName("created_at" ) var createdAt : String? = null,
    @SerializedName("updated_at" ) var updatedAt : String? = null
)