package com.callastrouser.ui.activities

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.TimePicker
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.MainActivity
import com.callastrouser.R
import com.callastrouser.databinding.ActivityRegistrationBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.DateFormat
import com.callastrouser.viewModel.RegistrationViewModel
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.google.maps.android.SphericalUtil
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import java.util.*

@AndroidEntryPoint
class Registration : BaseActivity() {
    private lateinit var binding: ActivityRegistrationBinding
    private val viewModel: RegistrationViewModel by viewModels()
    lateinit var id: String
    lateinit var otp: String
    var gender: String = "1"
    var placesClient: PlacesClient? = null
    private val AUTOCOMPLETE_PLACE_REQUEST_CODE = 1
    var latLng: LatLng? = null
    var pickupLongitude = 0.0
    var pickupLatitude = 0.0
    var dropLongitude = 0.0
    var dropLatitude = 0.0
    var sourceLatLong: LatLng? = null
    var destLatLong: LatLng? = null
    var distance: Double? = null
    var distanceString: String? = null
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_registration)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        if (intent != null) {
            id = intent.getStringExtra("id").toString()
            otp = intent.getStringExtra("otp").toString()
        }
        binding.date.setOnClickListener {
            chooseDataPicker()
        }
        binding.datetv.setOnClickListener {
            chooseDataPicker()
        }
        binding.time.setOnClickListener {
            Selecttime()
        }
        binding.timetv.setOnClickListener {
            Selecttime()
        }
        binding.radio1.setOnClickListener {
            if (binding.radio1.isChecked == true) {
                gender = "1"
            }
        }
        binding.radio2.setOnClickListener {
            if (binding.radio2.isChecked == true) {
                gender = "2"
            }
        }
        binding.radio3.setOnClickListener {
            if (binding.radio3.isChecked == true) {
                gender = "3"
            }
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.registrationResponse.observe(this) {
            if (it?.status == 1) {
                id = it.data?.id.toString()
//                var intent = Intent(this, LoginVerifyOtpActivity::class.java)
//                intent.putExtra("id", id)
//                intent.putExtra("otp", otp)
//                startActivity(intent)


//                userPref.user = it.data!!
                userPref.isLogin = true
                userPref.setid(it.data?.id.toString())
                userPref.setUserId(it.data!!.id!!.toString())
                userPref.setMobile(it.data!!.mobileNo.toString())
                userPref.setToken(it.data!!.apiToken)
                userPref.setName(it.data?.name!!)
                userPref.setEmail(it.data!!.email)
                userPref.setProfile(it.data!!.profile.toString())

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finishAffinity()

            } else {
                //toast(it.message)
                snackbar(it?.message!!)
            }
        }

        binding.btnSubmit.setOnClickListener {
            if (binding.nameet.text.isNullOrEmpty()) {
                snackbar("Please enter name.")
            }else if (binding.email.text.isNullOrEmpty()) {
                snackbar("Please select email.")
            }else if (!binding.email.text.toString().trim().matches(emailPattern.toRegex())) {
                snackbar("Please enter valid email.")
            }else if (binding.datetv.text.isNullOrEmpty()) {
                snackbar("Please select date of birth.")
            }else if (binding.timetv.text.isNullOrEmpty()) {
                snackbar("Please select time of birth.")
            }else if (binding.placeofbirth.text.isNullOrEmpty()) {
                snackbar("Please select place of birth.")
            }else {
                if (CommonUtils.isInternetAvailable(this)) {
                    viewModel.Registration(
                        id,
                        binding.nameet.text.toString(),
                        binding.datetv.text.toString(),
                        binding.placeofbirth.text.toString(),
                        gender,
                        binding.timetv.text.toString(),
                        binding.email.text.toString()
                    )
                } else {
                    toast(this,"Please check internet connection.")
                }

            }
        }

        val apiKey = getString(R.string.api_key)
        if (!Places.isInitialized()) {
            Places.initialize(this, apiKey)
        }
        placesClient = Places.createClient(this)


        binding.placeofbirth.setOnClickListener{
            placesAPiCall(AUTOCOMPLETE_PLACE_REQUEST_CODE)
        }


    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun chooseDataPicker() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            this, R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                binding.datetv.text =
                    DateFormat.addServiceDealsDate(simpleDateFormat.format(cal.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
//        datePickerDialog.datePicker.minDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }
    fun Selecttime() {
        val mTimePicker: TimePickerDialog
        val mcurrentTime = Calendar.getInstance()
        val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
        val minute = mcurrentTime.get(Calendar.MINUTE)

        mTimePicker = TimePickerDialog(
            this,
            R.style.MyTimePickerTheme,
            object : TimePickerDialog.OnTimeSetListener {
                override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                    if (minute < 10) {
                        binding.timetv.setText(String.format("%d:0%d", hourOfDay, minute))
                    } else {
                        binding.timetv.setText(String.format("%d:%d", hourOfDay, minute))

                    }
                }
            },
            hour,
            minute,
            false
        )
        mTimePicker.show()
    }


    private fun placesAPiCall(requestCode: Int) {
        val fields = listOf(
            Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS,
            Place.Field.LAT_LNG
        )
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
            .build(this)
        startActivityForResult(intent, requestCode)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == AUTOCOMPLETE_PLACE_REQUEST_CODE) {
            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    pickupLongitude = latLng!!.longitude
                    pickupLatitude = latLng!!.latitude

//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLAT,
//                        pickupLatitude.toString()
//                    )
//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLNG,
//                        pickupLongitude.toString()
//                    )

                    binding.placeofbirth.text = place.address
                    sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
                    Log.e("@@pickupLatitude", pickupLatitude.toString())
                }
                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                }
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
}