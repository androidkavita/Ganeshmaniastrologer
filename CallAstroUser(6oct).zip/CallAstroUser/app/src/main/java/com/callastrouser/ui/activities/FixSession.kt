package com.callastrouser.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.ActivityFixSessionBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.AstrologerViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class FixSession : BaseActivity() {
    lateinit var binding: ActivityFixSessionBinding
    val viewModel : AstrologerViewModel by viewModels()
    lateinit var astrologerid:String
    lateinit var sessiontype:String
    lateinit var minimumbalence:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fix_session)
        binding = DataBindingUtil.setContentView(this@FixSession,R.layout.activity_fix_session)
        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Profile"
        if (intent!=null){
            astrologerid = intent.getStringExtra("id").toString()
            sessiontype = intent.getStringExtra("sessiontype").toString()
            minimumbalence = intent.getStringExtra("minimumbalence").toString()
        }


        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.strologer_details(
                "Bearer " + userPref.getToken().toString(),
                astrologerid
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }



        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.astrorahiResponse.observe(this) {
            if (it.status == 1) {
                binding.name.text = it.data?.name.toString()
                binding.designation.text = it.data?.expertise.toString()
                binding.language.text = it.data?.language.toString()
                binding.experience.text = it.data?.experence.toString()
                Glide.with(this).load(it.data?.profile).into(binding.image)
                binding.ratings.rating = it.data?.astroRating!!.avgRating!!.toFloat()
                binding.amount30min.text = "₹"+it.data?.fixed_session_30min_charge.toString()+"/-"
                binding.amount60min.text = "₹"+it.data?.fixed_session_60min_charge.toString()+"/-"
            } else {
            }
        }

        binding.callimage.setOnClickListener{
            startActivity(Intent(this,IntakeMatchMakingFormActivity::class.java)
                .putExtra("id",astrologerid)
                .putExtra("request_type","2")
                .putExtra("fix","FIX")
                .putExtra("sessiontype",sessiontype)
                .putExtra("minimumbalence",minimumbalence))
        }

        binding.chatimage.setOnClickListener{
            startActivity(Intent(this,IntakeMatchMakingFormActivity::class.java).putExtra("id",astrologerid).putExtra("request_type","1").putExtra("fix","FIX").putExtra("sessiontype",sessiontype).putExtra("minimumbalence",minimumbalence))
        }

        binding.videocallimage.setOnClickListener{
            startActivity(Intent(this,IntakeMatchMakingFormActivity::class.java).putExtra("id",astrologerid).putExtra("request_type","3").putExtra("fix","FIX").putExtra("sessiontype",sessiontype).putExtra("minimumbalence",minimumbalence))
        }

    }
}