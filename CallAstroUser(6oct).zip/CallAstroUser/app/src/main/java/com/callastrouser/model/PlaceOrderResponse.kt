package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class PlaceOrderResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : PlaceOrderResponseData?   = PlaceOrderResponseData()
)
data class PlaceOrderResponseData(
    @SerializedName("order_id"             ) var orderId            : String? = null,
    @SerializedName("product_name"         ) var productName        : String? = null,
    @SerializedName("total_item"           ) var totalItem          : String? = null,
    @SerializedName("pament_mode"          ) var pamentMode         : String? = null,
    @SerializedName("expact_delivery_date" ) var expactDeliveryDate : String? = null,
    @SerializedName("order_status"         ) var orderStatus        : String? = null
)
