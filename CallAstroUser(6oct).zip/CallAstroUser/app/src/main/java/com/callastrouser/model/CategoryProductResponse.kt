package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class CategoryProductResponse(
    @SerializedName("status"   ) var status   : Int?            = null,
    @SerializedName("message"  ) var message  : String?         = null,
    @SerializedName("category" ) var category : String?         = null,
    @SerializedName("data"     ) var data     : ArrayList<CategoryProductResponseData> = arrayListOf()
)
data class CategoryProductResponseData(
    @SerializedName("id"          ) var id          : Int?    = null,
    @SerializedName("category_id" ) var categoryId  : Int?    = null,
    @SerializedName("name"        ) var name        : String? = null,
    @SerializedName("description" ) var description : String? = null,
    @SerializedName("price"       ) var price       : String? = null,
    @SerializedName("main_image"  ) var mainImage   : String? = null
)