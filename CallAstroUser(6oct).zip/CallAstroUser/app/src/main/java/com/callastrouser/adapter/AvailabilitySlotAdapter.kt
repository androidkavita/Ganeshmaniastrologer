package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowAvailabilityTimeslotBinding
import com.callastrouser.model.AvailTimmings

class AvailabilitySlotAdapter (val context : Context, var data: ArrayList<AvailTimmings>) :
    RecyclerView.Adapter<AvailabilitySlotAdapter.ViewHolder>() {
    var List:ArrayList<AvailTimmings> = arrayListOf()
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowAvailabilityTimeslotBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AvailabilitySlotAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_availability_timeslot, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: AvailabilitySlotAdapter.ViewHolder, position: Int) {
        val List = data[position]
//        holder.binding.tvDay.text = List.fromTime.toString()+" - "+List.toTime.toString()
        holder.binding.tvDay.text = List.timeAvail.toString()
    }

    override fun getItemCount(): Int {
        return data.size
    }

}