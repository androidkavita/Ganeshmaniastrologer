package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.AboutUsResponse
import com.callastrouser.model.AstrorahiResponse
import com.callastrouser.model.CallStartResponse
import com.callastrouser.model.ChatCallCancelReasonResponse
import com.callastrouser.model.ChatRequestCancelResponse
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.EmailUs_Response
import com.callastrouser.model.FAQResponse
import com.callastrouser.model.GetCustomerSupportChat
import com.callastrouser.model.GetGiftResponse
import com.callastrouser.model.GiveGiftResponse
import com.callastrouser.model.GiveReviewResponse
import com.callastrouser.model.LiveCommentsModelClass
import com.callastrouser.model.NotificationResponse
import com.callastrouser.model.UserAstroConnectStatusResponse
import com.callastrouser.util.ApiException
import com.callastrouser.util.NoInternetException
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.Response
import java.net.SocketTimeoutException
import javax.inject.Inject

@HiltViewModel
class CustomerViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    val emailusResponse = MutableLiveData<EmailUs_Response>()
    val liveCommentsModelClass = MutableLiveData<LiveCommentsModelClass>()
    val AboutUsResponse = MutableLiveData<AboutUsResponse>()
    val NotificationResponse = MutableLiveData<NotificationResponse>()
    val errorString = MutableLiveData<String>()
    val FAQResponse = MutableLiveData<FAQResponse>()
    val customerSupportChat = MutableLiveData<GetCustomerSupportChat>()
    val _progressBarVisibility = MutableLiveData<Boolean>()
    var callStartResponse = MutableLiveData<CallStartResponse>()
    var callStartResponseagain = MutableLiveData<CallStartResponse>()
    var callStartResponseagainandagain = MutableLiveData<CallStartResponse>()
    var commonResponse = MutableLiveData<CommonResponse>()
    var getgiftResponse = MutableLiveData<GetGiftResponse>()
    var givegiftResponse = MutableLiveData<GiveGiftResponse>()
    var commonssResponse = MutableLiveData<CommonResponse>()
    var commonssResponses = MutableLiveData<CommonResponse>()
    val chatcallCancelReasonResponse = MutableLiveData<ChatCallCancelReasonResponse>()
    val callCancelResponse = MutableLiveData<ChatRequestCancelResponse>()
    val userAstroConnectStatusResponse = MutableLiveData<UserAstroConnectStatusResponse>()
    val givereviewResponse = MutableLiveData<GiveReviewResponse>()
    val astrorahiResponse = MutableLiveData<AstrorahiResponse>()


    fun EmailUs(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.EmailUs(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                emailusResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun strologer_details(
        token:String,
        id:String,
    ) {
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.strologer_details(token,id)
                if (response.isSuccessful) {
                    astrorahiResponse.postValue(response.body())
                } else {
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
    }
    fun user_give_review(
        token: String,
        astro_id: String,
        rating: String,
        review: String,
    ) {
        viewModelScope.launch {
            val response =
                mainRepository.user_give_review(token,astro_id,rating,review,"","")
            if (response.isSuccessful) {
                givereviewResponse.postValue(response.body())
            } else {
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun product_give_review(
        token: String,
        product_id: String,
        rating: String,
        review: String,
    ) {
        viewModelScope.launch {
            val response =
                mainRepository.product_give_review(token,product_id,rating,review)
            if (response.isSuccessful) {
                givereviewResponse.postValue(response.body())
            } else {
                Log.d("TAG", response.body().toString())
            }
        }
    }



    fun chatcallReasonCancelListApi(
        token: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.chatcallReasonCancelListApi(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                chatcallCancelReasonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun live_astrologer_user(
        token:String,astro_id: String,channel_name: String,status: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.live_astrologer_user(token,astro_id,channel_name,status)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonssResponses.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun live_astrologer_user(
        token:String,channel_name: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.user_astro_connect_status(token,channel_name)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                userAstroConnectStatusResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }




    fun gifts(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.gifts(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                getgiftResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun user_send_gifts(
        token: String,
        id: String,
        astro_id: String,
        channel_name: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.user_send_gifts(token,id,astro_id,channel_name)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                givegiftResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }




    fun call_request_cancel_api(
        token: String,id: String,
        reason: String,
        comment: String,
        action_by:String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.call_request_cancel_api(token, id, reason, comment,action_by)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                callCancelResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun when_call_start(
        token: String,
        astro_id: String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.when_call_start(token,astro_id)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    callStartResponse.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }

    fun when_call_start_again(
        token: String,
        astro_id: String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.when_call_start(token,astro_id)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    callStartResponseagain.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }

    fun when_call_start_again_and_again(
        token: String,
        astro_id: String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.when_call_start(token,astro_id)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    callStartResponseagainandagain.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }
    fun live_end(token: String,timer: String,from_user: String,to_user: String,type: String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.live_end(token,timer,from_user,to_user,type)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    commonssResponse.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }


    fun send_chat_with_us(
        token: String,
        message: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.send_chat_with_us(token,message)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun get_chat_with_us(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.get_chat_with_us(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                customerSupportChat.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }
    fun add_comment(
        token: String,
        message: String,
        channel_name: String,
        astro_id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.add_comment(
                    token,
                    message,
                    channel_name,astro_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun get_live_comments(
        token: String,
        channel_name: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.get_live_comments(
                    token,
                    channel_name,)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                liveCommentsModelClass.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun Callback(
        token: String,
        mobile :String,
        discription:String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.callback_apply(token,mobile,discription)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun AboutUs(
        token: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.aboutus(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                AboutUsResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun Notification(
        token: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.notification(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                NotificationResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun Notification_Read(
        token: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.Notification_Read(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun FAQ(
        token: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.faq(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                FAQResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

}