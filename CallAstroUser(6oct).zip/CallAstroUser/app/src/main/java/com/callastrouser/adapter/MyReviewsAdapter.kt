package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowCustomerTestimonialsBinding
import com.callastrouser.model.MyReviewsResponseData

class MyReviewsAdapter (val context : Context, var data: ArrayList<MyReviewsResponseData>) :
    RecyclerView.Adapter<MyReviewsAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowCustomerTestimonialsBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyReviewsAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_customer_testimonials, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MyReviewsAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.tvName.text = List.astroName.toString()
        holder.binding.tvDetail.text = List.reveiw.toString()
        holder.binding.rating.rating = List.rating!!.toFloat()
        Glide.with(context).load(List.astroProfile).into(holder.binding.ivImage)
    }

    override fun getItemCount(): Int {
        return data.size
    }
}