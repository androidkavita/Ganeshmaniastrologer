package com.callastrouser.ui.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.ActivityMyCartBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.OrderDetailsViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject

@AndroidEntryPoint
class MyCart : BaseActivity(), PaymentResultListener {
    private val viewModel: OrderDetailsViewModel by viewModels()
    lateinit var binding: ActivityMyCartBinding
    lateinit var id :String
    lateinit var address_id :String
    var minteger = 0
    var quantityprice = 0
    var discount = 0
    var realamount = 0
    var TotalAmount = 0
    var Shippingamount : String = ""
    var tax : String = ""
    var finalAmount : String = ""
    var coupon : String = ""
    var itemCount = ""
    var amt :String=""
    var isPaymentDone=false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_cart)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_my_cart)
        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Order Details"

        if (intent!= null){
            id = intent.getStringExtra("id").toString()
            address_id = intent.getStringExtra("addressid").toString()

        }
        binding.placeorder.setOnClickListener {
            startPayment(finalAmount)
        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.OrderDetail(
                "Bearer "+userPref.getToken().toString(),
                id,
                address_id,"2",""
            )
        } else {
            toast(this,"Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        binding.apply.setOnClickListener {
            if (binding.coupondiscount.text.isNullOrEmpty()){
                toast(this@MyCart,"please enter coupon code.")
            }else{
                viewModel.OrderDetail(
                    "Bearer "+userPref.getToken().toString(),
                    id,
                    address_id,"4",binding.coupondiscount.text.toString()
                )
            }

        }

        binding.tvPlus.setOnClickListener {
            minteger = 1
            minteger += 1
            viewModel.OrderDetail(
                "Bearer "+userPref.getToken().toString(),
                id,
                address_id,"1",""
            )
//            binding.tvCount.text = minteger.toString()
//            realamount = quantityprice*minteger
//            binding.price.text = "₹"+realamount.toString()
//            binding.productPrice.text = "₹"+realamount.toString()
//            finalAmount = ((realamount -((realamount*discount)/100))+Shippingamount.toInt()+tax.toInt()).toString()
//            binding.TotalAmount.text = "₹"+finalAmount
        }
        binding.tvMinus.setOnClickListener {
            if (minteger > 1) {

                minteger -= 1
                viewModel.OrderDetail(
                    "Bearer "+userPref.getToken().toString(),
                    id,
                    address_id,"0",""
                )
//                binding.tvCount.text = minteger.toString()
//                realamount = quantityprice*minteger
//                binding.price.text = "₹"+realamount.toString()
//                binding.productPrice.text = "₹"+realamount.toString()
//                finalAmount = ((realamount -((realamount*discount)/100))+Shippingamount.toInt()+tax.toInt()).toString()
//                binding.TotalAmount.text = "₹"+finalAmount
            }else{
                toast(this@MyCart,"Quantity will not less then 1.")
            }
        }



        viewModel.myCartResponse.observe(this){
            if (it.status == 1){
                minteger = 1
//                quantityprice = it.data?.product?.itemPrice.toString().toInt()
//                discount = it.data?.couponDiscount.toString().toInt()
//                TotalAmount = it.data?.grandTotal.toString().toInt()
                finalAmount = it.data?.grandTotal.toString()
//                Shippingamount = it.data?.shippingChard.toString()
//                tax = it.data?.tax.toString()
                coupon = it.data?.couponDiscount.toString()
//                realamount = it.data?.product?.price.toString().toInt()
            binding.tvProductname.text= it.data?.product?.name.toString()
            binding.hsncode.text= it.data?.product?.hsnCode.toString()
            binding.price.text= "Product Price : ₹"+it.data?.product?.itemPrice.toString()
                binding.tvCount.text = it.data?.product?.qty.toString()
                minteger = it.data!!.product!!.qty!!.toInt()
            binding.discription.text= it.data?.product?.description.toString()
            binding.productPrice.text= "₹"+it.data?.product?.totalItemPrice.toString()
            binding.tax.text= "₹"+it.data?.tax.toString()
            binding.shippingCharges.text= "₹"+it.data?.shippingChard.toString()
            binding.couponDiscount.text= "₹"+it.data?.couponDiscount.toString()
            binding.TotalAmount.text= "₹"+it.data?.grandTotal.toString()
//                finalAmount = ((realamount-(realamount*discount)/100)+it.data?.shippingChard.toString().toInt()).toString()
//            binding.TotalAmount.text= "₹"+((realamount-(realamount*discount)/100)+it.data?.shippingChard.toString().toInt()+it.data?.tax.toString().toInt()).toString()
            Glide.with(this).load(it.data?.product?.mainImage.toString()).into(binding.ivImage)
            }else if(it.status == 2){
                snackbar(it.message.toString())
            }else if(it.status == 3){
                snackbar(it.message.toString())
            }else{
                snackbar(it.message.toString())
            }
        }
        viewModel.cartPlaceOrderResponse.observe(this){
            if (it.status == 1) {
                var intent = Intent(this@MyCart,OrderPlaced::class.java)
                intent.putExtra("orerid",it.data?.orderId.toString())
                intent.putExtra("productname",it.data?.productName.toString())
                intent.putExtra("totalitems",it.data?.totalItem.toString())
                intent.putExtra("expactDeliveryDate",it.data?.expactDeliveryDate.toString())
                intent.putExtra("orderstatus",it.data?.orderStatus.toString())
                startActivity(intent)
                finishAffinity()
            }
        }
        viewModel.placeorderResponse.observe(this){
            if (it.status == 1){
                var intent = Intent(this@MyCart,OrderPlaced::class.java)
                intent.putExtra("orerid",it.data?.orderId.toString())
                intent.putExtra("productname",it.data?.productName.toString())
                intent.putExtra("totalitems",it.data?.totalItem.toString())
                intent.putExtra("expactDeliveryDate",it.data?.expactDeliveryDate.toString())
                intent.putExtra("orderstatus",it.data?.orderStatus.toString())
                startActivity(intent)
                finishAffinity()
            }else{
                snackbar(it.message.toString())
            }
        }
    }
    private fun startPayment(amt:String) {
        val activity: Activity = this
        val co = Checkout()
//        co.setKeyID("rzp_test_GtInU79qatMxhL")
        co.setKeyID("rzp_test_wUqHQQPq0YcTZ2")

        try {

            var amount=amt.toDouble()
            val options = JSONObject()
            options.put("name", "Call Astro")
            options.put("description", "s")
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("currency", "INR")
            options.put("amount",amount*100)
//            val preFill = JSONObject()
            /* preFill.put("email", userPref.getEmail())
             preFill.put("contact", userPref.getmobile())*/
            //  options.put("prefill", preFill)
            co.open(activity, options)
        } catch (e: Exception) {
            Toast.makeText(activity, "Error in payment: " + e.message, Toast.LENGTH_SHORT)
                .show()
            e.printStackTrace()
        }
    }

    override fun onPaymentSuccess(razorpayPaymentID: String) {
        try {
            //   val finalAmount  = amount/100
            Toast.makeText(this, "Payment Successful: $razorpayPaymentID", Toast.LENGTH_SHORT)
//                .show()
            isPaymentDone=true
            //callSendDetailAPI()
            paymentsuccessAPI(razorpayPaymentID)

        } catch (e: Exception) {
        }
    }

    private fun paymentsuccessAPI(razorpayPaymentID: String) {
        if (CommonUtils.isInternetAvailable(this)) {
//            viewModel.OrderPlace(
//                "Bearer "+userPref.getToken().toString(),
//                id,
//                realamount.toString(),
//                Shippingamount,
//                coupon,
//                finalAmount,
//                "Coupon#123@",
//                address_id,
//                binding.tvCount.text.toString(),
//                razorpayPaymentID,
//                "1",
//                "1",
//            )
            viewModel.cart_place_order(
                "Bearer "+userPref.getToken().toString(),
                address_id,
                "1",
                "1",
                razorpayPaymentID,
                "single",
                id,
                coupon,
                minteger.toString())
        } else {
            toast(this,"Please check internet connection.")
        }
    }

    override fun onPaymentError(p0: Int, p1: String?) {
        try {
            Toast.makeText(this, "Payment failed", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {

        }
    }
}