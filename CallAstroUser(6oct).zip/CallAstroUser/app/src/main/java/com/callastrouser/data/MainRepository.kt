package com.callastro.data

import com.callastrouser.model.LoginResponse
import com.callastrouser.model.LoginverificationResponse
import com.callastrouser.model.RegistrationResponse
import com.callastrouser.model.AboutUsResponse
import com.callastrouser.model.ActiveHomeResponse
import com.callastrouser.model.AddAddressResponse
import com.callastrouser.model.AddressListResponse
import com.callastrouser.model.AgoraCreateUserResponse
import com.callastrouser.model.AgoraGenerateTokenResponse
import com.callastrouser.model.AstrologersListViewAllResponse
import com.callastrouser.model.AstrorahiResponse
import com.callastrouser.model.AvailabilityResponse
import com.callastrouser.model.BannerResponse
import com.callastrouser.model.BlogListResponse
import com.callastrouser.model.BookingDetailsResponse
import com.callastrouser.model.CallHistoryResponse
import com.callastrouser.model.CallRingResponse
import com.callastrouser.model.CallStartResponse
import com.callastrouser.model.CallendbyuserResponse
import com.callastrouser.model.CancelReasonResponse
import com.callastrouser.model.CartCountResponse
import com.callastrouser.model.CartListResponse
import com.callastrouser.model.CartPlaceOrderResponse
import com.callastrouser.model.CategoryProductResponse
import com.callastrouser.model.ChatAgoraResponse
import com.callastrouser.model.ChatFragmentResponse
import com.callastrouser.model.ChatHistoryResponse
import com.callastrouser.model.ChatListMessageResponse
import com.callastrouser.model.CheckChatEndResponse
import com.callastrouser.model.CityList
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.ConsultancyDetail
import com.callastrouser.model.ConsultancyOrderResponse
import com.callastrouser.model.EmailUs_Response
import com.callastrouser.model.ExpertizeResponse
import com.callastrouser.model.FAQResponse
import com.callastrouser.model.GetAstroDetailsResponse
import com.callastrouser.model.GetIntakeResponse
import com.callastrouser.model.GiveReviewResponse
import com.callastrouser.model.HistoryProductSuggestedResponse
import com.callastrouser.model.HistoryWallet
import com.callastrouser.model.IntakeResponse
import com.callastrouser.model.LanguageResponse
import com.callastrouser.model.LiveAstrologerResponse
import com.callastrouser.model.LiveastrologerviewallResponse
import com.callastrouser.model.MaritalStatusList
import com.callastrouser.model.MatchMakingResponse
import com.callastrouser.model.MissedCallChatResponse
import com.callastrouser.model.MyCartResponse
import com.callastrouser.model.MyOrdersEcommersProductResponse
import com.callastrouser.model.MyReviewsResponse
import com.callastrouser.model.NotificationResponse
import com.callastrouser.model.PlaceOrderResponse
import com.callastrouser.model.ProductResponse
import com.callastrouser.model.RechargeAmountDiscountResponse
import com.callastrouser.model.RemedyProductResponse
import com.callastrouser.model.RemedySuggestedResponse
import com.callastrouser.model.ReportIntakeDetail
import com.callastrouser.model.ReportsHistoryResponse
import com.callastrouser.model.ShopwithusViewallResponse
import com.callastrouser.model.StateList
import com.callastrouser.model.TransactionHistoryResponse
import com.callastrouser.model.ViewProfile
import com.callastrouser.model.ViewReportResponse
import com.callastrouser.model.WaitingListResponse
import com.callastrouser.model.WalletResponse
import com.callastrouser.model.ChatAcceptedResponse
import com.callastrouser.model.ChatCallCancelReasonResponse
import com.callastrouser.model.ChatRequestCancelResponse
import com.callastrouser.model.DThreeChartResponse
import com.callastrouser.model.EditAddressResponse
import com.callastrouser.model.GetAddressResponse
import com.callastrouser.model.GetAstroSlotsResponse
import com.callastrouser.model.GetBlogDetailResponse
import com.callastrouser.model.GetCustomerSupportChat
import com.callastrouser.model.GetGiftResponse
import com.callastrouser.model.GiveGiftResponse
import com.callastrouser.model.KundliMatchMakingResponse
import com.callastrouser.model.LiveCommentsModelClass
import com.callastrouser.model.MakeKundaliResponse
import com.callastrouser.model.NavmsaResponse
import com.callastrouser.model.Notiffication_Count_Response
import com.callastrouser.model.PlanetsResponse
import com.callastrouser.model.RecentSeeKundliResponse
import com.callastrouser.model.RemedyPoojaResponse
import com.callastrouser.model.SendKundliResponse
import com.callastrouser.model.UserAstroConnectStatusResponse
import com.callastrouser.model.call_ring_status_save_Response
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response

interface MainRepository {
//
//
    suspend fun login(country_code: String,mobile:String,device_id: String,device_type: String,device_name: String,device_token: String):
        Response<LoginResponse>

    suspend fun recent_otp(mobile_no: String,type: String):
            Response<LoginResponse>

    suspend fun loginverification(id: String, otp: String):
            Response<LoginverificationResponse>

    suspend fun notification_count(token: String):
            Response<Notiffication_Count_Response>

    suspend fun Registration(id:String,name:String,dob:String,address:String,gender:String,birth_time: String,email: String/*,mobile_no: String*/):
            Response<RegistrationResponse>

    suspend fun live_end(token:String,timer:String,from_user: String,to_user: String,type: String):
            Response<CommonResponse>

    suspend fun liveAstrologers(token:String):
            Response<LiveAstrologerResponse>

    suspend fun EmailUs(token:String):
            Response<EmailUs_Response>

    suspend fun add_comment(
        token: String,
        message: String,
        channel_name: String,
        astro_id: String,
    ): Response<CommonResponse>

    suspend fun AddAddress(token:String,full_name:String,phone_no: String,house_no: String,area: String/*,state: String,city: String*/,pincode: String,address_type: String,):
            Response<AddAddressResponse>

    suspend fun get_live_comments(
        token: String,
        channel_name: String,
        ): Response<LiveCommentsModelClass>

    suspend fun active_home(token: String):
            Response<ActiveHomeResponse>

    suspend fun AddressList(token:String):
            Response<AddressListResponse>

    suspend fun Wallet(token:String):
            Response<WalletResponse>

    suspend fun history_wallets(token:String):
            Response<TransactionHistoryResponse>

    suspend fun add_to_cart(token: String,product_id: String,type: String):
            Response<CommonResponse>

    suspend fun callback_apply(token:String,mobile:String,discription:String):
            Response<CommonResponse>

    suspend fun aboutus(token:String):
            Response<AboutUsResponse>

    suspend fun notification(token:String):
            Response<NotificationResponse>

    suspend fun faq(token:String):
            Response<FAQResponse>

    suspend fun ViewProfile(token:String):
            Response<ViewProfile>

    suspend fun Expertize(token:String):
            Response<ExpertizeResponse>

    suspend fun Liveastrologersviewall(token:String):
            Response<LiveastrologerviewallResponse>

    suspend fun cart_place_order(token: String,address_id: String,payment_status: String,payment_type:String,transaction_id:String,orderfrom: String,product_id: String,coupon_discount: String,qty: String):
            Response<CartPlaceOrderResponse>

    suspend fun delete_cart(token:String,cart_id: String):
            Response<CommonResponse>

    suspend fun gifts(token:String):
            Response<GetGiftResponse>

    suspend fun chatcallReasonCancelListApi(token:String):
            Response<ChatCallCancelReasonResponse>

    suspend fun user_send_gifts(
        token: String,
        id: String,
        astro_id: String,
        channel_name: String
    ): Response<GiveGiftResponse>

    suspend fun call_request_cancel_api(token:String,id:String,reason:String,comment:String,action_by:String):
            Response<ChatRequestCancelResponse>

    suspend fun insert_recently_see_match_making_kundali(
        token:String,
        fname : String,
        fdate : String,
        fmonth: String,
        fyear: String,
        fhours: String,
        fminutes: String,
        fseconds: String,
        flatitude: String,
        flongitude: String,
        ftimezone: String,
        fbirthplace: String,
        mname : String,
        mdate : String,
        mmonth: String,
        myear: String,
        mhours: String,
        mminutes: String,
        mseconds: String,
        mlatitude: String,
        mlongitude: String,
        mtimezone: String,
        mbirthplace: String,
    ): Response<SendKundliResponse>

    suspend fun UpdateAddress(
        token: String,
        address_id: String,
        full_name: String,
        phone_no: String,
        house_no: String,
        area: String,
//        state: String,
//        city: String,
        pincode: String,
        address_type: String,
    ): Response<EditAddressResponse>

    suspend fun RemedySuggested(token:String):
            Response<RemedySuggestedResponse>

    suspend fun RemedyProduct(token:String):
            Response<RemedyProductResponse>


    suspend fun get_puja_list(
        token: String,
        ):Response<RemedyPoojaResponse>

    suspend fun live_astrologer_user(token:String,astro_id: String,channel_name: String,status: String):
            Response<CommonResponse>

    suspend fun user_astro_connect_status(token:String,channel_name: String):
            Response<UserAstroConnectStatusResponse>

    suspend fun ShopwithusViewall(token:String):
            Response<ShopwithusViewallResponse>

    suspend fun Chat(token:String,expertise_id: String,sort_filter: String):
            Response<ChatFragmentResponse>

    suspend fun CategoryList(token:String,id:String):
            Response<CategoryProductResponse>

    suspend fun ProductDetails(token:String,id:String):
            Response<ProductResponse>

    suspend fun Call(token:String,expertise_id: String,sort_filter: String):
            Response<ChatFragmentResponse>
    suspend fun EditProfile(token:String, name: RequestBody, mobile_no: RequestBody, email: RequestBody, dob: RequestBody, address: RequestBody,
                            birth_time: RequestBody,gender: RequestBody,/* state: RequestBody,
                            city: RequestBody,*/ profile: MultipartBody.Part):
            Response<CommonResponse>

//    suspend fun StateList(): Response<StateList>
    suspend fun maritials_list(token:String): Response<MaritalStatusList>
//    suspend fun CityList(id:Int): Response<CityList>

    suspend fun banner(token:String):
            Response<BannerResponse>

    suspend fun cart_item_count(token: String):
            Response<CartCountResponse>

    suspend fun OrderDetails(token:String,product_id:String,address_id:String,type: String,coupon_code: String,): Response<MyCartResponse>

    suspend fun HistoryWallet(token: String):
            Response<HistoryWallet>

    suspend fun history_call(token: String):
            Response<CallHistoryResponse>

    suspend fun history_chat(token: String):
            Response<ChatHistoryResponse>
    suspend fun history_reports(token: String):
            Response<ReportsHistoryResponse>
    suspend fun OrderPlaced(
        token: String,
        product_id: String,
        product_price: String,
        shipping_chard: String,
        coupon_discount: String,
        grand_total: String,
        coupon_code: String,
        address_id: String,
        qty: String,
        transaction_id: String,
        payment_status: String,
        payment_type: String,
    ): Response<PlaceOrderResponse>

    suspend fun history_products(token: String,type:String):
            Response<HistoryProductSuggestedResponse>

    suspend fun cart_lists(token: String,coupon_code: String,address_id: String):
            Response<CartListResponse>

    suspend fun get_chat_with_us(token:String):
            Response<GetCustomerSupportChat>

    suspend fun call_ring_status_save(token:String,channel_name: String):
            Response<call_ring_status_save_Response>

    suspend fun call_ring_end(token:String,channel_name: String):
            Response<CommonResponse>

    suspend fun send_chat_with_us(token:String,message:String):
            Response<CommonResponse>

    suspend fun kundli_match(
        token: String,
        boy_name: String,
        boy_birth_date: String,
        boy_birth_time: String,
        boy_birth_place: String,
        girl_name: String,
        girl_birth_date: String,
        girl_birth_time: String,
        girl_birth_place: String,
    ):
            Response<MakeKundaliResponse>

    suspend fun user_my_reveiw(token: String):
            Response<MyReviewsResponse>

    suspend fun my_orders(token: String,type:String):
            Response<MyOrdersEcommersProductResponse>

    suspend fun get_intake_report(token: String):
            Response<GetIntakeResponse>

    suspend fun booking_detail(token: String,order_id:String,product_id: String,):
            Response<BookingDetailsResponse>

    suspend fun strologer_details(token: String, id: String,):
            Response<AstrorahiResponse>

    suspend fun consultancy_order(token: String):
            Response<ConsultancyOrderResponse>

    suspend fun consultancy_order_detail(token: String, id: String):
            Response<ConsultancyDetail>


    suspend fun user_give_review(token: String,astro_id: String,rating: String,review: String,caller_id: String,type: String):
            Response<GiveReviewResponse>

    suspend fun product_give_review(token: String,product_id: String,rating: String,review: String,):
            Response<GiveReviewResponse>


    suspend fun strologer_availability(token: String,id: String,):Response<AvailabilityResponse>

    suspend fun recharg_amount_list(
        token: String,

        ): Response<RechargeAmountDiscountResponse>

    suspend fun MatchMaking(
        token: String,
        boy_name: String,
        dob_boy: String,
        birth_time_boy: String,
        place_birth_boy: String,
        occupation_boy: String,
//        maritial_status_boy: String,
//        topic_consultation_boy: String,
        girl_name: String,
        dob_girl: String,
        birth_time_girl: String,
        place_birth_girl: String,
        occupation_girl: String,
//        maritial_status_girl: String,
//        topic_consultation_girl: String,
        request_type: String,
        astro_id: String,
        language_id: String
    ): Response<MatchMakingResponse>

    suspend fun help(
        token: String,
        astro_id: String,
        message: String,
        booking_id: String
    ): Response<CommonResponse>

    suspend fun Notification_Read(token:String):
            Response<CommonResponse>

    suspend fun missed_requests(
        token: String
    ): Response<MissedCallChatResponse>

    suspend fun Language(token:String):
            Response<LanguageResponse>
    suspend fun add_user_details_first(
        token: String,
        name: String,
        dob: String,
        birth_time: String,
        place_birth: String,
        occupation: String,
        maritial_status: String,
        topic_consultation: String,
        language_id: String,
        astro_id: String,
        request_type: String,
//        state: String,
//        city: String,
        gender: String,
        fixed_session :String,
        fixed_session_type :String,
        slot_date :String,
        slot_time :String,
    ):
            Response<IntakeResponse>


    suspend fun agora_generate_tokenApi(token:String,  astro_id: String, call_type: String):
            Response<AgoraGenerateTokenResponse>

    suspend fun agora_create_userApi(token:String, to_userId:String, nickname:String):
            Response<AgoraCreateUserResponse>

    suspend fun chat_list_MessageApi(token:String,  to_id: String):
            Response<ChatListMessageResponse>

    suspend fun chatagoraApi(token:String,  to_userId: String, message: String, type: String):
            Response<ChatAgoraResponse>

    suspend fun reason_cancel_list(token: String):
            Response<CancelReasonResponse>
    suspend fun strologers_list(token: String):
            Response<AstrologersListViewAllResponse>

    suspend fun check_chat_end(token:String,caller_id: String):
            Response<CheckChatEndResponse>

    suspend fun get_address(token: String,id: String,):
            Response<GetAddressResponse>

    suspend fun planets(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String
    ): Response<PlanetsResponse>

    suspend fun navamsa_chart(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String
    ): Response<NavmsaResponse>


    suspend fun dThreechart(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String
    ): Response<DThreeChartResponse>

    suspend fun match_making(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String,
        fyear: String,
        fmonth: String,
        fdate: String,
        fhours: String,
        fminutes: String,
        fseconds: String,
        flatitude: String,
        flongitude: String,
        ftimezone: String,
    ): Response<KundliMatchMakingResponse>


    suspend fun insert_recently_see_kundali(
        token:String,
        name : String,
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String,
        BirthPlace: String,
    ): Response<SendKundliResponse>

    suspend fun recently_see_kundali(
        token:String,
        type: String
    ): Response<RecentSeeKundliResponse>

    suspend fun call_end_by_status(token:String,caller_id: String):
            Response<CallendbyuserResponse>
    suspend fun request_for_report(
        token: String,
        dob: String,
        birth_time: String,
        place_birth: String,
        occupation: String,
        maritial_status: String,
        topic_consultation: String,
        astro_id: String,
    ):
            Response<CommonResponse>

    suspend fun delete_address(token:String,id:String):
            Response<CommonResponse>

    suspend fun cancel_order(token:String,order_id: String,id:String,reason_ids: String,write_reason: String,):
            Response<CommonResponse>

    suspend fun call_end(token:String,timer:String,from_user: String,to_user: String,caller_id:String,type:String):
            Response<CommonResponse>

    suspend fun when_call_start(token:String,astro_id: String):
            Response<CallStartResponse>

    suspend fun add_money(token:String,amount: String,payment_status: String,transaction_id: String,):
            Response<CommonResponse>

    suspend fun get_report_astro_list(token: String):
            Response<AstrologersListViewAllResponse>

    suspend fun get_report_astro_details(token: String,astro_id:String):
            Response<GetAstroDetailsResponse>

    suspend fun waiting_chat_list(token: String):
            Response<WaitingListResponse>

    suspend fun waiting_call_list(token: String):
            Response<WaitingListResponse>

    suspend fun chat_cancel_by_user(token: String,id: String):
            Response<CommonResponse>

    suspend fun get_blog_detail(token: String,id: String):
            Response<GetBlogDetailResponse>

    suspend fun get_blog_list(token: String):
            Response<BlogListResponse>

    suspend fun chat_accepted(token:String):
            Response<ChatAcceptedResponse>

    suspend fun get_astro_slot(token:String,date: String,astro_id:String):
            Response<GetAstroSlotsResponse>

    suspend fun call_cancel_by_user(token: String,id: String):
            Response<CommonResponse>

    suspend fun call_accepted(token:String):
            Response<ChatAcceptedResponse>

    suspend fun requests_wait_delete(token: String):
            Response<CommonResponse>

    suspend fun add_report_intake(
        token: String,
        astro_id: String,
        report_id: String,
        full_name: String,
        gender: String,
        dob: String,
        birth_time: String,
        place_birth: String,
        occupation: String,
        maritial_status: String,
        topic_consultation: String,
        language_id: String,

    ): Response<CommonResponse>

    suspend fun view_report_doc_upload(token: String,id:String,):
            Response<ViewReportResponse>

    suspend fun chat_end(token:String,timer:String,from_user: String,to_user: String,caller_id:String,type: String):
            Response<CommonResponse>


    suspend fun report_intake_detail(
        token: String,
        id: String
    ): Response<ReportIntakeDetail>

    suspend fun call_ring(token: String,astro_id:String,user_id:String,request_id: String):
            Response<CallRingResponse>

    suspend fun call_received(token: String,unique_id:String):
            Response<CommonResponse>
}




