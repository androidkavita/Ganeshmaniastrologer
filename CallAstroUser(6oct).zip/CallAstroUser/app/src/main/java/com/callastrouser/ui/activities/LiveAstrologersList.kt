package com.callastrouser.ui.activities

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.R
import com.callastrouser.adapter.Click
import com.callastrouser.adapter.LiveastrologerviewallAdapter
import com.callastrouser.databinding.ActivityFixSessionBinding
import com.callastrouser.databinding.FragmentLiveAstrologersListBinding
import com.callastrouser.model.LiveastrologerviewallResponseData
import com.callastrouser.ui.fragments.GoLiveFragment
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.HomeViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LiveAstrologersList : BaseFragment(), Click {
    lateinit var binding: FragmentLiveAstrologersListBinding
    lateinit var adapter: LiveastrologerviewallAdapter
    var Listdata: ArrayList<LiveastrologerviewallResponseData> = ArrayList()
    private val viewModel: HomeViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentLiveAstrologersListBinding.inflate(inflater,container,false)

//        binding.header.backArrow.setOnClickListener {
//            finish()
//        }
//        binding.header.tvHeadName.text = "Live Astrologers"
        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.Liveastrologersviewall(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            toast("Please check internet connection.")
        }


        viewModel.liveastrologersviewallResponse.observe(viewLifecycleOwner){
            if (it.status == 1){
                binding.idNouser.visibility = View.GONE
                binding.rvPurchasedProducts.visibility = View.VISIBLE
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = LiveastrologerviewallAdapter(requireContext(),Listdata,this)
                binding.rvPurchasedProducts.adapter = adapter
                adapter.notifyDataSetChanged()
            }else {
               binding.idNouser.visibility = View.VISIBLE
               binding.rvPurchasedProducts.visibility = View.GONE
                binding.nodatatext.text = "No astrologer is live."
            }
        }

        return binding.root
    }
    override fun liveastro(id: String, channelname: String, agora_token: String,name:String,Profile:String,calling_charg:String) {
        startActivity(Intent(requireContext(),LiveActivity::class.java)
            .putExtra("channelname",channelname)
            .putExtra("agora_token",agora_token)
            .putExtra("name",name)
            .putExtra("id",id)
            .putExtra("profile",Profile)
            .putExtra("calling_charg",calling_charg)
        )
    }

    override fun onResume() {

        super.onResume()
        viewModel.Liveastrologersviewall(
            "Bearer "+userPref.getToken().toString()
        )
        Log.d("TAG", "onResume: "+" on Resume ")

    }

    override fun onPause() {
        viewModel.Liveastrologersviewall(
            "Bearer "+userPref.getToken().toString()
        )
        super.onPause()

        Log.d("TAG", "onPause: "+" on pause")

    }

    override fun onStop() {
        viewModel.Liveastrologersviewall(
            "Bearer "+userPref.getToken().toString()
        )
        super.onStop()

        Log.d("TAG", "onStop: "+" on stop")

    }

    override fun onAttach(context: Context) {
        Log.d("TAG", "onAttach: "+"   onAttach ")
        super.onAttach(context)



    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d("TAG", "onViewCreated: "+" on view created")
    }

    override fun onStart() {
        super.onStart()
        Log.d("TAG", "onStart: "+" on start")
    }

}