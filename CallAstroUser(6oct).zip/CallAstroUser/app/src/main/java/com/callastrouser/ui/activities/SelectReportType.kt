package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.GetDeitails
import com.callastrouser.adapter.GetDetailsReportAdapter
import com.callastrouser.databinding.ActivitySelectReportTypeBinding
import com.callastrouser.model.ChatFragmentResponseData
import com.callastrouser.model.GetAstroDetailsResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.GetReportViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class SelectReportType : BaseActivity(), GetDeitails {
    lateinit var binding: ActivitySelectReportTypeBinding
    lateinit var adapter: GetDetailsReportAdapter
    lateinit var astroid:String
    var scpflag: String = ""
    private val viewModel: GetReportViewModel by viewModels()
    var Listdata: ArrayList<GetAstroDetailsResponseData> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_report_type)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_select_report_type)
        binding.header.tvHeadName.text="Select Report Type"
        binding.header.backArrow.setOnClickListener { finish() }

        if (intent != null){
            astroid = intent.getStringExtra("id").toString()
        }

        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.get_report_astro_details(
                "Bearer "+userPref.getToken().toString(),astroid
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.getAstroDetailsResponse.observe(this){
            if (it.status == 1){
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = GetDetailsReportAdapter(this@SelectReportType,Listdata,this)
                binding.rvAstrologers.adapter = adapter
            }
        }

        binding.tvSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(text: Editable?) {
                filterData(text.toString(), scpflag)
            }

        })
    }
    private fun filterData(searchText: String, scpflag: String) {
        var filteredStateList: java.util.ArrayList<GetAstroDetailsResponseData> = java.util.ArrayList()


//        if (scpflag.equals("State")) {
        for (item in Listdata) {
            try {
                if (item.title!!.toLowerCase().contains(searchText.toLowerCase())) {
                    filteredStateList.add(item)
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }


        try {
            adapter?.filterList(filteredStateList)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    override fun getid(id: String) {
        startActivity(Intent(this@SelectReportType, ReportIntakeForm::class.java)
            .putExtra("id",id)
            .putExtra("astroid",astroid))
    }
}