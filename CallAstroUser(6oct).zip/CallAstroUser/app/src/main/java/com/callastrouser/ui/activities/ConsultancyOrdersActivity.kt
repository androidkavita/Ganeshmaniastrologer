package com.callastrouser.ui.activities

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.ConsultancyAdapter
import com.callastrouser.databinding.ActivityConsultancyOrdersBinding
import com.callastrouser.databinding.HelpBinding
import com.callastrouser.model.ConsultancyOrderResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.OrderDetailsViewModel
import com.maxtra.astrorahi.interfaces.ProductDetailsconsultancy
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ConsultancyOrdersActivity : BaseActivity(), ProductDetailsconsultancy {
    lateinit var binding: ActivityConsultancyOrdersBinding
    private val viewModel: OrderDetailsViewModel by viewModels()
    var List :ArrayList<ConsultancyOrderResponseData> = arrayListOf()
    lateinit var adapter : ConsultancyAdapter
    var flag:String = "2"
    lateinit var astro_id_new:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consultancy_orders)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_consultancy_orders)

        binding.header.backArrow.setOnClickListener {
            finish()
        }

        binding.header.tvHeadName.text = "Consultancy Orders"


        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.consultancy_order(
                "Bearer "+userPref.getToken().toString())
        } else {
            toast(this,"Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.consultancyOrderResponse.observe(this){
            if (it.status == 1){
                List.clear()
                List.addAll(it.data)
                adapter = ConsultancyAdapter(this,List,this)
                binding.rvConsultancyOrders.adapter = adapter
            }else{
                snackbar(it.message.toString())
            }
        }
        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                snackbar(it.message.toString())
            }else{
                snackbar(it.message.toString())
            }
        }


    }

    private fun ADDMONEY(astroid:String,booking_id:String) {
        val cDialog = Dialog(this)
        val bindingDialog: HelpBinding = DataBindingUtil.inflate(
            LayoutInflater.from(this),
            R.layout.help,
            null,
            false
        )
        cDialog.setContentView(bindingDialog.root)
        cDialog.setCancelable(true)
        cDialog.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        cDialog.show()
        bindingDialog.btnCancel.setOnClickListener {
            cDialog.dismiss()
        }

        bindingDialog.btnLogout.setOnClickListener {
            var concern = bindingDialog.fullnameet.text.toString()
            viewModel.help("Bearer "+userPref.getToken().toString(), astroid , concern,booking_id)
            cDialog.dismiss()
        }


//        bindingDialog.btnLogout.setOnClickListener {
//            userPref.clearPref()
//            startActivity(Intent(this, LoginActivity::class.java))
//            finishAffinity()
//            cDialog.dismiss()
//        }
    }

//    override fun Details(button: Button, id: String) {
//
//    }

    override fun Details(button: Button, id: String, image: ImageView,astro_id:String,type: String) {
        button.setOnClickListener {
            startActivity(Intent(this@ConsultancyOrdersActivity, ConsultancyDetailsActivity::class.java).putExtra("id",id).putExtra("flag",flag).putExtra("type",type))
        }
        image.setOnClickListener {
            ADDMONEY(astro_id,id)
        }
    }
}