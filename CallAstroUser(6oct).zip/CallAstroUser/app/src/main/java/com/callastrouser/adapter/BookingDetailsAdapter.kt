package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.BookingsitemBinding
import com.callastrouser.model.BookingDetailsResponseData

class BookingDetailsAdapter (val context : Context, var data: ArrayList<BookingDetailsResponseData>,var click:ClickBokingDetails,var flag :String) :
    RecyclerView.Adapter<BookingDetailsAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: BookingsitemBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookingDetailsAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.bookingsitem, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: BookingDetailsAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.name.toString()
        Glide.with(context).load(List.mainImage).into(holder.binding.ivImage)
        holder.binding.qty.text = List.qty.toString()
        holder.binding.amount.text = "₹"+List.productPrice1.toString()

//        if (flag == "1"){
//            holder.binding.llSuggestRemedy.visibility = View.GONE
//            holder.binding.llRefundAmount.visibility = View.GONE
//        }else{
        if (List.status == "1"){
            holder.binding.llSuggestRemedy.visibility = View.VISIBLE
            holder.binding.llRefundAmount.visibility = View.GONE
        } else if (List.status == "3"){
            holder.binding.llSuggestRemedy.visibility = View.GONE
            holder.binding.llRefundAmount.visibility = View.GONE
        } else if (List.status == "6"){
            holder.binding.llSuggestRemedy.visibility = View.GONE
            holder.binding.llRefundAmount.visibility = View.VISIBLE
        }else if (List.status == "7"){
            holder.binding.llSuggestRemedy.visibility = View.GONE
            holder.binding.llRefundAmount.visibility = View.GONE
        }else{
            holder.binding.llSuggestRemedy.visibility = View.VISIBLE
            holder.binding.llRefundAmount.visibility = View.GONE
//            }
        }

        holder.binding.llSuggestRemedy.setOnClickListener {
            click.CancelAndrating(List.productId!!,"1",List.name.toString(),List.qty.toString(),List.mainImage.toString(),List.status.toString())
        }

        holder.binding.llRefundAmount.setOnClickListener {
            click.CancelAndrating(List.productId!!,"2",List.name.toString(),List.qty.toString(),List.mainImage.toString(),List.status.toString())
        }
        if (List.status == "1"){
            holder.binding.tvConfirmationStatus.text = "Order Placed"
        }else if (List.status == "2"){
            holder.binding.tvConfirmationStatus.text = "Accepted"
        }else if (List.status == "3"){
            holder.binding.tvConfirmationStatus.text = "Cancelled"
        }else if (List.status == "4"){
            holder.binding.tvConfirmationStatus.text = "Out for delivery"
        }else if (List.status == "5"){
            holder.binding.tvConfirmationStatus.text = "Pending"
        }else if (List.status == "6"){
            holder.binding.tvConfirmationStatus.text = "Delivered"
        }else if (List.status == "7"){
            holder.binding.tvConfirmationStatus.text = "Rejected"
        }
    }

    override fun getItemCount(): Int {
        return data.size
    }


}
interface ClickBokingDetails{
    fun CancelAndrating(id:Int,type :String,name :String,qty :String,image:String,statustype:String)
}