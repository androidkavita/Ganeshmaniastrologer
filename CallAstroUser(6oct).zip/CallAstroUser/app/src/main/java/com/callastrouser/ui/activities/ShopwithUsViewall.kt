package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.ShopwithUsViewallAdapter
import com.callastrouser.databinding.ActivityShopwithUsViewallBinding
import com.callastrouser.model.ShopwithusViewallResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.HomeViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import java.util.ArrayList

@AndroidEntryPoint
class ShopwithUsViewall : BaseActivity(),ShopwithUsViewallAdapter.Shop {
    lateinit var binding: ActivityShopwithUsViewallBinding
    lateinit var adapter: ShopwithUsViewallAdapter
    var Listdata: ArrayList<ShopwithusViewallResponseData> = ArrayList()
    private val viewModel: HomeViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shopwith_us_viewall)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_shopwith_us_viewall)

        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Shop With Us"

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        if (CommonUtils.isInternetAvailable(this@ShopwithUsViewall)) {
            viewModel.Shopwithusviewall(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }


        viewModel.shopwithusviewallResponse.observe(this){
            if (it.status == 1){
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = ShopwithUsViewallAdapter(this,Listdata,this)
                binding.rvPurchasedProducts.adapter = adapter
            }
        }


    }

    override fun layoutid(layout: LinearLayout, id: String,name: String) {
        layout.setOnClickListener {
            var intent = Intent(this,ShopWithUsItem::class.java)
            intent.putExtra("id",id)
            intent.putExtra("name",name)
            startActivity(intent)
        }
    }


}