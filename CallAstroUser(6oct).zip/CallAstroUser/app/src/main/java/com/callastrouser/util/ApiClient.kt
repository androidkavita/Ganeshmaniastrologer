package com.callastrouser.util

import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.RequestBody
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit


object ApiClient {
//    var BASE_URL = "https://api.vedicastroapi.com/v3-json/matching/"
    var BASE_URL ="https://api.kundli.click/v0.4/"
//    var BASE_URL ="http://182.76.237.251/~gocab/api/"

    var client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS).build()
    var retrofit:Retrofit? = null
    var gson = GsonBuilder()
        .setLenient()
        .create()
    fun getClient():Retrofit {
        if (retrofit !=null)
            retrofit =null

        retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL).client(client)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
        return retrofit as Retrofit
    }

//    fun getClient2():Retrofit {
//        if (retrofit !=null)
//            retrofit =null
//
//        retrofit = Retrofit.Builder()
//            .baseUrl(BASE_URL2).client(client)
//            .addConverterFactory(GsonConverterFactory.create(gson))
//            .build()
//        return retrofit as Retrofit
//    }



}
