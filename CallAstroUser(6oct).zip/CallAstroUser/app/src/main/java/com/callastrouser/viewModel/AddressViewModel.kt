package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.AddAddressResponse
import com.callastrouser.model.AddressListResponse
import com.callastrouser.model.CartListResponse
import com.callastrouser.model.CartPlaceOrderResponse
import com.callastrouser.model.CityList
import com.callastrouser.model.CityListData
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.EditAddressResponse
import com.callastrouser.model.GetAddressResponse
import com.callastrouser.model.StateList
import com.callastrouser.model.StateListData
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AddressViewModel  @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    val _progressBarVisibility = MutableLiveData<Int>()
    val addresslistResponse = MutableLiveData<AddressListResponse>()
    val add_addressResponse = MutableLiveData<AddAddressResponse>()
    val getAddressResponse = MutableLiveData<GetAddressResponse>()
    val edit_addressResponse = MutableLiveData<EditAddressResponse>()
    val commonResponse = MutableLiveData<CommonResponse>()
    var stateListData = MutableLiveData<ArrayList<StateListData>>()
    var statlistResponse = MutableLiveData<StateList>()
    var citylistResponse = MutableLiveData<CityList>()
    var citylistData = MutableLiveData<ArrayList<CityListData>>()
    val cartListResponse = MutableLiveData<CartListResponse>()
    val cartPlaceOrderResponse = MutableLiveData<CartPlaceOrderResponse>()


    fun AddressList(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.AddressList(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                addresslistResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }
    fun cart_place_order(
        token: String,
        address_id:String,
        payment_status:String,
        payment_type:String,
        transaction_id:String,
        orderfrom: String,
        product_id: String,
        coupon_discount: String,
        qty: String,


        ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.cart_place_order(token,address_id,payment_status,payment_type,transaction_id,orderfrom,product_id,coupon_discount,qty)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                cartPlaceOrderResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun AddAddress(
        token:String,
        full_name:String,
        phone_no: String,
        house_no: String,
        area: String,
//        state: String,
//        city: String,
        pincode: String,
        address_type: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.AddAddress(token,full_name,phone_no,house_no,area/*,state,city*/,pincode,address_type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                add_addressResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun get_address(
        token:String,
        id:String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.get_address(token,id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                getAddressResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }



//    fun StateListAPI(): MutableLiveData<StateList> {
//        if (statlistResponse == null) {
//            statlistResponse = MutableLiveData()
//        }
//        progressBarStatus.value = true
//        viewModelScope.launch {
//            try {
//                val response = mainRepository.StateList()
//
//                if (response.isSuccessful) {
//                    progressBarStatus.value = false
//                    statlistResponse.postValue(response.body())
//                }
//            }catch (e:Exception) {
//                _progressBarVisibility.postValue(0)
//                e.printStackTrace()
//            }
//        }
//        return statlistResponse
//    }


//    fun CityListAPI(
//        id:Int
//    ): MutableLiveData<CityList> {
//        if (citylistResponse == null) {
//            citylistResponse = MutableLiveData()
//        }
//        progressBarStatus.value = true
//        viewModelScope.launch {
//            try {
//                val response = mainRepository.CityList(id)
//
//                if (response.isSuccessful) {
//                    progressBarStatus.value = false
//                    citylistResponse.postValue(response.body())
//                }
//            }catch (e:Exception) {
//                _progressBarVisibility.postValue(0)
//                e.printStackTrace()
//            }
//        }
//        return citylistResponse
//    }

    fun DeleteAddress(
        token:String,
        id:String,

    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.delete_address(token,id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun UpdateAddress(
        token: String,
        address_id: String,
        full_name: String,
        phone_no: String,
        house_no: String,
        area: String,
//        state: String,
//        city: String,
        pincode: String,
        address_type: String,

        ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.UpdateAddress(token,address_id, full_name, phone_no, house_no, area/*, state, city*/, pincode, address_type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                edit_addressResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }



}