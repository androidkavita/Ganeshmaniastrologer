package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class AstrologersListViewAllResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<AstrologersListViewAllResponseData> = arrayListOf()
)
data class AstrologersListViewAllResponseData(
    @SerializedName("id"           ) var id          : Int?              = null,
    @SerializedName("name"         ) var name        : String?           = null,
    @SerializedName("experence_id" ) var experenceId : Int?              = null,
    @SerializedName("profile"      ) var profile     : String?           = null,
    @SerializedName("rating"       ) var rating     : String?           = null,
    @SerializedName("request"      ) var request     : Int?           = null,
    @SerializedName("calling_charg") var calling_charg     : String?           = null,
    @SerializedName("expertise"    ) var expertise   : String?           = null,
    @SerializedName("language"     ) var language    : String?           = null,
    @SerializedName("experence"    ) var experence   : String?           = null
)