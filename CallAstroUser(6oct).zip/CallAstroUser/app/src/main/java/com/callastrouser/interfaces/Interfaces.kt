package com.maxtra.astrorahi.interfaces

import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.widget.LinearLayoutCompat

interface CallChat {
    fun callchatLL(linear :LinearLayoutCompat,id:String,astroname:String,layoutclick:LinearLayout)
}
interface VideoCallChat {
    fun VideocallchatLL(linear :LinearLayoutCompat,id:String,astroname:String,layoutclick:LinearLayout)
}
interface ProductDetails{
    fun Details(button:Button,id: String,order_id:String)
}
interface CallVideo {
    fun callchatLL(linear :ImageView,id:String,type:String)
}
interface Chats {
    fun callchatLL(linear :LinearLayout,id:String,name:String)
}
interface ProductDetailsconsultancy{
    fun Details(button:Button,id: String,image:ImageView,astro_id:String,type: String)
}