package com.callastrouser.ui.activities

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.databinding.ActivityEditAddressBinding
import com.callastrouser.model.CityListData
import com.callastrouser.model.StateListData
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.toast
import com.callastrouser.viewModel.AddressViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class EditAddress : BaseActivity() {
    lateinit var binding:ActivityEditAddressBinding
    lateinit var addressid:String
    private val viewModel: AddressViewModel by viewModels()
//    var statedata :ArrayList<StateListData> = arrayListOf()
//    var statenamedata :ArrayList<String> = arrayListOf()
//    var idstatedata :ArrayList<String> = arrayListOf()
//    var citydata :ArrayList<CityListData> = arrayListOf()
//    var citynamedata :ArrayList<String> = arrayListOf()
//    var idcitydata :ArrayList<String> = arrayListOf()
//    var selectedStateId= ""
    var addresstype = "1"
//    lateinit var selectedCityId :String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_address)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_edit_address)

        addressid = intent.getStringExtra("addressid").toString()



        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Edit Address"

//        if (CommonUtils.isInternetAvailable(this@EditAddress)) {
//            StateAPI()
//        } else {
//            Log.d("TAG", "onCreate: " + "else part")
//            toast(this,"Please check internet connection.")
//        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.edit_addressResponse.observe(this) {
            if (it.status == 1) {
                finish()
                toast(it.message.toString())
            } else {

            }
        }

//        binding.State.onItemSelectedListener = object :
//            AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
//                selectedStateId=idstatedata[p2]
//                CityAPI()
//            }
//            override fun onNothingSelected(p0: AdapterView<*>?) {
//
//            }
//        }
//        binding.city.onItemSelectedListener = object :
//            AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
//                selectedCityId=idcitydata[p2]
//            }
//            override fun onNothingSelected(p0: AdapterView<*>?) {
//
//            }
//        }


    if (CommonUtils.isInternetAvailable(this@EditAddress)) {
        viewModel.get_address(
            "Bearer " + userPref.getToken().toString(),
            addressid
        )
    } else {
        Log.d("TAG", "onCreate: " + "else part")
        toast(this,"Please check internet connection.")
    }
    viewModel.getAddressResponse.observe(this) {
        if (it.status == 1) {
            binding.fullnameet.setText(it.data?.fullName)
            binding.mobile.setText(it.data?.phoneNo)
            binding.houseno.setText(it.data?.houseNo)
            binding.area.setText(it.data?.area)
            binding.pincode.setText(it.data?.pincode)
            if (it.data?.addressType == 1){
                binding.homeLinear.setBackgroundResource(R.drawable.focus)
                binding.officeLinear.setBackgroundResource(R.drawable.background_focus_black)
                binding.hometext.text = "Home"
                binding.hometext.setTextColor(Color.parseColor("#742086"))
                binding.officetext.setTextColor(Color.parseColor("#FF000000"))
//            binding.homeicon.setBackgroundColor((ContextCompat.getColor(getActivity(), R.color.theme_purple))
                binding.homeicon.setImageResource(R.drawable.ic_home_address)
                binding.officeicon.setImageResource(R.drawable.office)
            }else{
                binding.homeLinear.setBackgroundResource(R.drawable.background_focus_black)
                binding.officeLinear.setBackgroundResource(R.drawable.focus)
                binding.officetext.text = "Office"
                binding.officetext.setTextColor(Color.parseColor("#742086"))
                binding.hometext.setTextColor(Color.parseColor("#FF000000"))
                binding.homeicon.setImageResource(R.drawable.blackhome)
                binding.officeicon.setImageResource(R.drawable.color_bag)
            }
        } else {

        }
    }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.edit_addressResponse.observe(this) {
            if (it.status == 1) {
                finish()
                toast(it.message.toString())
            } else {

            }
        }

        binding.homeLinear.setBackgroundResource(R.drawable.focus)
        binding.officeLinear.setBackgroundResource(R.drawable.background_focus_black)
        binding.hometext.text = "Home"
        binding.hometext.setTextColor(Color.parseColor("#742086"))
        binding.officetext.setTextColor(Color.parseColor("#FF000000"))
//            binding.homeicon.setBackgroundColor((ContextCompat.getColor(getActivity(), R.color.theme_purple))
        binding.homeicon.setImageResource(R.drawable.ic_home_address)
        binding.officeicon.setImageResource(R.drawable.office)

        binding.homeLinear.setOnClickListener {
            addresstype = "1"
            binding.homeLinear.setBackgroundResource(R.drawable.focus)
            binding.officeLinear.setBackgroundResource(R.drawable.background_focus_black)
            binding.hometext.text = "Home"
            binding.hometext.setTextColor(Color.parseColor("#742086"))
            binding.officetext.setTextColor(Color.parseColor("#FF000000"))
//            binding.homeicon.setBackgroundColor((ContextCompat.getColor(getActivity(), R.color.theme_purple))
            binding.homeicon.setImageResource(R.drawable.ic_home_address)
            binding.officeicon.setImageResource(R.drawable.office)
        }

        binding.officeLinear.setOnClickListener {
            addresstype = "2"
            binding.homeLinear.setBackgroundResource(R.drawable.background_focus_black)
            binding.officeLinear.setBackgroundResource(R.drawable.focus)
            binding.officetext.text = "Office"
            binding.officetext.setTextColor(Color.parseColor("#742086"))
            binding.hometext.setTextColor(Color.parseColor("#FF000000"))
            binding.homeicon.setImageResource(R.drawable.blackhome)
            binding.officeicon.setImageResource(R.drawable.color_bag)
        }


        binding.btnSaveContinue.setOnClickListener {
            if (binding.fullnameet.text.isNullOrEmpty()){
                snackbar("Please enter full name.")
            }else if (binding.mobile.text.isNullOrEmpty()){
                snackbar("Please enter mobile.")
            }else if (binding.mobile.text.length < 10){
                snackbar("Please enter valid mobile.")
            }else if (binding.houseno.text.isNullOrEmpty()){
                snackbar("Please enter house number.")
            }else if (binding.area.text.isNullOrEmpty()){
                snackbar("Please enter area.")
            }else if (binding.pincode.text.isNullOrEmpty()){
                snackbar("Please enter pincode.")
            }else{
                if (CommonUtils.isInternetAvailable(this@EditAddress)) {
                    viewModel.UpdateAddress(
                        "Bearer " + userPref.getToken().toString(),
                        addressid,
                        binding.fullnameet.text.toString(),
                        binding.mobile.text.toString(),
                        binding.houseno.text.toString(),
                        binding.area.text.toString(),
//                        selectedStateId,
//                        selectedCityId,
                        binding.pincode.text.toString(),
                        addresstype
                    )
                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this,"Please check internet connection.")
                }

            }
        }



    }

//    fun StateAPI(){
//        viewModel.StateListAPI().observe(this) {
//            if (it!!.status == 1) {
//                statedata.clear()
//                statenamedata.clear()
//                statedata.addAll(it!!.data)
//                viewModel.stateListData.value = it.data
//                for (i in 0 until it.data.size) {
//                    statenamedata.add(it.data[i].stateName.toString())
//                    idstatedata.add(it.data[i].id.toString())
//                }
//                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
//                    this,
//                    android.R.layout.simple_spinner_dropdown_item,
//                    statenamedata
//                )
//                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                binding.State.adapter = spinnerArrayAdapter
//            }
//        }
//    }

//    fun CityAPI(){
//        viewModel.CityListAPI(
//            selectedStateId.toInt()
//        ).observe(this) {
//            if (it!!.status == 1) {
//                citydata.clear()
//                citynamedata.clear()
//                citydata.addAll(it!!.data)
//                viewModel.citylistData.value = it.data
//                for (i in 0 until it.data.size) {
//                    citynamedata.add(it.data[i].cityName.toString())
//                    idcitydata.add(it.data[i].id.toString())
//                }
//                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
//                    this,
//                    android.R.layout.simple_spinner_dropdown_item,
//                    citynamedata
//                )
//                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                binding.city.adapter = spinnerArrayAdapter
//            }
//        }
//    }
}