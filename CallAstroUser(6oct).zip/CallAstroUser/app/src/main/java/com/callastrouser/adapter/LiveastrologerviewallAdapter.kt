package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowLiveastrologersBinding
import com.callastrouser.databinding.RowLiveastrologersSeeallBinding
import com.callastrouser.model.LiveastrologerviewallResponseData

class LiveastrologerviewallAdapter(
    val context: Context,
    var data: ArrayList<LiveastrologerviewallResponseData>,
    var liveclick: Click
) :
    RecyclerView.Adapter<LiveastrologerviewallAdapter.ViewHolder>() {
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var binding: RowLiveastrologersSeeallBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): LiveastrologerviewallAdapter.ViewHolder {
        val itemView =
            LayoutInflater.from(parent.context).inflate(R.layout.row_liveastrologers_seeall, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: LiveastrologerviewallAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.name
        holder.binding.topic.text = List.topic
        Glide.with(context).load(List.profile).into(holder.binding.rvImgs)

        holder.binding.linearItem.setOnClickListener {
            liveclick.liveastro(
                List.id.toString(),
                List.channel_name.toString(),
                List.agora_token.toString(),
                List.name.toString(),
                List.profile.toString(),
                List.calling_charg.toString()
            )
        }





        }

    override fun getItemCount(): Int {
        return data.size
    }
}

interface Click {
    fun liveastro(
        id: String,
        channelname: String,
        agora_token: String,
        name: String,
        Profile: String,
        calling_charg: String,
    )
}