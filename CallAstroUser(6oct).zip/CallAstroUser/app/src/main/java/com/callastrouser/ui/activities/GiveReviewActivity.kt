package com.callastrouser.ui.activities

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.ActivityGiveReviewConsultancyBinding
import com.callastrouser.databinding.ActivityGiveReviewProductBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.toast
import com.callastrouser.viewModel.CustomerViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class GiveReviewActivity : BaseActivity() {
    lateinit var binding: ActivityGiveReviewProductBinding
    private val viewModel: CustomerViewModel by viewModels()
    lateinit var name:String
    lateinit var quantity:String
    lateinit var price:String
    lateinit var image:String
    lateinit var bookingId:String
    lateinit var product_id:String
    lateinit var date:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_give_review_product)

        binding = DataBindingUtil.setContentView(this,R.layout.activity_give_review_product)
        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text ="Give Review"

        if (intent!=null){
            name = intent.getStringExtra("name").toString()
            quantity = intent.getStringExtra("quantity").toString()
            price = intent.getStringExtra("price").toString()
            image = intent.getStringExtra("image").toString()
            bookingId = intent.getStringExtra("bookingId").toString()
            date = intent.getStringExtra("date").toString()
            product_id = intent.getStringExtra("product_id").toString()
        }

        binding.tvHead.text = name
        binding.quantity.text= quantity
        binding.price.text= price
        binding.bookingid.text= bookingId
        binding.date.text= date
        Glide.with(this@GiveReviewActivity).load(image).into(binding.ivImage)

        viewModel.givereviewResponse.observe(this){
            if (it.status == 1){
                toast("Ratings and reviews sent successfully.")
                finish()
            }else{
                snackbar(it.message.toString())
            }
        }
        binding.btnSubmit.setOnClickListener{
            if (CommonUtils.isInternetAvailable(this@GiveReviewActivity)) {
                viewModel.product_give_review(
                    "Bearer "+userPref.getToken().toString(),
                    product_id.toString(),binding.rating.toString(),binding.etReason.text.toString(),
                )
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast(this@GiveReviewActivity,"Please check internet connection.")
            }


        }

    }
}