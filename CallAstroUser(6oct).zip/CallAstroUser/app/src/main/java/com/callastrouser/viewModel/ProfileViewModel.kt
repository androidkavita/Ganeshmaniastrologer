package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.CityList
import com.callastrouser.model.CityListData
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.MyReviewsResponse
import com.callastrouser.model.StateList
import com.callastrouser.model.StateListData
import com.callastrouser.model.ViewProfile
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    val viewProfileResponse = MutableLiveData<ViewProfile>()
    val myreviewsResponse = MutableLiveData<MyReviewsResponse>()
    val commonResponse = MutableLiveData<CommonResponse>()
    var stateListData = MutableLiveData<ArrayList<StateListData>>()
    var statlistResponse = MutableLiveData<StateList>()
    var citylistResponse = MutableLiveData<CityList>()
    var citylistData = MutableLiveData<ArrayList<CityListData>>()
    val _progressBarVisibility = MutableLiveData<Int>()

    fun ViewProfile(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.ViewProfile(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                viewProfileResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun EditProfile(
        token: String,
        name: String,
        mobile_no: String,
        email: String,
        dob: String,
        address: String,
        birth_time: String,
        gender: String,
//        state: String,
//        city: String,
        profile: MultipartBody.Part
    ) {
        val name: RequestBody = RequestBody.create(MediaType.parse("text/plain"), name)
        val mobile_no: RequestBody = RequestBody.create(MediaType.parse("text/plain"), mobile_no)
        val email: RequestBody = RequestBody.create(MediaType.parse("text/plain"), email)
        val dob: RequestBody = RequestBody.create(MediaType.parse("text/plain"), dob)
        val address: RequestBody = RequestBody.create(MediaType.parse("text/plain"), address)
        val birth_time: RequestBody = RequestBody.create(MediaType.parse("text/plain"), birth_time)
        val gender: RequestBody = RequestBody.create(MediaType.parse("text/plain"), gender)
//        val state: RequestBody = state.toRequestBody("text/plain".toMediaTypeOrNull())
//        val city: RequestBody = city.toRequestBody("text/plain".toMediaTypeOrNull())

        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.EditProfile(token,name,mobile_no,email,dob,address,birth_time,gender,/*,state,city*/profile)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }
//    fun StateListAPI(): MutableLiveData<StateList> {
//        if (statlistResponse == null) {
//            statlistResponse = MutableLiveData()
//        }
//        progressBarStatus.value = true
//        viewModelScope.launch {
//            try {
//                val response = mainRepository.StateList()
//
//                if (response.isSuccessful) {
//                    progressBarStatus.value = false
//                    statlistResponse.postValue(response.body())
//                }
//            }catch (e:Exception) {
//                _progressBarVisibility.postValue(0)
//                e.printStackTrace()
//            }
//        }
//        return statlistResponse
//    }


//    fun CityListAPI(
//        id:Int
//    ): MutableLiveData<CityList> {
//        if (citylistResponse == null) {
//            citylistResponse = MutableLiveData()
//        }
//        progressBarStatus.value = true
//        viewModelScope.launch {
//            try {
//                val response = mainRepository.CityList(id)
//
//                if (response.isSuccessful) {
//                    progressBarStatus.value = false
//                    citylistResponse.postValue(response.body())
//                }
//            }catch (e:Exception) {
//                _progressBarVisibility.postValue(0)
//                e.printStackTrace()
//            }
//        }
//        return citylistResponse
//    }


    fun MyReviews(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.user_my_reveiw(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                myreviewsResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }


    }

}