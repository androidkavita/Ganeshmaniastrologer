package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class HistoryProductSuggestedResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<HistoryProductSuggestedData> = arrayListOf()
)
data class HistoryProductSuggestedData(
    @SerializedName("id"       ) var id      : Int? = null,
    @SerializedName("order_date"       ) var order_date      : String? = null,
    @SerializedName("product_id"       ) var product_id      : String? = null,
    @SerializedName("name"       ) var name      : String? = null,
    @SerializedName("price"      ) var price     : String? = null,
    @SerializedName("main_image" ) var mainImage : String? = null
)