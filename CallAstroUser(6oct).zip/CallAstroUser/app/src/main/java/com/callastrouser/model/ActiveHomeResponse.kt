package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ActiveHomeResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : ActiveHomeResponseData?   = ActiveHomeResponseData()
)
data class ActiveHomeResponseData(
    @SerializedName("home" ) var home : Int? = null
)
