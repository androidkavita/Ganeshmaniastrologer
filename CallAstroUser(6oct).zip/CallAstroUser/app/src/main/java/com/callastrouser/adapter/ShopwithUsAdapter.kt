package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowEShopBinding
import com.callastrouser.model.Shopwithus

class ShopwithUsAdapter (val context : Context, var data: ArrayList<Shopwithus>, var transfer: Shops) :
    RecyclerView.Adapter<ShopwithUsAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowEShopBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShopwithUsAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_e_shop, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ShopwithUsAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.categoryName
        Glide.with(context).load(List.categoryImage).into(holder.binding.rvImgs)
        transfer.layoutid(holder.binding.img,List.id.toString(),List.categoryName.toString())
    //        holder.binding.linearItem.setOnClickListener(View.OnClickListener {
//            val intent = Intent(context, DriverDetailActivity::class.java)
//            intent.putExtra("orderType", "4")
//            intent.putExtra("id",List.id)
//            context.startActivity(intent)
//        })
    }

    override fun getItemCount(): Int {
        return data.size
    }
}

interface Shops{
    fun layoutid(layout: LinearLayout, id:String, name:String)
}