package com.callastrouser.ui.activities

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.databinding.DataBindingUtil
import com.airbnb.lottie.LottieAnimationView
import com.callastrouser.R
import com.callastrouser.databinding.ActivityPaymentInformationBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.WalletViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject

@AndroidEntryPoint
class PaymentInformation : BaseActivity() , PaymentResultListener {
    private lateinit var binding: ActivityPaymentInformationBinding
    var isPaymentDone=false
    var amt :String=""
    var discounts :String=""
    private val viewModel : WalletViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_information)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_payment_information)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Payment Information"

        if (intent!=null){
            amt = intent.getStringExtra("amount").toString()
            discounts = intent.getStringExtra("discount").toString()
        }
        binding.totalamount.text = "₹$amt"

        var totalamount = (amt.toFloat() * 18)/100
        binding.gst.text = "₹"+"%.2f".format(totalamount).toString()
        var payableamount = "%.2f".format(amt.toInt()+totalamount)
        binding.payableamount.text = "₹$payableamount"

        if (discounts == "null"){
            binding.discount.visibility = View.GONE
        }else{
            binding.discount.visibility = View.VISIBLE
            binding.discount.text = "$discounts% extra on recharge of ₹$amt"
        }

        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                toast(this@PaymentInformation,it.message.toString())
                paymentDialog(this)

            }
        }

        binding.btnSubmit.setOnClickListener {
            startPayment(payableamount.toString())
        }

    }
    private fun startPayment(amt:String) {
        val activity: Activity = this
        val co = Checkout()
//        co.setKeyID("rzp_test_GtInU79qatMxhL")
        co.setKeyID("rzp_test_wUqHQQPq0YcTZ2")

        try {

            var amount=amt.toDouble()
            val options = JSONObject()
            options.put("name", "Call Astro")
            options.put("description", "s")
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("currency", "INR")
            options.put("amount",amount*100)
//            val preFill = JSONObject()
            /* preFill.put("email", userPref.getEmail())
             preFill.put("contact", userPref.getmobile())*/
            //  options.put("prefill", preFill)
            co.open(activity, options)
        } catch (e: Exception) {
            Toast.makeText(activity, "Error in payment: " + e.message, Toast.LENGTH_SHORT)
                .show()
            e.printStackTrace()
        }
    }

    override fun onPaymentSuccess(razorpayPaymentID: String) {
        try {
            //   val finalAmount  = amount/100
            Toast.makeText(this, "Payment Successful: $razorpayPaymentID", Toast.LENGTH_SHORT)
//                .show()
            isPaymentDone=true
            //callSendDetailAPI()
            paymentsuccessAPI(razorpayPaymentID)

        } catch (e: Exception) {
        }
    }

    override fun onPaymentError(p0: Int, p1: String?) {
        try {
            Toast.makeText(this, "Payment failed", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {

        }
    }
    fun paymentsuccessAPI(transactionid:String){
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.add_money(
                "Bearer "+userPref.getToken().toString(),
                amt,
                "1",
                transactionid
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }



    }

    fun paymentDialog(context: Context)
    {
        val dialog = Dialog(context)
        dialog.setContentView(R.layout.success_layout)
        val lottie =dialog.findViewById<LottieAnimationView>(R.id.personal_edit_info_loader)
        lottie.initLoader(true)
        val yesBtn = dialog.findViewById<Button>(R.id.btnSave)
        yesBtn.setOnClickListener {
//            var intent = Intent(context, MainDashboard::class.java)
//            TOKENAMT()
//            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            context.startActivity(intent)
            finish()
//            viewModel.wallet(
//                "Bearer "+userPref.getToken().toString()
//            )
            dialog.dismiss()

        }
//            val noBtn = dialog.findViewById<Button>(com.moteemaids.R.id.btnCancel)
//            noBtn.setOnClickListener {
//                dialog.dismiss()
//            }
        dialog.setCancelable(false)
        dialog.show()
        val window = dialog.window
        window?.setLayout(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayoutCompat.LayoutParams.WRAP_CONTENT
        )
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }
    fun LottieAnimationView.initLoader(isLoading: Boolean) {
        if (isLoading) {
            playAnimation()

            visibility = View.VISIBLE
        } else {
            pauseAnimation()
            animation?.reset()

            visibility = View.GONE
        }
    }

}