package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.CallStartResponse
import com.callastrouser.model.CityList
import com.callastrouser.model.CityListData
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.GetAstroSlotsResponse
import com.callastrouser.model.GetAstroSlotsResponseData
import com.callastrouser.model.GetIntakeResponse
import com.callastrouser.model.IntakeResponse
import com.callastrouser.model.LanguageResponse
import com.callastrouser.model.LanguageResponseData
import com.callastrouser.model.MaritalStatusList
import com.callastrouser.model.MaritalStatusListData
import com.callastrouser.model.MatchMakingResponse
import com.callastrouser.model.ReportIntakeDetail
import com.callastrouser.model.StateList
import com.callastrouser.model.StateListData
import com.callastrouser.util.NoInternetException
import com.google.android.gms.common.api.ApiException
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import java.net.SocketTimeoutException
import javax.inject.Inject

@HiltViewModel
class IntakeViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {

    val progressBarStatus = MutableLiveData<Boolean>()
    var languageResponse = MutableLiveData<LanguageResponse>()
    var timesloteResponse = MutableLiveData<GetAstroSlotsResponse>()
    var timesloteResponseData = MutableLiveData<ArrayList<GetAstroSlotsResponseData>>()
    var intakeResponse = MutableLiveData<IntakeResponse>()
    var getIntakeResponse = MutableLiveData<GetIntakeResponse>()
    var commonResponse = MutableLiveData<CommonResponse>()
    var reportIntakeDetail = MutableLiveData<ReportIntakeDetail>()
    var matchmakingResponse = MutableLiveData<MatchMakingResponse>()
    var languageResponseData = MutableLiveData<ArrayList<LanguageResponseData>>()
    val _progressBarVisibility = MutableLiveData<Int>()
    var maritalResponse = MutableLiveData<MaritalStatusList>()
    var maritalResponseData = MutableLiveData<ArrayList<MaritalStatusListData>>()
    var callStartResponse = MutableLiveData<CallStartResponse>()
    val errorString = MutableLiveData<String>()
    var stateListData = MutableLiveData<ArrayList<StateListData>>()
    var statlistResponse = MutableLiveData<StateList>()
    var citylistResponse = MutableLiveData<CityList>()
    var citylistData = MutableLiveData<ArrayList<CityListData>>()

    fun Language(
        token: String,
    ): MutableLiveData<LanguageResponse> {
        if (languageResponse == null) {
            languageResponse = MutableLiveData()
        }
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response = mainRepository.Language(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    languageResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return languageResponse
    }

    fun get_astro_slot(
        token: String,
        date: String,
        astro_id:String
    ): MutableLiveData<GetAstroSlotsResponse> {
        if (languageResponse == null) {
            languageResponse = MutableLiveData()
        }
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response = mainRepository.get_astro_slot(token,date,astro_id)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    timesloteResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return timesloteResponse
    }



    fun add_user_details_first(
        token: String,
        name: String,
        dob: String,
        birth_time: String,
        place_birth: String,
        occupation: String,
        maritial_status: String,
        topic_consultation: String,
        language_id: String,
        astro_id: String,
        request_type: String,
//        state: String,
//        city: String,
        gender: String,
        fixed_session :String,
        fixed_session_type :String,
        slot_date :String,
        slot_time :String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.add_user_details_first(
                        token,
                        name,
                        dob,
                        birth_time,
                        place_birth,
                        occupation,
                        maritial_status,
                        topic_consultation,
                        language_id,
                        astro_id,
                        request_type/*,state,city*/,gender,fixed_session,fixed_session_type,slot_date, slot_time)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    intakeResponse.postValue(response.body())
                } else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
    }

    fun get_intake_report(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.get_intake_report(
                    token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                getIntakeResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

//    fun StateListAPI(): MutableLiveData<StateList> {
//        if (statlistResponse == null) {
//            statlistResponse = MutableLiveData()
//        }
//        progressBarStatus.value = true
//        viewModelScope.launch {
//            try {
//                val response = mainRepository.StateList()
//
//                if (response.isSuccessful) {
//                    progressBarStatus.value = false
//                    statlistResponse.postValue(response.body())
//                }
//            }catch (e:Exception) {
//                _progressBarVisibility.postValue(0)
//                e.printStackTrace()
//            }
//        }
//        return statlistResponse
//    }


//    fun CityListAPI(
//        id:Int
//    ): MutableLiveData<CityList> {
//        if (citylistResponse == null) {
//            citylistResponse = MutableLiveData()
//        }
//        progressBarStatus.value = true
//        viewModelScope.launch {
//            try {
//                val response = mainRepository.CityList(id)
//
//                if (response.isSuccessful) {
//                    progressBarStatus.value = false
//                    citylistResponse.postValue(response.body())
//                }
//            }catch (e:Exception) {
//                _progressBarVisibility.postValue(0)
//                e.printStackTrace()
//            }
//        }
//        return citylistResponse
//    }


    fun when_call_start(
        token: String,
        astro_id: String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.when_call_start(token,astro_id)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    callStartResponse.postValue(response.body())
                }
                progressBarStatus.value = false
            } catch (e: ApiException) {
                progressBarStatus.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                progressBarStatus.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                progressBarStatus.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                progressBarStatus.value = false
                e.printStackTrace()
            }
        }
    }

    fun request_for_report(
        token: String,
        dob: String,
        birth_time: String,
        place_birth: String,
        occupation: String,
        maritial_status: String,
        topic_consultation: String,
        astro_id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.request_for_report(
                    token,
                    dob,
                    birth_time,
                    place_birth,
                    occupation,
                    maritial_status,
                    topic_consultation,
                    astro_id,)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun MatchMaking(
        token: String,
        boy_name: String,
        dob_boy: String,
        birth_time_boy: String,
        place_birth_boy: String,
        occupation_boy: String,
//        maritial_status_boy: String,
//        topic_consultation_boy: String,
        girl_name: String,
        dob_girl: String,
        birth_time_girl: String,
        place_birth_girl: String,
        occupation_girl: String,
//        maritial_status_girl: String,
//        topic_consultation_girl: String,
        request_type: String,
        astro_id: String,
        language_id: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.MatchMaking(
                    token,
                    boy_name,
                    dob_boy,
                    birth_time_boy,
                    place_birth_boy,
                    occupation_boy,
//                    maritial_status_boy,
//                    topic_consultation_boy,
                    girl_name,
                    dob_girl,
                    birth_time_girl,
                    place_birth_girl,
                    occupation_girl,
//                    maritial_status_girl,
//                    topic_consultation_girl,
                    request_type,
                    astro_id,
                    language_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                matchmakingResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun add_report_intake(
        token: String,
        astro_id: String,
        report_id: String,
        full_name: String,
        gender: String,
        dob: String,
        birth_time: String,
        place_birth: String,
        occupation: String,
        maritial_status: String,
        topic_consultation: String,
        language_id:String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.add_report_intake(token,astro_id,report_id,full_name,gender,dob,birth_time,place_birth, occupation, maritial_status, topic_consultation,language_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun report_intake_detail(
        token: String,
        id: String,

    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.report_intake_detail(token,id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                reportIntakeDetail.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun maritials_list(
        token:String
    ): MutableLiveData<MaritalStatusList> {
        if (maritalResponse == null) {
            maritalResponse = MutableLiveData()
        }
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response = mainRepository.maritials_list(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    maritalResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return maritalResponse
    }


}