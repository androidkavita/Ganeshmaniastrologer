package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ChatFragmentResponse(

    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<ChatFragmentResponseData> = arrayListOf()
)
data class ChatFragmentResponseData(
    @SerializedName("id"               ) var id              : Int?              = null,
    @SerializedName("name"             ) var name            : String?           = null,
    @SerializedName("experience"       ) var experience      : Int?           = 0,
    @SerializedName("profile_image"    ) var profileImage    : String?           = null,
    @SerializedName("astro_experience" ) var astroExperience : String?           = null,
    @SerializedName("astro_rating"     ) var astro_rating    : String?           = null,
    @SerializedName("request"          ) var request         : Int?              = null,
    @SerializedName("calling_charg"    ) var calling_charge  : String?           = null,
    @SerializedName("expertise"        ) var expertise       : String?           = null,
    @SerializedName("language"         ) var language        : String?           = null
)