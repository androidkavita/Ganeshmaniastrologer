package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.adapter.UserReviewsAdapter
import com.callastrouser.databinding.ActivityAstrologerProfileBinding
import com.callastrouser.model.AstroRatingReview
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.AstrologerViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AstrologerProfileActivity : BaseActivity() {
    lateinit var binding: ActivityAstrologerProfileBinding
    val viewModel : AstrologerViewModel by viewModels()
    lateinit var astrologerid:String
    lateinit var adapter : UserReviewsAdapter
    var List:ArrayList<AstroRatingReview> = arrayListOf()
    lateinit var minimumbalence30:String
    lateinit var minimumbalence60:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_astrologer_profile)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_astrologer_profile)

        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Profile"

        if (intent!=null){
            astrologerid = intent.getStringExtra("id").toString()
        }

        binding.availability.setOnClickListener {
            startActivity(Intent(this,AvailabilityActivity::class.java).putExtra("astrologerid",astrologerid))
        }
        binding.callimage.setOnClickListener{
            startActivity(Intent(this,IntakeMatchMakingFormActivity::class.java).putExtra("id",astrologerid).putExtra("request_type","2"))
        }
        binding.chatimage.setOnClickListener{
            startActivity(Intent(this,IntakeMatchMakingFormActivity::class.java).putExtra("id",astrologerid).putExtra("request_type","1"))
        }
        binding.callimagevideo.setOnClickListener{
            startActivity(Intent(this,IntakeMatchMakingFormActivity::class.java).putExtra("id",astrologerid).putExtra("request_type","3"))
        }


        binding.fixedsession.setOnClickListener{
            startActivity(Intent(this,FixSession::class.java).putExtra("id",astrologerid).putExtra("sessiontype","1").putExtra("minimumbalence",minimumbalence30))
        }
        binding.fixedsession2.setOnClickListener {
            startActivity(Intent(this,FixSession::class.java).putExtra("id",astrologerid).putExtra("sessiontype","2").putExtra("minimumbalence",minimumbalence60))
        }
//        AvailabilityActivity

        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.strologer_details(
                "Bearer " + userPref.getToken().toString(),
                astrologerid
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }


        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.astrorahiResponse.observe(this) {
            if (it.status == 1) {
                binding.name.text = it.data?.name.toString()
                binding.designation.text = it.data?.expertise.toString()
                binding.language.text = it.data?.language.toString()
                binding.experience.text = "Exp: "+it.data?.experence.toString()
                Glide.with(this).load(it.data?.profile).into(binding.image)
                binding.ratings.rating = it.data?.astroRating!!.avgRating!!.toFloat()
                binding.ratings2.rating = it.data?.astroRating!!.avgRating!!.toFloat()
                binding.about.text = it.data?.aboutUs.toString()
                binding.order.text = it.data?.order.toString()+ " Orders"
                binding.ratingtext.text = it.data?.astroRating!!.avgRating!!.toString()
                binding.money.text = "₹"+it.data?.calling_charg+"/min"
                binding.reviews.text = it.data?.astroRating!!.total!!.toString()+" Reviews"
//                if (it.data?.sessionDetail?.size != 0){
                    binding.fixedfor30.text = "₹"+it.data?.fixed_session_30min_charge.toString()+"/-"
                    minimumbalence30 = it.data?.fixed_session_30min_charge.toString()
                    binding.fixedfor60.text = "₹"+it.data?.fixed_session_60min_charge.toString()+"/-"
                    minimumbalence60 = it.data?.fixed_session_60min_charge.toString()
//                }
                List.clear()
                List.addAll(it.data!!.astroRatingReview)
                adapter = UserReviewsAdapter(this,List)
                binding.rvTestimonials.adapter = adapter
                binding.pBar1.progress = it.data?.astroRating!!.one!!.toInt()
                binding.pBar2.progress = it.data?.astroRating!!.two!!.toInt()
                binding.pBar3.progress = it.data?.astroRating!!.three!!.toInt()
                binding.pBar4.progress = it.data?.astroRating!!.four!!.toInt()
                binding.pBar5.progress = it.data?.astroRating!!.five!!.toInt()

                if (it.data!!.request!!.equals(2)){
                    binding.callimage.visibility = View.GONE
                    binding.chatimage.visibility = View.GONE
                    binding.callimagevideo.visibility = View.GONE
                }else{
                    binding.callimage.visibility = View.VISIBLE
                    binding.chatimage.visibility = View.VISIBLE
                    binding.callimagevideo.visibility = View.VISIBLE
                }

//                binding.tv5.text = it.data?.astroRating!!.one!!.toString()
//                binding.tv4.text = it.data?.astroRating!!.two!!.toString()
//                binding.tv3.text = it.data?.astroRating!!.three!!.toString()
//                binding.tv2.text = it.data?.astroRating!!.four!!.toString()
//                binding.tv1.text = it.data?.astroRating!!.five!!.toString()

            } else {

            }
        }
    }
}