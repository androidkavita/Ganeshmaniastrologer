package com.callastrouser.ui.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.adapter.BookingDetailsAdapter
import com.callastrouser.adapter.ClickBokingDetails
import com.callastrouser.databinding.ActivityBookingDetailsBinding
import com.callastrouser.model.BookingDetailsResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.OrderDetailsViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BookingDetailsActivity : BaseActivity(), ClickBokingDetails {
    lateinit var binding: ActivityBookingDetailsBinding
    private val viewModel: OrderDetailsViewModel by viewModels()
    lateinit var product_id:String
    lateinit var order_id:String
    lateinit var flag:String
    lateinit var image:String
    lateinit var adapter : BookingDetailsAdapter
    var data : ArrayList<BookingDetailsResponseData> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking_details)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_booking_details)

        binding.header.backArrow.setOnClickListener {
            finish()
        }

        binding.header.tvHeadName.text = "Booking Details"

        if (intent!=null){
            product_id = intent.getStringExtra("id").toString()
            order_id = intent.getStringExtra("order_id").toString()
            flag = intent.getStringExtra("flag").toString()
        }
        binding.btnGiveReview.visibility = View.GONE
        binding.btnCancelOrder.visibility = View.GONE
//        if (flag == "1"){
//            binding.btnCancelOrder.visibility = View.VISIBLE
//            binding.btnGiveReview.visibility = View.GONE
//        }else{
//            binding.btnGiveReview.visibility = View.VISIBLE
//            binding.btnCancelOrder.visibility = View.GONE
//        }
        binding.btnCancelOrder.setOnClickListener{

        }

        binding.btnGiveReview.setOnClickListener{

        }

        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.BookingDetail(
                "Bearer "+userPref.getToken().toString(),
                order_id,
                product_id
            )
        } else {
            toast(this,"Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.bookingResponse.observe(this){
            if (it.status == 1){
//                image = it.data?.mainImage.toString()
                binding.date.text = it.details?.orderDate.toString()
                data.clear()
                data.addAll(it.data)
                adapter = BookingDetailsAdapter(this@BookingDetailsActivity,data,this,flag)
                binding.rvAddress.adapter = adapter
                binding.bookingid.text = it.details?.bookingId.toString()
                if (it.details?.status == 1){
                    binding.bookingStatus.text = "Order Placed"
                }else if (it.details?.status == 2){
                    binding.bookingStatus.text = "Accepted"
                }else if (it.details?.status == 3){
                    binding.bookingStatus.text = "Cancel"
                    binding.deliverydatell.visibility = View.GONE
                }else if (it.details?.status == 4){
                    binding.bookingStatus.text = "Out for delivery"
                }else if (it.details?.status == 5){
                    binding.bookingStatus.text = "Pending"
                }else if (it.details?.status == 6){
                    binding.bookingStatus.text = "Delivered"
                }else if (it.details?.status == 7){
                    binding.bookingStatus.text = "Rejected"
                    binding.deliverydatell.visibility = View.GONE
                }
                binding.deliveryaddress.text = it.details?.deliveryAddress.toString()
                binding.productPrice.text = "₹"+it.details?.productPrice.toString()
                binding.shippingCharges.text = "₹"+it.details?.shippingCharg.toString()
                binding.couponDiscount.text = it.details?.couponDiscount.toString()
                binding.totalAmount.text = "₹"+it.details?.grandTotal.toString()
                binding.gst.text = it.details?.tax.toString()
                binding.deliveryDate.text = it.details?.expactDelivery.toString()

//                if (it.data?.status!!.equals(3)){
//                    toast(this@BookingDetailsActivity,"This Order has been cancelled.")
//                    binding.visibledata.visibility = View.GONE
//                    binding.rawtext.visibility = View.VISIBLE
//                }else{
//                    binding.visibledata.visibility = View.VISIBLE
//                    binding.rawtext.visibility = View.GONE
//                    binding.name.text = it.data?.name.toString()
//                    Glide.with(this@BookingDetailsActivity).load(it.data?.mainImage).into(binding.ivImage)
//                    binding.date.text = it.data?.orderDate.toString()
//                    binding.qty.text = it.data?.qty.toString()
//                    binding.amount.text = "₹"+it.data?.grandTotal.toString()
//                    binding.bookingid.text = it.data?.orderId.toString()
//                    binding.bookingStatus.text = it.data?.status.toString()
//
//                    binding.deliveryaddress.text = it.data?.deliveryAddress.toString()
//                    binding.productPrice.text = "₹"+it.data?.product_price.toString()
//                    binding.couponDiscount.text = it.data?.couponDiscount.toString()
//                    binding.totalAmount.text = it.data?.grandTotal.toString()
//                    binding.gst.text = it.data?.gst.toString()
//                    binding.deliveryDate.text = it.data?.expact_delivery.toString()
//                }
            }else{
                snackbar(it.message.toString())
            }
        }

    }

    override fun CancelAndrating(id: Int, type: String,name :String,qty :String,image:String,statustype:String) {

        if (type == "1"){
            startActivity(Intent(this,CancelOrderActivity::class.java).putExtra("id",product_id).putExtra("order_id",order_id))
        }else{
            startActivity(Intent(this,GiveReviewActivity::class.java)
                .putExtra("name",name)
                .putExtra("quantity",qty)
                .putExtra("price",binding.productPrice.text.toString())
                .putExtra("bookingId",binding.bookingid.text.toString())
                .putExtra("date",binding.date.text.toString())
                .putExtra("product_id",id)
                .putExtra("image",image)
            )
        }

        if (statustype == "1"){
            binding.bookingStatus.text = "Order Placed"
        }else if (statustype == "2"){
            binding.bookingStatus.text = "Accepted"
        }else if (statustype == "3"){
            binding.bookingStatus.text = "Cancel"
        }else if (statustype == "4"){
            binding.bookingStatus.text = "Out for delivery"
        }else if (statustype == "5"){
            binding.bookingStatus.text = "Pending"
        }else if (statustype== "6"){
            binding.bookingStatus.text = "Delivered"
        }else if (statustype == "7"){
            binding.bookingStatus.text = "Rejected"
        }


    }
}