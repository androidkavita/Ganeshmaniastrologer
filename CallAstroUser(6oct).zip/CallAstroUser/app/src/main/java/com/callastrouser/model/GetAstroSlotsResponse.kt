package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class GetAstroSlotsResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<GetAstroSlotsResponseData> = arrayListOf()
)

data class GetAstroSlotsResponseData(
    @SerializedName("id"         ) var id        : Int?    = null,
    @SerializedName("from_time"  ) var fromTime  : String? = null,
    @SerializedName("to_time"    ) var toTime    : String? = null,
    @SerializedName("time_avail" ) var timeAvail : String? = null
)
