package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.CallHistoryLayoutBinding
import com.callastrouser.model.CallHistoryResponseData
import com.maxtra.astrorahi.interfaces.CallVideo

class CallHistoryAdapter (val context : Context
                          , var data: ArrayList<CallHistoryResponseData>, var callchat: CallVideo
) :
    RecyclerView.Adapter<CallHistoryAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: CallHistoryLayoutBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CallHistoryAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.call_history_layout, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: CallHistoryAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.orderid.text = "Order id: ${List.bookingId}"
        holder.binding.astrologername.text = "Astrologer Name: ${List.astroName}"
        holder.binding.chatrate.text = "Rate per min: ₹ ${List.callingCharg.toString()} /Min"
        holder.binding.date.text = List.bookingDate.toString()
        holder.binding.duration.text = "Duration: ${List.duration.toString()} Min"
        holder.binding.ratingUser.rating = List.rating!!.toFloat()
        holder.binding.review.text = "Feedback: ${List.feedback.toString()}"
        holder.binding.date.text = "Date: ${List.bookingDate.toString()}"
        holder.binding.status.text = List.status.toString()
//        holder.binding.remarks.text = List.remark.toString()
//        holder.binding.findness.text = List.findiness.toString()
//        holder.binding.conclusion.text = List.conclusion.toString()

    }

    override fun getItemCount(): Int {
        return data.size
    }

}