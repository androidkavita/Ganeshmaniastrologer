package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class GetAstroDetailsResponse(

    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<GetAstroDetailsResponseData> = arrayListOf()
)
data class GetAstroDetailsResponseData(

    @SerializedName("id"          ) var id          : Int?    = null,
    @SerializedName("title"       ) var title       : String? = null,
    @SerializedName("description" ) var description : String? = null,
    @SerializedName("image"       ) var image       : String? = null
)