package com.callastrouser.model.requesBody

import com.google.gson.annotations.SerializedName

class MatchHoroscopeRequest {

    @SerializedName("boy_dob")
    var boy_dob: String? = null

    @SerializedName("boy_tob")
    var boy_tob: String? = null

    @SerializedName("boy_tz")
    var boy_tz: String? = null

    @SerializedName("boy_lat")
    var boy_lat: String? = null

    @SerializedName("boy_lon")
    var boy_lon: String? = null

    @SerializedName("girl_dob")
    var girl_dob: String? = null

    @SerializedName("girl_tob")
    var girl_tob: String? = null

    @SerializedName("girl_tz")
    var girl_tz: String? = null

    @SerializedName("girl_lat")
    var girl_lat: String? = null

    @SerializedName("girl_lon")
    var girl_lon: String? = null

    @SerializedName("api_key")
    var api_key: String? = null

    @SerializedName("lang")
    var lang: String? = null


}