package com.callastrouser.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.ViewPagerHistoryProductsAdapter
import com.callastrouser.databinding.FragmentProductsHistoryBinding

class ProductsHistoryFragment : BaseFragment() {
    lateinit var binding: FragmentProductsHistoryBinding
    private var historyProductsPagerAdapter: ViewPagerHistoryProductsAdapter?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding   = FragmentProductsHistoryBinding.inflate(inflater,container,false)
        setTab()


        return binding.root
    }
    private fun setTab() {
        historyProductsPagerAdapter = ViewPagerHistoryProductsAdapter(getParentFragmentManager())
        binding.viewPager.adapter = historyProductsPagerAdapter
        binding.tabLayout.setupWithViewPager(binding.viewPager)
        binding.tabLayout.getChildAt(0)

    }
}