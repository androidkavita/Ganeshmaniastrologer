package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.DThreeChartResponse
import com.callastrouser.model.GetIntakeResponse
import com.callastrouser.model.KundliMatchMakingResponse
import com.callastrouser.model.MakeKundaliResponse
import com.callastrouser.model.NavmsaResponse
import com.callastrouser.model.PlanetsResponse
import com.callastrouser.model.RecentSeeKundliResponse
import com.callastrouser.model.SendKundliResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class KundaliViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {

    val progressBarStatus = MutableLiveData<Boolean>()
    val _progressBarVisibility = MutableLiveData<Int>()
    val errorString = MutableLiveData<String>()
    var makeKundaliResponse = MutableLiveData<MakeKundaliResponse>()
    var planetsResponse = MutableLiveData<PlanetsResponse>()
    var navmsaResponse = MutableLiveData<NavmsaResponse>()
    var dThreeChartResponse = MutableLiveData<DThreeChartResponse>()
    var kundliMatchMakingResponse = MutableLiveData<KundliMatchMakingResponse>()
    var sendKundliResponse = MutableLiveData<SendKundliResponse>()
    var recentSeeKundliResponse = MutableLiveData<RecentSeeKundliResponse>()

    fun MakeKundali(
        token: String,
        boy_name: String,
        boy_birth_date: String,
        boy_birth_time: String,
        boy_birth_place: String,
        girl_name: String,
        girl_birth_date: String,
        girl_birth_time: String,
        girl_birth_place: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.kundli_match(
                    token,
                    boy_name,
                    boy_birth_date,
                    boy_birth_time,
                    boy_birth_place,
                    girl_name,
                    girl_birth_date,
                    girl_birth_time,
                    girl_birth_place,)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                makeKundaliResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun Planets(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.planets(
                    year,
                    month,
                    date,
                    hours,
                    minutes,
                    seconds,
                    latitude,
                    longitude,
                    timezone)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                planetsResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }



    fun Navamsa_chart(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.navamsa_chart(
                    year,
                    month,
                    date,
                    hours,
                    minutes,
                    seconds,
                    latitude,
                    longitude,
                    timezone)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                navmsaResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun dThreechart(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.dThreechart(
                    year,
                    month,
                    date,
                    hours,
                    minutes,
                    seconds,
                    latitude,
                    longitude,
                    timezone)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                dThreeChartResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }




    fun match_making(
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String,
        fyear: String,
        fmonth: String,
        fdate: String,
        fhours: String,
        fminutes: String,
        fseconds: String,
        flatitude: String,
        flongitude: String,
        ftimezone: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.match_making(
                    year,
                    month,
                    date,
                    hours,
                    minutes,
                    seconds,
                    latitude,
                    longitude,
                    timezone,
                    fyear,
                    fmonth,
                    fdate,
                    fhours,
                    fminutes,
                    fseconds,
                    flatitude,
                    flongitude,
                    ftimezone,)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                kundliMatchMakingResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun insert_recently_see_kundali(
        token:String,
        name : String,
        year : String,
        month: String,
        date: String,
        hours: String,
        minutes: String,
        seconds: String,
        latitude: String,
        longitude: String,
        timezone: String,
        Placeofbirth: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.insert_recently_see_kundali(
                    token,
                    name,
                    year,
                    month,
                    date,
                    hours,
                    minutes,
                    seconds,
                    latitude,
                    longitude,
                    timezone,Placeofbirth)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                sendKundliResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun recently_see_kundali(
        token:String,
        type : String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.recently_see_kundali(
                    token,
                    type,
                  )
            if (response.isSuccessful) {
                progressBarStatus.value = false
                recentSeeKundliResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun insert_recently_see_match_making_kundali(
        token:String,
        fname : String,
        fdate : String,
        fmonth: String,
        fyear: String,
        fhours: String,
        fminutes: String,
        fseconds: String,
        flatitude: String,
        flongitude: String,
        ftimezone: String,
        fbirthplace: String,
        mname : String,
        mdate : String,
        mmonth: String,
        myear: String,
        mhours: String,
        mminutes: String,
        mseconds: String,
        mlatitude: String,
        mlongitude: String,
        mtimezone: String,
        mbirthplace: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.insert_recently_see_match_making_kundali(
                    token,fname, fdate, fmonth, fyear, fhours, fminutes, fseconds, flatitude, flongitude, ftimezone, fbirthplace, mname, mdate, mmonth, myear, mhours, mminutes, mseconds, mlatitude, mlongitude, mtimezone, mbirthplace
                )
            if (response.isSuccessful) {
                progressBarStatus.value = false
                sendKundliResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }






}