package com.callastrouser.ui.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.WalletHistoryAdapter
import com.callastrouser.databinding.FragmentWalletHistoryBinding
import com.callastrouser.model.TransactionHistory
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.DashboardHistoryWalletViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class WalletHistoryFragment : BaseFragment() {
    private val viewModel: DashboardHistoryWalletViewModel by viewModels()
    lateinit var binding: FragmentWalletHistoryBinding
    lateinit var adapter: WalletHistoryAdapter
    var List:ArrayList<TransactionHistory> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentWalletHistoryBinding.inflate(inflater,container,false)


        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.HistoryWallet(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.historyWalletResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                binding.totalbalance.text = "₹"+it.data?.wallet
                List.clear()
                List.addAll(it.data!!.transactionHistory)
//                adapter = WalletHistoryAdapter(requireContext(),List)
//                binding.rvwallethistory.adapter = adapter
            } else {
                toast(it.message.toString())
//                snackbar(it?.message!!)
            }
        }

        return binding.root
    }
}