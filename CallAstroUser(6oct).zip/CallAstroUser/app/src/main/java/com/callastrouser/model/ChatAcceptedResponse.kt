package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ChatAcceptedResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : ChatAcceptedResponseData?   = ChatAcceptedResponseData()
)
data class ChatAcceptedResponseData(
    @SerializedName("astro_id"     ) var astro_id     : String? = null,
    @SerializedName("user_name"     ) var userName     : String? = null,
    @SerializedName("user_profile"  ) var userProfile  : String? = null,
    @SerializedName("astro_name"    ) var astroName    : String? = null,
    @SerializedName("astro_profile" ) var astroProfile : String? = null,
    @SerializedName("request_status" ) var request_status : Int? = null,
)
