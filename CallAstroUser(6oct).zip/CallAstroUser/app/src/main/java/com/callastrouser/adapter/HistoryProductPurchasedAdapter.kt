package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowHistoryProductsPurchasedBinding
import com.callastrouser.model.HistoryProductSuggestedData

class HistoryProductPurchasedAdapter (val context : Context, var data: ArrayList<HistoryProductSuggestedData>, var transfer: ShopsHistoryPurchased) :
    RecyclerView.Adapter<HistoryProductPurchasedAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowHistoryProductsPurchasedBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryProductPurchasedAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_history_products_purchased, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: HistoryProductPurchasedAdapter.ViewHolder, position: Int) {
        val List = data[position]
        Glide.with(context).load(List.mainImage).into(holder.binding.ivImage)
        holder.binding.productname.text = List.name.toString()
        holder.binding.productprise.text = "₹"+List.price.toString()
        holder.binding.date.text = List.order_date.toString()
        transfer.layoutid(holder.binding.llGroceryItem,List.id.toString(),List.name.toString())
    }

    override fun getItemCount(): Int {
        return data.size
    }
}

interface ShopsHistoryPurchased{
    fun layoutid(layout: LinearLayout, id:String, name:String)
}