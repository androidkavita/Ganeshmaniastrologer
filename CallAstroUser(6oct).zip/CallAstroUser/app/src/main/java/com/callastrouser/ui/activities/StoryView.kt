package com.callastrouser.ui.activities

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.util.Log
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.ActivityStoryViewBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.StoryViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.WithFragmentBindings

@AndroidEntryPoint
class StoryView : BaseActivity() {
    lateinit var bindings: ActivityStoryViewBinding
    lateinit var id:String
    private val viewModel: StoryViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_story_view)
        bindings = DataBindingUtil.setContentView(this,R.layout.activity_story_view)

        bindings.header.backArrow.setOnClickListener { finish() }
        bindings.header.tvHeadName.text = "Blogs"

        if (intent != null){
            id = intent.getStringExtra("id").toString()
        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.get_blog_detail(
                "Bearer "+userPref.getToken().toString(),id
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.blogDetailResponse.observe(this){
            if (it.status == 1){
                bindings.name.text = it.data?.title
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    bindings.name1.setText(Html.fromHtml(it.data?.description, Html.FROM_HTML_MODE_COMPACT));
                } else {
                    bindings.name1.setText(Html.fromHtml(it.data?.description));
                }
                Glide.with(this@StoryView).load(it.data?.image).into(bindings.rvImgs)
            }
        }

    }
}