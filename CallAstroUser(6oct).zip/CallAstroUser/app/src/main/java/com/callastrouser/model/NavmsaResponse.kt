package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class NavmsaResponse(
    val output: NavmsaOutput,
    val statusCode: Int
)

data class NavmsaOutput(
    @SerializedName("0"  ) var zero  : NavmsaOutputData?,
    @SerializedName("1"  ) var one  : NavmsaOutputData,
    @SerializedName("2"  ) var two  : NavmsaOutputData,
    @SerializedName("3"  ) var three  : NavmsaOutputData,
    @SerializedName("4"  ) var four  : NavmsaOutputData,
    @SerializedName("5"  ) var five  : NavmsaOutputData,
    @SerializedName("6"  ) var six  : NavmsaOutputData,
    @SerializedName("7"  ) var seven  : NavmsaOutputData,
    @SerializedName("8"  ) var eight  : NavmsaOutputData,
    @SerializedName("9"  ) var nine  : NavmsaOutputData,
    @SerializedName("10" ) var ten : NavmsaOutputData,
    @SerializedName("11" ) var eleven : NavmsaOutputData,
    @SerializedName("12" ) var twelve : NavmsaOutputData
//    val `0`: NavmsaOutputData,
//    val `1`: NavmsaOutputData,
//    val `10`: NavmsaOutputData,
//    val `11`: NavmsaOutputData,
//    val `12`: NavmsaOutputData,
//    val `2`: NavmsaOutputData,
//    val `3`: NavmsaOutputData,
//    val `4`: NavmsaOutputData,
//    val `5`: NavmsaOutputData,
//    val `6`: NavmsaOutputData,
//    val `7`: NavmsaOutputData,
//    val `8`: NavmsaOutputData,
//    val `9`: NavmsaOutputData
)

data class NavmsaOutputData(
    val current_sign: Int,
    val isRetro: String,
    val name: String
)