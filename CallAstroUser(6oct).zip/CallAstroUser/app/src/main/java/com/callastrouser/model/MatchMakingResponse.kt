package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class MatchMakingResponse(

    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : MatchMakingResponseData?   = MatchMakingResponseData()
)
data class MatchMakingResponseData(
    @SerializedName("type"                    ) var type                  : Int?    = null,
    @SerializedName("user_id"                 ) var userId                : Int?    = null,
    @SerializedName("dob_boy"                 ) var dobBoy                : String? = null,
    @SerializedName("birth_time_boy"          ) var birthTimeBoy          : String? = null,
    @SerializedName("place_birth_boy"         ) var placeBirthBoy         : String? = null,
    @SerializedName("occupation_boy"          ) var occupationBoy         : String? = null,
    @SerializedName("maritial_status_boy"     ) var maritialStatusBoy     : String? = null,
    @SerializedName("topic_consultation_boy"  ) var topicConsultationBoy  : String? = null,
    @SerializedName("dob_girl"                ) var dobGirl               : String? = null,
    @SerializedName("birth_time_girl"         ) var birthTimeGirl         : String? = null,
    @SerializedName("place_birth_girl"        ) var placeBirthGirl        : String? = null,
    @SerializedName("occupation_girl"         ) var occupationGirl        : String? = null,
    @SerializedName("maritial_status_girl"    ) var maritialStatusGirl    : String? = null,
    @SerializedName("topic_consultation_girl" ) var topicConsultationGirl : String? = null
)
