package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class TransactionHistoryResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<TransactionHistoryData> = arrayListOf()
)
data class TransactionHistoryData(
    @SerializedName("id"           ) var id          : Int?    = null,
    @SerializedName("type"         ) var type        : Int?    = null,
    @SerializedName("content"      ) var content     : String? = null,
    @SerializedName("amount"       ) var amount      : Int?    = null,
    @SerializedName("created_at"   ) var createdAt   : String? = null,
    @SerializedName("created_time" ) var createdTime : String? = null
)