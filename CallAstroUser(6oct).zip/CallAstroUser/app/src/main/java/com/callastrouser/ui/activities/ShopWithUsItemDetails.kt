package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.ProductQAAdapter
import com.callastrouser.adapter.SliderAdapter
import com.callastrouser.adapter.TestimonialAdapter
import com.callastrouser.databinding.ActivityShopWithUsItemDetailsBinding
import com.callastrouser.model.ProductDetails
import com.callastrouser.model.ProductImages
import com.callastrouser.model.Testimonials
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.ProductDetailsViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import java.util.ArrayList

@AndroidEntryPoint
class ShopWithUsItemDetails : BaseActivity() {
    lateinit var binding : ActivityShopWithUsItemDetailsBinding
    private val viewModel : ProductDetailsViewModel by viewModels()
    var Listdata: ArrayList<ProductDetails> = ArrayList()
    var Listdata1: ArrayList<ProductImages> = ArrayList()
    var Listdata2: ArrayList<Testimonials> = ArrayList()
    lateinit var adapter : ProductQAAdapter
    lateinit var adapter1 : SliderAdapter
    lateinit var adapter2 : TestimonialAdapter
    lateinit var id :String
    lateinit var name :String
    var amount :String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop_with_us_item_details)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_shop_with_us_item_details)

        if (intent != null){
            id = intent.getStringExtra("id").toString()
            name = intent.getStringExtra("name").toString()
        }

        binding.backArrow.setOnClickListener {
            finish()
        }
        binding.tvHeadName.text = name

        binding.ivCart.setOnClickListener {
            startActivity(Intent(this,MyCartListCheckout::class.java))
        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.ProductDetails(
                "Bearer "+userPref.getToken().toString(),
                id
            )
            viewModel.cart_item_count(
                "Bearer "+userPref.getToken().toString(),
            )

        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.cartcountResponse.observe(this){
            if (it.status == 1){
                binding.count.text = it.data.toString()
            }
        }
        viewModel.ProductResponse.observe(this){
            if (it.status == 1){
                binding.productname.text = it.data?.product?.name.toString()
                binding.discription.text = it.data?.product?.description.toString()
                binding.price.text = "₹"+it.data?.product?.price.toString()
                amount = it.data?.product?.price.toString()
                Listdata.clear()
                Listdata1.clear()
                Listdata2.clear()
                Listdata.addAll(it.data!!.productDetails)
                for (i in 0 until it.data?.productImages!!.size){
                    Listdata1.add(it.data!!.productImages[i])
                }
                Listdata2.addAll(it.data!!.testimonials)
                adapter1 = SliderAdapter(Listdata1)
                binding.imageSlider.setSliderAdapter(adapter1)
                adapter = ProductQAAdapter(this,Listdata)
                binding.rvQuestions.adapter = adapter
                adapter2 = TestimonialAdapter(this,Listdata2)
                binding.rvTestimonials.adapter = adapter2

            }else{
                snackbar(it.message.toString())
            }
        }

        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                toast(this@ShopWithUsItemDetails,"Product added successfully.")
                viewModel.cart_item_count(
                    "Bearer "+userPref.getToken().toString(),
                )
//                var intent = Intent(this@ShopWithUsItemDetails,AddressList::class.java)
//                intent.putExtra("bookingtype","CART")
//                startActivity(intent)
            }else{
                snackbar(it.message.toString())
            }
        }

        binding.bookNow.setOnClickListener {
            var intent = Intent(this@ShopWithUsItemDetails,AddressList::class.java)
            intent.putExtra("id",id)
            intent.putExtra("bookingtype","booknow")
            intent.putExtra("amount",amount)
            startActivity(intent)
        }

        binding.addtocart.setOnClickListener {
            if (CommonUtils.isInternetAvailable(this)) {
                viewModel.add_to_cart("Bearer "+userPref.getToken().toString(),id,"1")
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast(this,"Please check internet connection.")
            }

        }
        binding.addtocarttext.setOnClickListener {
            if (CommonUtils.isInternetAvailable(this)) {
                viewModel.add_to_cart("Bearer "+userPref.getToken().toString(),id,"1")
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast(this,"Please check internet connection.")
            }
        }

    }
}