package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class RemedyPoojaResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<RemedyPoojaResponseData> = arrayListOf()
)
data class RemedyPoojaResponseData(
    @SerializedName("id"             ) var id           : Int?    = null,
    @SerializedName("title"          ) var title        : String? = null,
    @SerializedName("description"    ) var description  : String? = null,
    @SerializedName("thumb_nail"     ) var thumbNail    : String? = null,
    @SerializedName("video"          ) var video        : String? = null,
    @SerializedName("status"         ) var status       : Int?    = null,
    @SerializedName("created_at"     ) var createdAt    : String? = null,
    @SerializedName("updated_at"     ) var updatedAt    : String? = null,
    @SerializedName("thumb_nail_url" ) var thumbNailUrl : String? = null,
    @SerializedName("video_url"      ) var videoUrl     : String? = null
)