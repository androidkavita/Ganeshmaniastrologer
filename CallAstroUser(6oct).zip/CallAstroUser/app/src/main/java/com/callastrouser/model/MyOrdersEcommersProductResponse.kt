package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class MyOrdersEcommersProductResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<MyOrdersEcommersProductData> = arrayListOf()
)
//data class MyOrdersEcommersProductData(
//    @SerializedName("id"                   ) var id                 : Int?    = null,
//    @SerializedName("user_id"              ) var userId             : Int?    = null,
//    @SerializedName("order_id"             ) var orderId            : String? = null,
//    @SerializedName("product_id"           ) var productId          : Int?    = null,
//    @SerializedName("unit_price"           ) var unitPrice          : String? = null,
//    @SerializedName("product_price"        ) var productPrice       : String? = null,
//    @SerializedName("shipping_charg"       ) var shippingCharg      : String? = null,
//    @SerializedName("coupon_discount"      ) var couponDiscount     : String? = null,
//    @SerializedName("grand_total"          ) var grandTotal         : String? = null,
//    @SerializedName("qty"                  ) var qty                : String? = null,
//    @SerializedName("address_id"           ) var addressId          : Int?    = null,
//    @SerializedName("status"               ) var status             : Int?    = null,
//    @SerializedName("payment_status"       ) var paymentStatus      : Int?    = null,
//    @SerializedName("payment_type"         ) var paymentType        : Int?    = null,
//    @SerializedName("coupon_id"            ) var couponId           : Int?    = null,
//    @SerializedName("order_date"           ) var orderDate          : String? = null,
//    @SerializedName("transaction_id"       ) var transactionId      : String? = null,
//    @SerializedName("expact_delivery_date" ) var expactDeliveryDate : String? = null,
//    @SerializedName("created_at"           ) var createdAt          : String? = null,
//    @SerializedName("updated_at"           ) var updatedAt          : String? = null,
//    @SerializedName("product_name"         ) var productName        : String? = null,
//    @SerializedName("main_image"           ) var mainImage          : String? = null,
//    @SerializedName("status_name"          ) var statusName         : String? = null
//)

data class MyOrdersEcommersProductData(
@SerializedName("id"                   ) var id                 : Int?    = null,
@SerializedName("user_id"              ) var userId             : Int?    = null,
@SerializedName("order_id"             ) var orderId            : String? = null,
@SerializedName("shipping_charg"       ) var shippingCharg      : String? = null,
@SerializedName("tax"                  ) var tax                : String? = null,
@SerializedName("coupon_discount"      ) var couponDiscount     : String? = null,
@SerializedName("grand_total"          ) var grandTotal         : String? = null,
@SerializedName("address_id"           ) var addressId          : Int?    = null,
@SerializedName("status"               ) var status             : Int?    = null,
@SerializedName("payment_status"       ) var paymentStatus      : Int?    = null,
@SerializedName("payment_type"         ) var paymentType        : Int?    = null,
@SerializedName("coupon_id"            ) var couponId           : Int?    = null,
@SerializedName("transaction_id"       ) var transactionId      : String? = null,
@SerializedName("cod_payment_type"     ) var codPaymentType     : String? = null,
@SerializedName("order_image"          ) var orderImage         : String? = null,
@SerializedName("order_date"           ) var orderDate          : String? = null,
@SerializedName("expact_delivery_date" ) var expactDeliveryDate : String? = null,
@SerializedName("cancelled_date"       ) var cancelledDate      : String? = null,
@SerializedName("assign_dboy"          ) var assignDboy         : String? = null,
@SerializedName("created_at"           ) var createdAt          : String? = null,
@SerializedName("updated_at"           ) var updatedAt          : String? = null,
@SerializedName("product_id"           ) var productId          : Int?    = null,
@SerializedName("product_name"         ) var productName        : String? = null,
@SerializedName("main_image"           ) var mainImage          : String? = null,
@SerializedName("status_name"          ) var statusName         : String? = null,
@SerializedName("product_price"        ) var productPrice       : String? = null,
@SerializedName("qty"                  ) var qty                : String? = null,
@SerializedName("product_names"        ) var productNames       : String? = null,
@SerializedName("product_count"        ) var productCount       : Int?    = null,
@SerializedName("total_product_price"  ) var totalProductPrice  : Int?    = null
)