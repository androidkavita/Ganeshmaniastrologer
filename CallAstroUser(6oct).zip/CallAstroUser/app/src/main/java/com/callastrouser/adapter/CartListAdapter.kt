package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowCallAstrologersBinding
import com.callastrouser.databinding.RowCartItemBinding
import com.callastrouser.model.ProductList
import com.maxtra.astrorahi.interfaces.CallChat
import com.maxtra.astrorahi.interfaces.VideoCallChat

class CartListAdapter (val context : Context, var data: ArrayList<ProductList>, var itemplusminus: Itemplusminus) :
    RecyclerView.Adapter<CartListAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowCartItemBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartListAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_cart_item, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: CartListAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.tvProductname.text = List.productName.toString()
        holder.binding.price.text = "₹ ${List.total_price.toString()}"
        holder.binding.prductprice.text = "Product Price: ₹ ${List.price.toString()}"
        Glide.with(context).load(List.productImage).into(holder.binding.ivImage)
        holder.binding.tvCount.text = List.qty.toString()
        holder.binding.hsncode.text = "HSN CODE: "+ List.hsn_code.toString()

        holder.binding.tvPlus.setOnClickListener {
            itemplusminus.Datas(position,List.productId.toString(),holder.binding.tvMinus,holder.binding.tvPlus,List.qty.toString(),holder.binding.ivCross,List.cart_id.toString(),"1")
        }
        holder.binding.tvMinus.setOnClickListener {
            itemplusminus.Datas(position,List.productId.toString(),holder.binding.tvMinus,holder.binding.tvPlus,List.qty.toString(),holder.binding.ivCross,List.cart_id.toString(),"2")
        }
        holder.binding.ivCross.setOnClickListener {
            itemplusminus.Datas(position,List.productId.toString(),holder.binding.tvMinus,holder.binding.tvPlus,List.qty.toString(),holder.binding.ivCross,List.cart_id.toString(),"3")
        }

    }
    override fun getItemCount(): Int {
        return data.size
    }
}
interface Itemplusminus{
    fun Datas (position:Int,id:String,minus:ImageView,plus:ImageView,qty:String,ivcross:ImageView,mainid:String,type:String)
}