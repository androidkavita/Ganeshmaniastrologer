package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.AgoraGenerateTokenResponse
import com.callastrouser.model.AstrorahiResponse
import com.callastrouser.model.CallRingResponse
import com.callastrouser.model.CallStartResponse
import com.callastrouser.model.CallendbyuserResponse
import com.callastrouser.model.ChatAgoraResponse
import com.callastrouser.model.ChatListMessageResponse
import com.callastrouser.model.CheckChatEndResponse
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.GiveReviewResponse
import com.callastrouser.model.call_ring_status_save_Response
import com.callastrouser.util.ApiException
import com.callastrouser.util.NoInternetException
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import java.net.SocketTimeoutException
import javax.inject.Inject
@HiltViewModel
class VideoCallViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel(){

    val error = MutableLiveData<Int>()
    val errorString = MutableLiveData<String>()
    val _progressBarVisibility = MutableLiveData<Boolean>()
    var commonResponse = MutableLiveData<CommonResponse>()
    var callStartResponse = MutableLiveData<CallStartResponse>()
    val agoraGenerateTokenResponse= MutableLiveData<AgoraGenerateTokenResponse>()
    val callerendResponse= MutableLiveData<CallendbyuserResponse>()
    val checkChatEndResponse= MutableLiveData<CheckChatEndResponse>()
    val givereviewResponse = MutableLiveData<GiveReviewResponse>()
    val agoraChatListMessageResponse= MutableLiveData<ChatListMessageResponse>()
    val chatAgoraSendResponse= MutableLiveData<ChatAgoraResponse>()
    val callRingResponse= MutableLiveData<CallRingResponse>()
    val progressBarStatus = MutableLiveData<Boolean>()
    val astrorahiResponse = MutableLiveData<AstrorahiResponse>()
    var call_ring_status_save_Response = MutableLiveData<call_ring_status_save_Response>()

    fun agora_generate_tokenApi(
        token: String,astro_id: String, call_type: String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.agora_generate_tokenApi(token,astro_id,call_type)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    agoraGenerateTokenResponse.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }


    fun call_received(
        token: String,
        unique_id: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.call_received(token,
                    unique_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun call_ring_status_save(
        token: String,
        channel_name: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.call_ring_status_save(token,
                    channel_name)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                call_ring_status_save_Response.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun call_ring(
        token: String,
        astro_id: String,
        user_id: String,
        request_id: String
    ) {
//        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.call_ring(token, astro_id,user_id,request_id)
            if (response.isSuccessful) {
//                progressBarStatus.value = false
                callRingResponse.postValue(response.body())
            } else {
//                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun call_ring_end(
        token: String,
        channel_name: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.call_ring_end(token,
                    channel_name)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }




//    fun call_end_by_status(
//        token: String,
//        caller_id: String
//    ) {
////        progressBarStatus.value = true
//        viewModelScope.launch {
//
//            val response =
//                mainRepository.call_end_by_status(token, caller_id)
//            if (response.isSuccessful) {
////                progressBarStatus.value = false
//                callerendResponse.postValue(response.body())
//            } else {
////                progressBarStatus.value = false
//                Log.d("TAG", response.body().toString())
//            }
//        }
//
//    }
    fun check_chat_end(
        token: String,
        caller_id: String
    ) {
//        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.check_chat_end(token, caller_id)
            if (response.isSuccessful) {
//                progressBarStatus.value = false
                checkChatEndResponse.postValue(response.body())
            } else {
//                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun chat_list_MessageApi(token: String, to_id: String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.chat_list_MessageApi(token,to_id)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    agoraChatListMessageResponse.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }


    fun chatagoraApi(token: String, userId: String, message: String, type: String
    ) {
        //  _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.chatagoraApi(token, userId, message, type)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    chatAgoraSendResponse.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }


    fun call_end(token: String,timer: String,from_user: String,to_user: String,caller_id:String,type:String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.call_end(token,timer,from_user,to_user,caller_id,type)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    commonResponse.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }

    fun chat_end(token: String,timer: String,from_user: String,to_user: String,caller_id:String,type: String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.chat_end(token,timer,from_user,to_user,caller_id,type)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    commonResponse.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }



    fun when_call_start(
        token: String,
        astro_id: String
    ) {
        // _progressBarVisibility.value = true
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.when_call_start(token,astro_id)
                if (response.isSuccessful) {
                    _progressBarVisibility.value = false
                    callStartResponse.postValue(response.body())
                }
                _progressBarVisibility.value = false
            } catch (e: ApiException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: NoInternetException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: SocketTimeoutException) {
                _progressBarVisibility.value = false
                errorString.postValue(e.message!!)
            } catch (e: Exception) {
                _progressBarVisibility.value = false
                e.printStackTrace()
            }
        }
    }
    fun strologer_details(
        token:String,
        id:String,
    ) {
        viewModelScope.launch {
            try {
                val response =
                    mainRepository.strologer_details(token,id)
                if (response.isSuccessful) {
                    astrorahiResponse.postValue(response.body())
                } else {
                    Log.d("TAG", response.body().toString())
                }
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
    }

    fun user_give_review(
        token: String,
        astro_id: String,
        rating: String,
        review: String,
        caller_id: String,
        type: String
    ) {
        viewModelScope.launch {
            val response =
                mainRepository.user_give_review(token,astro_id,rating,review,caller_id,type)
            if (response.isSuccessful) {
                givereviewResponse.postValue(response.body())
            } else {
                Log.d("TAG", response.body().toString())
            }
        }
    }

}