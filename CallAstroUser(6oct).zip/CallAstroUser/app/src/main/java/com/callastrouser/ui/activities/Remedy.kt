package com.callastrouser.ui.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.ViewPagerRemedyAdapter
import com.callastrouser.databinding.ActivityRemedyBinding
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class Remedy : BaseActivity() {
    lateinit var binding: ActivityRemedyBinding
    private var remedyAdapter: ViewPagerRemedyAdapter?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_remedy)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_remedy)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Remedy"
        setTab()
    }

    private fun setTab() {
        remedyAdapter = ViewPagerRemedyAdapter(supportFragmentManager)
        binding.viewPager.adapter = remedyAdapter
        binding.tabLayout.setupWithViewPager(binding.viewPager)
        binding.tabLayout.getChildAt(0)
    }
}