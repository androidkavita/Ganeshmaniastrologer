package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class AvailabilityResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : AvailabilityResponseData?   = AvailabilityResponseData()
)
data class AvailabilityResponseData(
    @SerializedName("profile"               ) var profile              : Profile?                        = Profile(),
    @SerializedName("calendar_availability" ) var calendarAvailability : ArrayList<CalendarAvailability> = arrayListOf()
)
data class Profile (
    @SerializedName("id"      ) var id      : Int?    = null,
    @SerializedName("name"    ) var name    : String? = null,
    @SerializedName("profile" ) var profile : String? = null
)
data class CalendarAvailability (
    @SerializedName("date"           ) var date          : String?                  = null,
    @SerializedName("day_name"       ) var dayName       : String?                  = null,
    @SerializedName("avail_date"     ) var availDate     : String?                  = null,
    @SerializedName("avail_timmings" ) var availTimmings : ArrayList<AvailTimmings> = arrayListOf()
)
data class AvailTimmings (
    @SerializedName("from_time"  ) var fromTime  : String? = null,
    @SerializedName("to_time"    ) var toTime    : String? = null,
    @SerializedName("time_avail" ) var timeAvail : String? = null
)
