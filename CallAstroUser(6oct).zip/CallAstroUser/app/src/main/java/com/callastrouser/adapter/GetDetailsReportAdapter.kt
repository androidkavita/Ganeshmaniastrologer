package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowSelectReportTypeBinding
import com.callastrouser.model.ChatFragmentResponseData
import com.callastrouser.model.GetAstroDetailsResponseData

class GetDetailsReportAdapter (val context : Context, var Listdata: ArrayList<GetAstroDetailsResponseData>, var details:GetDeitails) :
    RecyclerView.Adapter<GetDetailsReportAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowSelectReportTypeBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GetDetailsReportAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_select_report_type, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: GetDetailsReportAdapter.ViewHolder, position: Int) {
        var Data =Listdata[position]
        holder.binding.name.text = Data.title
        holder.binding.description.text = Data.description
        Glide.with(context).load(Data.image).into(holder.binding.image)
        holder.binding.linearItem.setOnClickListener {
            details.getid(Data.id.toString())
        }
    }

    override fun getItemCount(): Int {
        return Listdata.size
    }
    @SuppressLint("NotifyDataSetChanged")
    fun filterList(filteredStateList: ArrayList<GetAstroDetailsResponseData>) {
        Listdata = filteredStateList
        notifyDataSetChanged()
    }
}
interface GetDeitails{
    fun getid(id:String)
}
