package com.callastrouser.ui.activities

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.CartListAdapter
import com.callastrouser.adapter.Itemplusminus
import com.callastrouser.databinding.ActivityMyCartListCheckoutBinding
import com.callastrouser.databinding.RowChatwithusBinding
import com.callastrouser.model.ProductList
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.OrderDetailsViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject

@AndroidEntryPoint
class MyCartListCheckout : BaseActivity(), Itemplusminus {
    lateinit var binding: ActivityMyCartListCheckoutBinding
    private val viewModel: OrderDetailsViewModel by viewModels()
    lateinit var id :String
    lateinit var address_id :String
    lateinit var adapter : CartListAdapter
    var minteger = 0

    var List : ArrayList<ProductList> = arrayListOf()

    lateinit var orderId:String
    lateinit var productName:String
    lateinit var totalItem:String
    lateinit var expactDeliveryDate:String
    lateinit var orderStatus:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_cart_list_checkout)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_my_cart_list_checkout)

        if (intent!= null){
            id = intent.getStringExtra("id").toString()
            address_id = intent.getStringExtra("addressid").toString()
        }

        binding.header.tvHeadName.text = "My Cart"
        binding.header.backArrow.setOnClickListener {
            finish()
        }

        binding.maindata.visibility = View.GONE
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.cart_lists(
                "Bearer "+userPref.getToken().toString(),
                "",address_id
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }


        binding.apply.setOnClickListener {
            if (binding.coupondiscount.text.isNullOrEmpty()){
                toast(this@MyCartListCheckout,"please enter coupon code.")
            }else{
                viewModel.cart_lists(
                    "Bearer "+userPref.getToken().toString(),
                    binding.coupondiscount.text.toString(),address_id
                )
            }

        }
        viewModel.cartListResponse.observe(this){
            if (it.status == 1){
                binding.idNouser.visibility = View.GONE
                binding.maindata.visibility = View.VISIBLE
                List.clear()
                List.addAll(it.data!!.productList)
                adapter = CartListAdapter(this,List,this)
                binding.rvItemList.adapter = adapter
                binding.productrupees.text = "₹"+it.data?.totalItemAmount.toString()
                binding.shippingCharges.text= "₹"+it.data?.shippingCharg.toString()
                binding.couponDiscount.text= "₹"+it.data?.couponDiscount.toString()
                binding.tax.text= "₹"+it.data?.tax.toString()
                binding.TotalAmount.text= "₹"+it.data?.grandTotal.toString()
                var payment = it.data?.grandTotal.toString()
                var coupon = it.data?.couponDiscount.toString()


                binding.placeorder.setOnClickListener {
                    var intent = Intent(this@MyCartListCheckout,AddressList::class.java)
                    intent.putExtra("id",id)
                    intent.putExtra("bookingtype","cart")
                    intent.putExtra("amount",payment)
                    intent.putExtra("coupon_discount",coupon)
                    startActivity(intent)
                }
            }else if (it.status == 3){
                toast(this@MyCartListCheckout,it.message.toString())
            }else{
                binding.idNouser.visibility = View.VISIBLE
                binding.nodatatext.text = it.message.toString()
                binding.maindata.visibility = View.GONE
            }
        }



        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                viewModel.cart_lists(
                    "Bearer "+userPref.getToken().toString(),
                    "",address_id
                )
            }else{
                snackbar(it.message.toString())
            }
        }
    }

    override fun Datas(position:Int,id: String, minus: ImageView, plus: ImageView, qty: String,ivcross:ImageView,mainid:String,type:String) {
        minteger = qty.toInt()
//        toast(this@MyCartListCheckout,qty.toString())
//        minus.setOnClickListener{
        if (type == "2") {
            if (minteger > 1) {
                minteger -= 1
                binding.tvCount.text = minteger.toString()
                viewModel.add_to_cart("Bearer " + userPref.getToken().toString(), id, "2")
            } else {
                val buinder = AlertDialog.Builder(this)
                buinder.setMessage("Are you sure, you want to remove this item?")
                buinder.setIcon(R.drawable.alert)
                buinder.setTitle("Alert!!")

                buinder.setPositiveButton("Yes") { dialogInterface, which ->
                    viewModel.delete_cart("Bearer " + userPref.getToken().toString(), mainid)
                }
                buinder.setNegativeButton("No") { dialogInterface, which ->
                }
                val alertDialog: AlertDialog = buinder.create()
                alertDialog.setCancelable(false)
                alertDialog.show()
            }
        }
        if (type == "1"){
                if (minteger > 1) {
                    minteger -= 1
                    binding.tvCount.text = minteger.toString()

                }
                viewModel.add_to_cart("Bearer "+userPref.getToken().toString(),id,"1")
            }

//        }

        if (type == "3"){
            val buinder = AlertDialog.Builder(this)
            buinder.setMessage("Are you sure, you want to remove this item?")
            buinder.setIcon(R.drawable.alert)
            buinder.setTitle("Alert!!")

            buinder.setPositiveButton("Yes") { dialogInterface, which ->
                viewModel.delete_cart("Bearer "+userPref.getToken().toString(),mainid)
            }
            buinder.setNegativeButton("No") { dialogInterface, which ->
            }

            val alertDialog: AlertDialog = buinder.create()
            alertDialog.setCancelable(false)
            alertDialog.show()
        }

    }


}