package com.callastrouser.ui.activities

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.NotificationAdapter
import com.callastrouser.databinding.ActivityNotificationBinding
import com.callastrouser.model.NotificationData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.CustomerViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class Notification : BaseActivity() {
    lateinit var binding: ActivityNotificationBinding
    private val viewModel: CustomerViewModel by viewModels()
    lateinit var adapter : NotificationAdapter
    var Listdata : ArrayList<NotificationData> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_notification)
        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Notification"
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.Notification(
                "Bearer "+userPref.getToken().toString()
            )
            viewModel.Notification_Read("Bearer "+userPref.getToken().toString())
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.commonResponse.observe(this){
            if (it.status == 1){

            }else{

            }
        }

        viewModel.NotificationResponse.observe(this) {
            if (it?.status == 1) {
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = NotificationAdapter(this, Listdata)
                binding.rvAssistant.adapter =adapter
            } else {
                snackbar(it?.message!!)
            }
        }






    }
}