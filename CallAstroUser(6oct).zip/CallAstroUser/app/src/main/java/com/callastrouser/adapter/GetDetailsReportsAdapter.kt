package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowGetDetailsBinding
import com.callastrouser.model.AstrologersListViewAllResponseData
import com.callastrouser.model.ChatFragmentResponseData

class GetDetailsReportsAdapter (val context : Context, var Listdata :ArrayList<AstrologersListViewAllResponseData>, var Click:GetDetsilsButton) :
    RecyclerView.Adapter<GetDetailsReportsAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowGetDetailsBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GetDetailsReportsAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_get_details, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: GetDetailsReportsAdapter.ViewHolder, position: Int) {
        var data = Listdata[position]
        holder.binding.name.text = data.name.toString()
        holder.binding.designation.text = data.expertise.toString()
        holder.binding.language.text = data.language.toString()
        holder.binding.experience.text = data.experence.toString()
        holder.binding.money.text = "₹"+data.calling_charg.toString()+"/min"
        Glide.with(context).load(data.profile).into(holder.binding.image)


        holder.binding.getreportll.setOnClickListener {
            Click.buttonclick(data.id.toString(),position,holder.binding.getreportll)
        }
    }

    override fun getItemCount(): Int {
        return Listdata.size
    }
    @SuppressLint("NotifyDataSetChanged")
    fun filterList(filteredStateList: ArrayList<AstrologersListViewAllResponseData>) {
        Listdata = filteredStateList
        notifyDataSetChanged()
    }
}
interface GetDetsilsButton{
    fun buttonclick(id:String,position: Int,detailsbutton: LinearLayoutCompat)
}