package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.ActiveHomeResponse
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.Notiffication_Count_Response
import com.callastrouser.model.RechargeAmountDiscountResponse
import com.callastrouser.model.TransactionHistoryResponse
import com.callastrouser.model.ViewProfile
import com.callastrouser.model.WalletResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class WalletViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    val walletResponse = MutableLiveData<WalletResponse>()
    val notificationcountresponseResponse = MutableLiveData<Notiffication_Count_Response>()
    val activeHomeResponse = MutableLiveData<ActiveHomeResponse>()
    val transactionHistory = MutableLiveData<TransactionHistoryResponse>()
    val rechargeAmountDiscountResponse = MutableLiveData<RechargeAmountDiscountResponse>()
    var commonResponse = MutableLiveData<CommonResponse>()
    val viewProfileResponse = MutableLiveData<ViewProfile>()

    fun wallet(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.Wallet(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                walletResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun notification_count(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.notification_count(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                notificationcountresponseResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }



    fun ViewProfile(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.ViewProfile(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                viewProfileResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }


    }
    fun active_home(
        token: String,
    ) {
//        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.active_home(token)
            if (response.isSuccessful) {
//                progressBarStatus.value = false
                activeHomeResponse.postValue(response.body())
            } else {
//                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun history_wallets(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.history_wallets(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                transactionHistory.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun add_money(
        token:String,
        amount: String,
        payment_status: String,
        transaction_id: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.add_money(token,amount,payment_status,transaction_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun Rechargewithdiscount(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.recharg_amount_list(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                rechargeAmountDiscountResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

}