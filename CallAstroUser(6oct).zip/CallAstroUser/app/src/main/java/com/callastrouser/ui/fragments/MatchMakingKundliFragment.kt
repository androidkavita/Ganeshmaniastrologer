package com.callastrouser.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.R
import com.callastrouser.adapter.KundaliListAdapter
import com.callastrouser.adapter.MatchMakingKundliListAdapter
import com.callastrouser.databinding.FragmentKundliBinding
import com.callastrouser.databinding.FragmentMatchMakingKundliBinding
import com.callastrouser.model.AstrologersListViewAllResponseData
import com.callastrouser.model.RecentSeeKundliResponseData
import com.callastrouser.ui.activities.EnterKundaliDetails
import com.callastrouser.ui.activities.MakeKundali
import com.callastrouser.viewModel.KundaliViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MatchMakingKundliFragment : BaseFragment() {
    lateinit var binding: FragmentMatchMakingKundliBinding
    lateinit var adapter:MatchMakingKundliListAdapter
    val viewModel: KundaliViewModel by viewModels()
    var Listdata : ArrayList<RecentSeeKundliResponseData> = arrayListOf()
    var scpflag: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentMatchMakingKundliBinding.inflate(inflater,container,false)

        viewModel.recently_see_kundali("Bearer "+userPref.getToken().toString(),"2")

        viewModel.recentSeeKundliResponse.observe(viewLifecycleOwner){
            if (it.status == 1){
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = MatchMakingKundliListAdapter(requireContext(),Listdata)
                binding.rvMakekundali.adapter = adapter
            }
        }

        binding.btnmakekundali.setOnClickListener {
                startActivity(Intent(requireContext(), MakeKundali::class.java))
        }
        binding.tvSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(text: Editable?) {
                filterData(text.toString(), scpflag)
            }

        })

        return binding.root


    }

    override fun onResume() {
        super.onResume()
        viewModel.recently_see_kundali("Bearer "+userPref.getToken().toString(),"2")

    }
    private fun filterData(searchText: String, scpflag: String) {
        var filteredStateList: java.util.ArrayList<RecentSeeKundliResponseData> = java.util.ArrayList()


//        if (scpflag.equals("State")) {
        for (item in Listdata) {
            try {
                if (item.mname!!.toLowerCase().contains(searchText.toLowerCase()) or item.fname!!.toLowerCase().contains(searchText.toLowerCase())) {
                    filteredStateList.add(item)
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }
        try {
            adapter?.filterList(filteredStateList)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}