package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ReportIntakeDetail(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : ReportIntakeDetailData?   = ReportIntakeDetailData()
)
data class ReportIntakeDetailData(
    @SerializedName("id"       ) var id       : Int?    = null,
    @SerializedName("name"     ) var name     : String? = null,
    @SerializedName("profile"  ) var profile  : String? = null,
    @SerializedName("language" ) var language : String? = null
)