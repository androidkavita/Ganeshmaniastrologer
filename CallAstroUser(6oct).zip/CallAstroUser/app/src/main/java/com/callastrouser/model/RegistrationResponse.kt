package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class RegistrationResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : RegistrationResponseData?   = RegistrationResponseData()
)
data class RegistrationResponseData(
    @SerializedName("id"      ) var id      : Int?    = null,
    @SerializedName("name"    ) var name    : String? = null,
    @SerializedName("profile" ) var profile : String? = null,
    @SerializedName("gender"  ) var gender  : Int?    = null,
    @SerializedName("dob"     ) var dob     : String? = null,
    @SerializedName("address" ) var address : String? = null,
    @SerializedName("email" ) var email : String? = null,
    @SerializedName("api_token" ) var apiToken : String? = null,
    @SerializedName("mobile_no" ) var mobileNo : String? = null,
)
