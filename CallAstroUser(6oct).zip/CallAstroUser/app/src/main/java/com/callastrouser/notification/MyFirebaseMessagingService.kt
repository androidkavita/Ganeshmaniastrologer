package com.callastrouser.notification

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.callastrouser.R
import com.callastrouser.ui.activities.BookingDetailsActivity
import com.callastrouser.ui.activities.ChatActivity
import com.callastrouser.ui.activities.IncomingCallActivity
import com.callastrouser.ui.activities.LiveActivity
import com.callastrouser.ui.activities.LiveastrologerViewall
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.maxtra.callastro.prefs.UserPref

class FirebaseMessagingServices : FirebaseMessagingService() {
    private var count = 0
    var notificationCount = "0"
    var mNotificationId = 1
    lateinit var userPref : UserPref
//    lateinit var broadCastingReceiver: BroadCastingReceiver

    override fun onMessageReceived(remote: RemoteMessage) {
        super.onMessageReceived(remote)
        Log.e("msg", "msg")
        userPref = UserPref(applicationContext)
        val data = remote.data
        Log.d("noti_message_data", data.toString())
        val title = remote.notification?.title ?: "title"
        val body = remote.notification?.body ?: "body"
        createNotification(body, remote.data, title)

//        broadCastingReceiver = BroadCastingReceiver() //passing context
////        IntentFilter(Intent.ACTION_CALL).also {
//        registerReceiver(broadCastingReceiver, IntentFilter("BroadCastingReceiver"));
////        }
//        val broadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
//            override fun onReceive(context: Context?, intent: Intent?) {
//                // internet lost alert dialog method call from here...
//                broadCastingReceiver.ma!!.chatList()
//            }
//        }
    }

    private fun createNotification(
        body: String,
        data: MutableMap<String, String>,
        title: String
    ) {

        try {
//            notificationCount = "0"
            val title = title
            val type: String = data["call_type"].toString()
            val astroname: String = data["astro_name"].toString()
            val astroid: String = data["astro_id"].toString()
            val channel_name: String = data["channel_name"].toString()
            val profileimage: String = data["astro_profile"].toString()
            val caller_id : String = data["caller_id"].toString()
            val agoratoken: String = data["agora_token"].toString()
            val calling_charge: String = data["calling_charg"].toString()
            val unique_id: String = data["unique_id"].toString()
            val order_id: String = data["order_id"].toString()
            val product_id: String = data["product_id"].toString()
            val id: String = data["id"].toString()
            val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val notificationBuilder =
                NotificationCompat.Builder(
                    this,
                    getString(R.string.default_notification_channel_id)
                )
                    .setSmallIcon(getNotificationIcon())
                    .setSound(defaultSoundUri)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setChannelId(getString(R.string.default_notification_channel_id))
            val notificationBuilder1 =
                NotificationCompat.Builder(
                    this,
                    getString(R.string.default_notification_channel_id)
                )
                    .setSmallIcon(getNotificationIcon())
                    .setSound(defaultSoundUri)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setChannelId(getString(R.string.default_notification_channel_id))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                notificationBuilder.setChannelId(getString(R.string.default_notification_channel_id))

                val notificationChannel = NotificationChannel(
                    getString(R.string.default_notification_channel_id),
                    getString(R.string.app_name),
                    NotificationManager.IMPORTANCE_HIGH

                )
                notificationChannel.lockscreenVisibility = Notification.VISIBILITY_PRIVATE
                notificationManager?.createNotificationChannel(notificationChannel)
            }

            if (type == "1") {
                try {
//                    val contentIntent = PendingIntent.getActivity(
//                        this, 0,
                    var intent = Intent(this, IncomingCallActivity::class.java)
                        .putExtra("type",type)
                        .putExtra("astroid",astroid)
                        .putExtra("astroname",astroname)
                        .putExtra("profileimage",profileimage)
                        .putExtra("caller_id",caller_id)
                        .putExtra("channel_name",channel_name)
                        .putExtra("agoratoken",agoratoken)
                        .putExtra("unique_id",unique_id)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
//                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
//                        )
//                    notificationBuilder.setContentIntent(contentIntent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else if (type == "2"){
                try {
//                    val contentIntent = PendingIntent.getActivity(
//                        this, 0,
                    var intent = Intent(this, IncomingCallActivity::class.java)
                        .putExtra("type",type)
                        .putExtra("astroid",astroid)
                        .putExtra("astroname",astroname)
                        .putExtra("profileimage",profileimage)
                        .putExtra("caller_id",caller_id)
                        .putExtra("channel_name",channel_name)
                        .putExtra("agoratoken",agoratoken)
                        .putExtra("unique_id",unique_id)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
//                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
//                        )
//                    notificationBuilder.setContentIntent(contentIntent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }else if (type == "live"){
                try {
                    val contentIntent = PendingIntent.getActivity(
                        this, 1,
                        Intent(this, LiveActivity::class.java)
                            .putExtra("channelname",channel_name)
                            .putExtra("agora_token",agoratoken)
                            .putExtra("name",astroname)
                            .putExtra("profile",profileimage)
                            .putExtra("calling_charg",calling_charge)
                            .putExtra("id",astroid)
                        ,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    notificationBuilder.setContentIntent(contentIntent)

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }else if (type == "orders"){
                try {
                    val contentIntent = PendingIntent.getActivity(
                        this, 1,
                        Intent(this, BookingDetailsActivity::class.java)
                            .putExtra("order_id",order_id)
                            .putExtra("id",product_id)
                        ,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    notificationBuilder.setContentIntent(contentIntent)

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else if (type == "cancel"){
                try {
//                    val contentIntent = PendingIntent.getActivity(
//                        this, 1,
//                        Intent(this, BookingDetailsActivity::class.java)
//                            .putExtra("order_id",order_id)
//                            .putExtra("id",product_id)
//                        ,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
//                    )
//                    notificationBuilder.setContentIntent(contentIntent)

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }else if (type == "chat"){
                try {
                    val contentIntent = PendingIntent.getActivity(
                        this, 1,
                        Intent(this, ChatActivity::class.java)
                            .putExtra("type",type)
                            .putExtra("astroid",astroid.toString())
                            .putExtra("astroname",astroname.toString())
//                            .putExtra("profileimage",profileimage)
//                            .putExtra("channel_name",channel_name)
                            .putExtra("caller_id",caller_id)
                            .putExtra("agoratoken",agoratoken)
                        ,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    notificationBuilder.setContentIntent(contentIntent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

//        }else if (title=="accepted"){
//            val contentIntent1 = PendingIntent.getActivity(
//                this, 1,
//                Intent(this, RideStatusActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT
//            )
//            notificationBuilder.setContentIntent(contentIntent1)
//        }else if (title=="complete"){
//            val contentIntent2 = PendingIntent.getActivity(
//                this, 2,
//                Intent(this, RideStatusActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT
//            )
//            notificationBuilder.setContentIntent(contentIntent2)
//        }


// Gets an instance of the NotificationManager service


// Gets an instance of the NotificationManager service
            val mNotificationManager =
                this.getSystemService(NOTIFICATION_SERVICE) as NotificationManager


// Builds the notification and issues it.


// Builds the notification and issues it.

//            if (userPref.getmessageContain().isNullOrEmpty()){
                mNotificationManager.notify(mNotificationId, notificationBuilder.build())
//            }else {

//            }


//        notificationManager.notify(Random.nextInt(), notificationBuilder.build())

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getNotificationIcon(): Int {

        val useWhiteIcon = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
        return if (useWhiteIcon) R.drawable.logo else R.drawable.logo
    }

}