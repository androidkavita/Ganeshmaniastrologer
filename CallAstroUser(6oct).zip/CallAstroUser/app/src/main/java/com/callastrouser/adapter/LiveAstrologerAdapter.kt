package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowLiveastrologersBinding
import com.callastrouser.model.LiveStrologers

class LiveAstrologerAdapter (val context : Context, var data: ArrayList<LiveStrologers>,var click: LiveAstro) :
    RecyclerView.Adapter<LiveAstrologerAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowLiveastrologersBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_liveastrologers, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.name
        holder.binding.topic.text = List.topic
        Glide.with(context).load(List.profile).into(holder.binding.rvImgs)
        click.Click(holder.binding.linearItem,List.id.toString(),List.channel_name.toString(),List.agora_token.toString(),List.name.toString(),List.profile.toString(),List.calling_charg.toString())
//        holder.binding.linearItem.setOnClickListener(View.OnClickListener {
//            val intent = Intent(context, DriverDetailActivity::class.java)
//            intent.putExtra("orderType", "4")
//            intent.putExtra("id",List.id)
//            context.startActivity(intent)
//        })
    }

    override fun getItemCount(): Int {
        return data.size
    }

}
interface LiveAstro{
    fun Click(layout:LinearLayout,id:String,channelName:String,agoraToken:String,name:String,Profile:String,calling_charg:String)
}