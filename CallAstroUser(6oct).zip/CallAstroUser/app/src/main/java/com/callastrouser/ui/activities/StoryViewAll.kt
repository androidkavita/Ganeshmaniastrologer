package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.Story
import com.callastrouser.adapter.StoryViewAllAdapter
import com.callastrouser.databinding.ActivityStoryViewAllBinding
import com.callastrouser.model.BlogListResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.StoryViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class StoryViewAll : BaseActivity(),Story {
    lateinit var binding: ActivityStoryViewAllBinding
    lateinit var id :String
    lateinit var adapter: StoryViewAllAdapter
    var list :ArrayList<BlogListResponseData> = arrayListOf()
    private val viewModel:StoryViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_story_view_all)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_story_view_all)

        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Stories"


//        if (intent != null){
//            id = intent.getStringExtra("id").toString()
//        }

        if (CommonUtils.isInternetAvailable(this@StoryViewAll)) {
            viewModel.get_blog_list(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.blogListResponse.observe(this){
            if (it.status == 1){
                list.clear()
                list.addAll(it.data)
                adapter = StoryViewAllAdapter(this@StoryViewAll,list,this)
                binding.rvPurchasedProducts.adapter = adapter

            }
        }

    }

    override fun layoutid(layout: LinearLayout, id: String, name: String) {
        layout.setOnClickListener {
            startActivity(Intent(this@StoryViewAll, StoryView::class.java).putExtra("id",id))
        }


    }
}