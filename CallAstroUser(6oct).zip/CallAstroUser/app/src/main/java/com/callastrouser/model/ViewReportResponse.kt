package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ViewReportResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ViewReportResponseData = ViewReportResponseData()
)
data class ViewReportResponseData(
    @SerializedName("id" ) var id : String? = null,
    @SerializedName("text" ) var text : String? = null,
    @SerializedName("file" ) var file : String? = null,
    @SerializedName("name" ) var name : String? = null,
    @SerializedName("profile" ) var profile : String? = null,
    @SerializedName("created_at" ) var created_at : String? = null,
)
