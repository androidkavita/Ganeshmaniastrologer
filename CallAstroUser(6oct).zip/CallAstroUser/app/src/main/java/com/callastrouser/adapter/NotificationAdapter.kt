package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowNotificationItemBinding
import com.callastrouser.model.NotificationData

class NotificationAdapter (val context : Context, var data: ArrayList<NotificationData>) :
    RecyclerView.Adapter<NotificationAdapter.ViewHolder>() {
    var isread:Int = 0

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowNotificationItemBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotificationAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_notification_item, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: NotificationAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.tvHead.text = List.title.toString()
        isread = List.isRead!!.toInt()
        holder.binding.tvDetail.text = List.message
        holder.binding.tvDate.text = List.time
        if (isread.equals(1)){
            holder.binding.tvCount.visibility = View.GONE
        }else{
            holder.binding.tvCount.visibility = View.VISIBLE
        }
//        holder.binding.experience.text = List.experence.toString()
//        holder.binding.money.text = List.
//        Glide.with(context).load(List.profile).into(holder.binding.image)
//        holder.binding.linearItem.setOnClickListener(View.OnClickListener {
//            val intent = Intent(context, DriverDetailActivity::class.java)
//            intent.putExtra("orderType", "4")
//            intent.putExtra("id",List.id)
//            context.startActivity(intent)
//        })
    }

    override fun getItemCount(): Int {
        return data.size
    }

}