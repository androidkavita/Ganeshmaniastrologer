package com.callastrouser.adapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.callastrouser.ui.fragments.CompletedEcommerceProductsFragment
import com.callastrouser.ui.fragments.KundliFragment
import com.callastrouser.ui.fragments.MatchMakingKundliFragment
import com.callastrouser.ui.fragments.OnGoingEcommerceProductsFragment

class ViewPagerKundliAdapter (
    fragmentManager: FragmentManager
) : FragmentPagerAdapter(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    private val titles =
        arrayOf("Kundli","Match Making")

    override fun getItem(position: Int): Fragment {

        val bundle = Bundle()
        val fragment : Fragment
        return when (position) {
            0 -> {
                fragment = KundliFragment()
                bundle.putInt("type",0)
                fragment.arguments = bundle
                fragment
            }

            else -> {
                fragment = MatchMakingKundliFragment()
                bundle.putInt("type",1)
                fragment.arguments = bundle
                fragment
            }
        }
    }

    override fun getCount(): Int {
        return titles.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return titles[position]
    }
}