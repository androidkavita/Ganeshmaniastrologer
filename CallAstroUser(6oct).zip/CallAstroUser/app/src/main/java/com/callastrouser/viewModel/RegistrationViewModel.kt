package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.RegistrationResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RegistrationViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {

    val progressBarStatus = MutableLiveData<Boolean>()
    val registrationResponse = MutableLiveData<RegistrationResponse>()


    fun Registration(
        id: String,
        name: String,
        dob: String,
        address: String,
        gender: String,
        birth_time: String,
        email: String,
//        mobile_no: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.Registration(id,name,dob,address,gender,birth_time,email,/*mobile_no*/)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                registrationResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

}