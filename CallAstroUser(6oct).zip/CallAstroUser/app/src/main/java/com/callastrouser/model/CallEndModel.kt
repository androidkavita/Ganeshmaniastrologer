package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class CallEndModel(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : CallEndModelData?   = CallEndModelData()
)
data class CallEndModelData(
    @SerializedName("wallet"        ) var wallet       : String? = null,
    @SerializedName("calling_charg" ) var callingCharg : Int?    = null
)
