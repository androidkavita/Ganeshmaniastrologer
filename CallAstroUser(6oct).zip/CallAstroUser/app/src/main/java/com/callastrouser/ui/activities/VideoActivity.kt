package com.callastrouser.ui.activities

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.util.DisplayMetrics
import android.util.Log
import android.view.SurfaceView
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.ActivityVideoBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.Constant
import com.callastrouser.util.toast
import com.callastrouser.viewModel.VideoCallViewModel
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import de.hdodenhof.circleimageview.CircleImageView
import io.agora.rtc2.*
import io.agora.rtc2.video.VideoCanvas
import java.text.DecimalFormat
import java.util.*

@AndroidEntryPoint
class VideoActivity : BaseActivity(),View.OnClickListener {

    private lateinit var binding: ActivityVideoBinding
    private val viewModel: VideoCallViewModel by viewModels()

    private var channelName: String? = ""
    private var token: String? = ""
    var doctorName: String? = null
    var doctorImage: String? = null
    var user_id: String? = null
    var booking_id: String? = null

    private val PERMISSION_REQ_ID = 22
    /*val REQUESTED_PERMISSIONS = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA,
        Manifest.permission.READ_PHONE_STATE
    )*/
    private val REQUESTED_PERMISSIONS= arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA,
        Manifest.permission.READ_PHONE_STATE
    )

    private fun checkSelfPermission(): Boolean {
        return !(ContextCompat.checkSelfPermission(
            this,
            REQUESTED_PERMISSIONS[0]
        ) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    this,
                    REQUESTED_PERMISSIONS[1]
                ) != PackageManager.PERMISSION_GRANTED)
    }
    private var counter = 0
    // An integer that identifies the local user.
    private val uid = 0
    private var isJoined = false
    lateinit var name : TextView
    lateinit var expertise : TextView
    lateinit var language : TextView
    lateinit var experience : TextView
    lateinit var image : CircleImageView
    private var agoraEngine: RtcEngine? = null
    private var callTimer: Timer? = null
    //SurfaceView to render local video in a Container.
    private var localSurfaceView: SurfaceView? = null
    lateinit var bottomdialog: BottomSheetDialog
    //SurfaceView to render Remote video in a Container.
    private var remoteSurfaceView: SurfaceView? = null
    private var mMuted = false
    var mMediaPlayer: MediaPlayer? = null
    var vib: Vibrator? = null
    var astroname: String? = null
    var caller_id: String? = null
    var astroid: String? = null
    lateinit var apitimer :String
    private var WalletMoney: Int = 0
    private var CallingCharge: Int = 0
    private var Calculatetime: Int = 0
    private var Minimumbalence: Int = 0
    val handlerStatusCheck = Handler(Looper.getMainLooper())
    var runnableStatusCheck: Runnable? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_video)


        if (intent!=null) {
                astroid = intent.getStringExtra("astroid").toString()
                astroname = intent.getStringExtra("astroname").toString()
                caller_id = intent.getStringExtra("caller_id").toString()
                channelName = intent.getStringExtra("channel_name")
                token = intent.getStringExtra("agoratoken")

        }
        playSound()

        // If all the permissions are granted, initialize the RtcEngine object and join a channel.
        if (!checkSelfPermission()) {
            ActivityCompat.requestPermissions(this, REQUESTED_PERMISSIONS, PERMISSION_REQ_ID);
        }

        setupVideoSDKEngine()
        CallStart()
        binding.name.text = astroname
        viewModel.callStartResponse.observe(this){
            if (it.status == 1){
                WalletMoney = it.data?.wallet!!.toInt()
                CallingCharge = it.data?.callingCharg!!.toInt()
                Calculatetime = (WalletMoney/CallingCharge)*60
                Minimumbalence = CallingCharge*5
                if(WalletMoney < Minimumbalence){
//                    toast(this@AudioCallActivity,"you don't have enough balence.")

                    Alertdialog()
                }else{
                    joinChannel(token.toString(),channelName.toString())
                }
            }
        }


        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                Alertdialog1()
            }
        }

        binding.buttonCall.setOnClickListener(this)
        binding.buttonSwitchCamera.setOnClickListener(this)
        binding.videoBtn.setOnClickListener(this)
        binding.buttonMute.setOnClickListener(this)

        handlerStatusCheck.postDelayed(Runnable { //do something
            handlerStatusCheck.postDelayed(runnableStatusCheck!!, 5000)
            if (CommonUtils.isInternetAvailable(this@VideoActivity)) {
                viewModel.call_ring("Bearer "+userPref.getToken().toString(),astroid.toString(),userPref.getUserId().toString(),caller_id.toString())
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast(this@VideoActivity,"Please check internet connection.")
            }


        }.also { runnableStatusCheck = it }, 0)
        viewModel.callRingResponse.observe(this){
            if (it.status == 1){
                if (it.data?.ringStatus == 1){
                    finish()
                }
            }
        }

    }
    fun Alertdialog1(){
        val buinder = AlertDialog.Builder(this)
        buinder.setMessage("Video Call has been ended.")
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Call Ended!!")

        buinder.setPositiveButton("OK") { dialogInterface, which ->
//                        val intent = Intent(this, CreateOrder::class.java)
//                        intent.putExtra("POPUP_FLAG", "yes")
//                        startActivity(intent)
            ReviewAndRating()

        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }


    fun ReviewAndRating() {
        // on below line we are creating a new bottom sheet dialog.
        bottomdialog = BottomSheetDialog(this)
        // on below line we are inflating a layout file which we have created.
        val view = layoutInflater.inflate(R.layout.astro_review_and_rating, null)
        val metrics = DisplayMetrics()
        windowManager?.defaultDisplay?.getMetrics(metrics)
        bottomdialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomdialog.behavior.peekHeight = metrics.heightPixels

        name = view.findViewById(R.id.name)
        expertise = view.findViewById(R.id.expertise)
        language = view.findViewById(R.id.language)
        experience = view.findViewById(R.id.experience)
        image = view.findViewById(R.id.iv_image)
        var btnSubmit = view.findViewById<AppCompatButton>(R.id.btnSubmit)
        var rating_complete = view.findViewById<RatingBar>(R.id.rating_complete)
        var etReason = view.findViewById<EditText>(R.id.etReason)
        var cancel = view.findViewById<ImageView>(R.id.cancel)
//        name.text = user_name.toString()
//        charge.text = charges.toString()
//        time.text = times.toString()
//        Glide.with(requireContext()).load(profiles).into(image)


        if (CommonUtils.isInternetAvailable(this@VideoActivity)) {
            viewModel.strologer_details(
                "Bearer " + userPref.getToken().toString(),
                astroid.toString()
            )

        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this@VideoActivity,"Please check internet connection.")
        }

        cancel.setOnClickListener{
            bottomdialog.dismiss()
            finish()
        }
        viewModel.astrorahiResponse.observe(this) {
            if (it.status == 1) {
                name.text = it.data?.name.toString()
                expertise.text = it.data?.expertise.toString()
                language.text = it.data?.language.toString()
                experience.text = "Exp: "+it.data?.experence.toString()
                Glide.with(this).load(it.data?.profile).into(image)
            }
        }
        viewModel.givereviewResponse.observe(this){
            if (it.status == 1){
                finish()
            }else{
                snackbar(it.message.toString())
            }
        }

        btnSubmit.setOnClickListener{

            if (rating_complete.rating.toInt().equals(0)){
                toast(this@VideoActivity,"Please rate to our astrologer.")
            }else{
                if (CommonUtils.isInternetAvailable(this@VideoActivity)) {
                    viewModel.user_give_review(
                        "Bearer "+userPref.getToken().toString(),
                        astroid.toString(),rating_complete.rating.toString(),etReason.text.toString(),caller_id.toString(),"2"
                    )
                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this@VideoActivity,"Please check internet connection.")
                }
            }
        }
        bottomdialog.setCancelable(false)

        // on below line we are setting
        // content view to our view.
        bottomdialog.setContentView(view)

        // on below line we are calling
        // a show method to display a dialog.
        bottomdialog.show()



    }
    private fun joinChannel(token: String, channelName: String) {
        if (checkSelfPermission()) {
            val options = ChannelMediaOptions()

            // For a Video call, set the channel profile as COMMUNICATION.
            options.channelProfile = io.agora.rtc2.Constants.CHANNEL_PROFILE_COMMUNICATION
            // Set the client role as BROADCASTER or AUDIENCE according to the scenario.
            options.clientRoleType = io.agora.rtc2.Constants.CLIENT_ROLE_BROADCASTER
            // Display LocalSurfaceView.
            setupLocalVideo()
            localSurfaceView?.visibility = View.VISIBLE
            // Start local preview.
            agoraEngine?.startPreview()
            // Join the channel with a temp token.
            // You need to specify the user ID yourself, and ensure that it is unique in the channel.
            agoraEngine?.joinChannel(token, channelName, uid, options)
        } else {
            Toast.makeText(applicationContext, "Permissions was not granted", Toast.LENGTH_SHORT)
                .show()
        }
    }
    fun Alertdialog(){
        val buinder = AlertDialog.Builder(this)

        buinder.setMessage("Your wallet balance is Rs $WalletMoney " +
                "Minimum balance required Rs $Minimumbalence " +
                "To connect Astrologer $astroname Recharge now with following balance")
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Recharge Now!!")

        buinder.setPositiveButton("OK") { dialogInterface, which ->
//                        val intent = Intent(this, CreateOrder::class.java)
//                        intent.putExtra("POPUP_FLAG", "yes")
//                        startActivity(intent)
//            finish
            var intent = Intent(this,WalletActivity::class.java)
//                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(true)
        alertDialog.show()
    }
    fun stopSound() {
        if (mMediaPlayer != null) {
            mMediaPlayer?.stop()
            vib?.cancel()
            mMediaPlayer?.release()
            mMediaPlayer = null
        }
    }

    private fun onRemoteUserVideoMuted(uid: Int, muted: Boolean) {
        val surfaceView = binding.remoteVideoView.getChildAt(0) as SurfaceView?

        val tag = surfaceView?.tag
        if (tag != null && tag as Int == uid) {
            surfaceView.visibility = if (muted) View.GONE else View.VISIBLE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        agoraEngine?.stopPreview()
        agoraEngine?.leaveChannel()
        stopSound()
        // Destroy the engine in a sub-thread to avoid congestion
        Thread {
            RtcEngine.destroy()
            agoraEngine = null
        }.start()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        CallEnd()
        binding.tvTime.visibility = View.GONE
        if (!isJoined) {
            showMessage("Join a channel first")

        } else {
//                    finish()
            stopSound()
//                    viewCallStatusApi()
            agoraEngine?.leaveChannel()
            showMessage("You left the channel")
            // Stop remote video rendering.
            if (remoteSurfaceView != null) remoteSurfaceView?.visibility = View.GONE
            // Stop local video rendering.
            if (localSurfaceView != null) localSurfaceView?.visibility = View.GONE
            isJoined = false
        }


    }

    fun showMessage(message: String?) {
        runOnUiThread {
            Toast.makeText(
                applicationContext,
                message,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun setupVideoSDKEngine() {
        try {
            val config = RtcEngineConfig()
            config.mContext = baseContext
            config.mAppId = getString(R.string.appId)
            config.mEventHandler = mRtcEventHandler
            agoraEngine = RtcEngine.create(config)
            // By default, the video module is disabled, call enableVideo to enable it.
            agoraEngine?.enableVideo()


        } catch (e: Exception) {
            showMessage(e.toString())
        }
    }

    private var mRtcEventHandler: IRtcEngineEventHandler = object : IRtcEngineEventHandler() {
        // Listen for the remote host joining the channel to get the uid of the host.
        override fun onUserJoined(uid: Int, elapsed: Int) {
//            showMessage("Remote user joined $uid")
            callTimer = Timer()
            startCallTimer()
            // Set the remote video view
            runOnUiThread {
                setupRemoteVideo(uid)
            }
            stopSound()
        }

        override fun onJoinChannelSuccess(channel: String, uid: Int, elapsed: Int) {
            isJoined = true
//            showMessage("Joined Channel $channel")
        }

        override fun onUserOffline(uid: Int, reason: Int) {
//            showMessage("Remote user offline $uid $reason")
            runOnUiThread { remoteSurfaceView?.visibility = View.GONE
                Alertdialog1()}
//            finish()
            CallEnd()
            binding.tvTime.visibility = View.GONE
            agoraEngine?.leaveChannel()
            stopSound()
        }

        override fun onUserMuteVideo(uid: Int, muted: Boolean) {
            runOnUiThread { onRemoteUserVideoMuted(uid, muted) }
        }

        // remote user has toggled their video
        override fun onRemoteVideoStateChanged(uid: Int, state: Int, reason: Int, elapsed: Int) {
            super.onRemoteVideoStateChanged(uid, state, reason, elapsed)
            runOnUiThread { onRemoteUserVideoToggle(uid, state) }

        }
    }

    fun playSound() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager

        when (am.ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> Log.i("MyApp", "Silent mode")
            AudioManager.RINGER_MODE_VIBRATE -> {
//                vib = this.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
//                vib?.vibrate(2000)
                Log.i("MyApp", "Vibrate mode")
            }
            AudioManager.RINGER_MODE_NORMAL -> {
                /*val manager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                manager.setStreamVolume(AudioManager.STREAM_MUSIC, 10, 0)
                val notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
               mMediaPlayer = MediaPlayer.create(applicationContext, notification)
                if(manager.ringerMode != AudioManager.RINGER_MODE_SILENT)
                    mMediaPlayer?.isLooping = true
                    mMediaPlayer?.start()*/
                Log.i("MyApp", "Normal mode")
            }
        }
    }

    private fun startCallTimer() {
//        if (counter< Calculatetime){
        callTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {

                if (++counter == Calculatetime) counter =
                    0 // for the taluxi app a call must not be longer than 1h.
                val formatter = DecimalFormat("00")
                val timerText =
                    formatter.format((counter / 60).toLong()) + ":" + formatter.format((counter % 60).toLong())
                runOnUiThread {
                    if (counter == 0){
                        CallEnd()
                        binding.tvTime.visibility = View.GONE
                        if (isJoined) {
//                    viewCallStatusApi()
                            showMessage("You left the channel")
                            agoraEngine?.leaveChannel()
                            finish()
                            isJoined = false
                            sendBroadcast(Intent(Constant.ACTION_HANG_UP_ANSWERED_CALL))

                        } else {
//                    showMessage("Join a channel first")

                        }
                    }else{
                        apitimer = timerText
                        binding.tvTime.text = timerText
                    }
                }
                Thread.sleep(1000);
            }
        }, 0, 1000)
//        }else{
//            snackbar("you don't have enough balence.")
//        }

    }
    private fun CallStart() {
        if (CommonUtils.isInternetAvailable(this@VideoActivity)) {
            viewModel.when_call_start(
                "Bearer "+userPref.getToken().toString(),astroid.toString()
                /* userPref.getChannelName().toString()*/
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this@VideoActivity,"Please check internet connection.")
        }

    }


    private fun CallEnd() {
        if (CommonUtils.isInternetAvailable(this@VideoActivity)) {
            viewModel.call_end(
                "Bearer "+userPref.getToken().toString(),apitimer,astroid.toString(),userPref.getUserId().toString(),caller_id.toString(),"3"
                /* userPref.getChannelName().toString()*/
            )
        } else {
            toast(this@VideoActivity,"Please check internet connection.")
        }

    }
    private fun setupRemoteVideo(uid: Int) {

        remoteSurfaceView = SurfaceView(baseContext)
        remoteSurfaceView?.setZOrderMediaOverlay(true)
        binding.remoteVideoView.addView(remoteSurfaceView)
        agoraEngine?.setupRemoteVideo(
            VideoCanvas(
                remoteSurfaceView,
                VideoCanvas.RENDER_MODE_FIT,
                uid
            )
        )
        // Display RemoteSurfaceView.
        remoteSurfaceView?.visibility = View.VISIBLE

    }

    private fun onRemoteUserVideoToggle(uid: Int, state: Int) {

        val videoSurface = binding.remoteVideoView.getChildAt(0) as SurfaceView
        videoSurface.visibility = if (state == 0) View.GONE else View.VISIBLE

        // add an icon to let the other user know remote video has been disabled
        if (state == 0) {
            val noCamera = ImageView(this)
            noCamera.setImageResource(R.drawable.ic_video_cross_y)
            binding.remoteVideoView.addView(noCamera)
        } else {
            try {
                val noCamera = binding.remoteVideoView.getChildAt(1) as ImageView?
                if (noCamera != null) {
                    binding.remoteVideoView.removeView(noCamera)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun setupLocalVideo() {

        // Create a SurfaceView object and add it as a child to the FrameLayout.
        localSurfaceView = SurfaceView(baseContext)
        localSurfaceView?.setZOrderMediaOverlay(true)
        binding.localVideoView.addView(localSurfaceView)
        // Pass the SurfaceView object to Agora so that it renders the local video.
        agoraEngine?.setupLocalVideo(
            VideoCanvas(
                localSurfaceView,
                VideoCanvas.RENDER_MODE_HIDDEN,
                0
            )
        )
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.videoBtn -> {
                val btn = v as ImageView
                if (btn.isSelected) {
                    btn.isSelected = false
                    btn.clearColorFilter()
                    btn.setImageResource(R.drawable.ic_video_cross_y)
                } else {
                    btn.isSelected = true
                    btn.setImageResource(R.drawable.ic_video_cross_y)

                }
                agoraEngine?.muteLocalVideoStream(btn.isSelected)
                if (btn.isSelected) {
//                    binding.localVideoView.visibility = View.GONE
                    binding.localVideoView.setBackgroundColor(R.color.localBackground)
                    binding.localVideoView.background =
                        ContextCompat.getDrawable(this, R.drawable.ic_video_cross_y)
                    btn.setImageResource(R.drawable.ic_video_cross_y)
                } else {
                    binding.localVideoView.visibility = View.VISIBLE
                    btn.setImageResource(R.drawable.videocamcolored)
                }

                val videoSurface = binding.localVideoView.getChildAt(0) as SurfaceView?
                videoSurface?.setZOrderMediaOverlay(!btn.isSelected)
                videoSurface?.visibility = if (btn.isSelected) View.GONE else View.VISIBLE
            }
            R.id.buttonCall->{
                CallEnd()
                binding.tvTime.visibility = View.GONE
                if (!isJoined) {
                    showMessage("Join a channel first")

                } else {
//                    finish()
                    stopSound()
//                    viewCallStatusApi()
                    agoraEngine?.leaveChannel()
                    showMessage("You left the channel")
                    // Stop remote video rendering.
                    if (remoteSurfaceView != null) remoteSurfaceView?.visibility = View.GONE
                    // Stop local video rendering.
                    if (localSurfaceView != null) localSurfaceView?.visibility = View.GONE
                    isJoined = false
                }
            }
            R.id.buttonMute -> {
                mMuted = !mMuted
                agoraEngine?.muteLocalAudioStream(mMuted)
                val res: Int = if (mMuted) {
                    R.drawable.ic_mute
                } else {
                    R.drawable.ic_unmute
                }

                binding.buttonMute.setImageResource(res)
                onRemoteUserVideoMuted(uid, mMuted)
            }
            R.id.buttonSwitchCamera-> {
                agoraEngine?.switchCamera()

            }
        }
    }
}