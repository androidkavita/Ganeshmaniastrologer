package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ConsultancyOrderResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<ConsultancyOrderResponseData> = arrayListOf()
)
data class ConsultancyOrderResponseData(
    @SerializedName("id"            ) var id           : Int?    = null,
    @SerializedName("booking_id"    ) var bookingId    : String? = null,
    @SerializedName("booking_date"  ) var bookingDate  : String? = null,
    @SerializedName("booking_time"  ) var bookingTime  : String? = null,
    @SerializedName("type"  ) var type  : Int? = null,
    @SerializedName("status"  ) var status  : Int? = null,
    @SerializedName("status_name"   ) var statusName   : String? = null,
    @SerializedName("astro_id"      ) var astro_id      : String? = null,
    @SerializedName("astro_name"    ) var astroName    : String? = null,
    @SerializedName("astro_package" ) var astroPackage : String? = null,
    @SerializedName("duration"      ) var duration     : String? = null,
    @SerializedName("price"         ) var price        : String? = null,
    @SerializedName("astro_iamge"   ) var astroIamge   : String? = null
)