package com.callastrouser.ui.activities

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.MyReviewsAdapter
import com.callastrouser.databinding.ActivityMyReviewBinding
import com.callastrouser.model.MyReviewsResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.ProfileViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MyReview : BaseActivity() {
    lateinit var binding: ActivityMyReviewBinding
    private val viewModel: ProfileViewModel by viewModels()
    lateinit var adapter: MyReviewsAdapter
    var List:ArrayList<MyReviewsResponseData> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_review)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_my_review)
        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "My Reviews"


        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.MyReviews(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }


        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.myreviewsResponse.observe(this) {
            if (it?.status == 1) {
                List.clear()
                List.addAll(it.data)
                adapter = MyReviewsAdapter(this,List)
                binding.rvMyReviews.adapter = adapter
            }else{
                snackbar(it.message.toString())
            }
        }




    }
}