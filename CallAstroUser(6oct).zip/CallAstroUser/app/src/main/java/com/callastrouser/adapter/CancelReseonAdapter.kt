package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowCancelReasonsBinding
import com.callastrouser.model.CancelReasonResponseData

class CancelReseonAdapter (val context : Context, var data: ArrayList<CancelReasonResponseData>, var Reason:CheckedReason) :
    RecyclerView.Adapter<CancelReseonAdapter.ViewHolder>() {
    private var selectedItemPosition: Int = 0
    lateinit var id:String
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowCancelReasonsBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CancelReseonAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_cancel_reasons, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: CancelReseonAdapter.ViewHolder, @SuppressLint("RecyclerView")position: Int) {
        val List = data[position]
        holder.binding.tvReason.text = List.reason

        holder.binding.tvReason.setOnClickListener {
            selectedItemPosition = position
            notifyDataSetChanged()


        }
        if(selectedItemPosition == position){
            holder.binding.tvReason.isChecked = true
            Reason.Reason(List.id.toString(),holder.binding.tvReason.text.toString())
//            holder.binding.category.setTextColor(Color.parseColor("#FFFFFF"))
//            holder.binding.category.setBackgroundResource(R.drawable.redbackgroundbutton)
        }else{
            holder.binding.tvReason.isChecked = false
//            Reason.Reason("","")
//            holder.binding.category.setTextColor(Color.parseColor("#530C0C"))
//            holder.binding.category.setBackgroundResource(R.drawable.white_background_round)
        }
//        holder.binding.specialist.text = List.experience.toString()
//        callchat.callchatLL(holder.binding.callLl,List.id.toString())
    }

    override fun getItemCount(): Int {
        return data.size
    }

}
interface CheckedReason{
    fun Reason(id: String,Reason:String)
}