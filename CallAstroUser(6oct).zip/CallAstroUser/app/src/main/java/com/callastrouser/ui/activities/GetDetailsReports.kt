package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.GetDetailsReportsAdapter
import com.callastrouser.adapter.GetDetsilsButton
import com.callastrouser.databinding.ActivityGetDetailsReportsBinding
import com.callastrouser.model.AstrologersListViewAllResponseData
import com.callastrouser.model.ChatFragmentResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.GetReportViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class GetDetailsReports : BaseActivity(), GetDetsilsButton {
    lateinit var binding: ActivityGetDetailsReportsBinding
    var Listdata: ArrayList<AstrologersListViewAllResponseData> = ArrayList()
    private val viewModel: GetReportViewModel by viewModels()
    lateinit var adapter: GetDetailsReportsAdapter
    var scpflag: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_get_details_reports)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_get_details_reports)
        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Get Details Report"



        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.get_report_astro_list(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.astrologerviewallResponse.observe(this){
            if (it.status == 1){
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = GetDetailsReportsAdapter(this,Listdata,this)
                binding.rvAstrologers.adapter = adapter
            }
        }
        binding.tvSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(text: Editable?) {
                filterData(text.toString(), scpflag)
            }

        })
    }
    private fun filterData(searchText: String, scpflag: String) {
        var filteredStateList: java.util.ArrayList<AstrologersListViewAllResponseData> = java.util.ArrayList()


//        if (scpflag.equals("State")) {
        for (item in Listdata) {
            try {
                if (item.name!!.toLowerCase().contains(searchText.toLowerCase())) {
                    filteredStateList.add(item)
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }


        try {
            adapter?.filterList(filteredStateList)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    override fun buttonclick(id:String,position: Int, detailsbutton: LinearLayoutCompat) {
        startActivity(Intent(this@GetDetailsReports,SelectReportType::class.java).putExtra("id",id))
    }
}