package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class MakeKundaliResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : MakeKundaliResponseData?   = MakeKundaliResponseData()
)

data class MakeKundaliResponseData(
    @SerializedName("boy_name"         ) var boyName        : String? = null,
    @SerializedName("boy_birth_date"   ) var boyBirthDate   : String? = null,
    @SerializedName("boy_birth_time"   ) var boyBirthTime   : String? = null,
    @SerializedName("boy_birth_place"  ) var boyBirthPlace  : String? = null,
    @SerializedName("girl_name"        ) var girlName       : String? = null,
    @SerializedName("girl_birth_date"  ) var girlBirthDate  : String? = null,
    @SerializedName("girl_birth_time"  ) var girlBirthTime  : String? = null,
    @SerializedName("girl_birth_place" ) var girlBirthPlace : String? = null
)
