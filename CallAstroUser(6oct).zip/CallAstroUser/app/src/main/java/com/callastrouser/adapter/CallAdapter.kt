package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowCallAstrologersBinding
import com.callastrouser.model.ChatFragmentResponseData
import com.maxtra.astrorahi.interfaces.CallChat
import com.maxtra.astrorahi.interfaces.VideoCallChat

class CallAdapter (val context : Context, var data: ArrayList<ChatFragmentResponseData>, var callchat: CallChat, var forvideo: VideoCallChat) :
    RecyclerView.Adapter<CallAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowCallAstrologersBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CallAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_call_astrologers, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: CallAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.name.toString()
        holder.binding.specialist.text = List.expertise.toString()
//        holder.binding.language.text = List.language.toString()
//        if (List.experience == ""){
//            holder.binding.experience.text = "Experience : 0 Years"
//        }else{
            holder.binding.experience.text = "Experience :"+List.experience.toString() + "Years"
//        }

        holder.binding.rating.text = List.astro_rating
        holder.binding.charge.text = "₹ ${List.calling_charge.toString()}/min"
        Glide.with(context).load(List.profileImage).into(holder.binding.photo)
        if (List.request!!.equals(7)){
            holder.binding.callLl.visibility = View.GONE
            holder.binding.videocallLl.visibility = View.GONE
            holder.binding.busy.text = "Online(Busy)"
            holder.binding.busy.setTextColor(Color.parseColor("#d32f2f"))
            holder.binding.ivDot.setImageResource(R.drawable.red_dot)
        }else{
            holder.binding.callLl.visibility = View.VISIBLE
            holder.binding.videocallLl.visibility = View.VISIBLE
            holder.binding.busy.text = "Online"
            holder.binding.busy.setTextColor(Color.parseColor("#145901"))
            holder.binding.ivDot.setImageResource(R.drawable.ic_dot)
        }
        callchat.callchatLL(holder.binding.callLl,List.id.toString(),List.name.toString(),holder.binding.linearItem)
        forvideo.VideocallchatLL(holder.binding.videocallLl,List.id.toString(),List.name.toString(),holder.binding.linearItem)
    }

    override fun getItemCount(): Int {
        return data.size
    }
    @SuppressLint("NotifyDataSetChanged")
    fun filterList(filteredStateList: ArrayList<ChatFragmentResponseData>) {
        data = filteredStateList
        notifyDataSetChanged()
    }
}