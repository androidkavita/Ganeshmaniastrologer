package com.callastrouser.ui.activities

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PorterDuff
import android.media.AudioManager
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.Log
import android.view.SurfaceView
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.doOnTextChanged
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.callastrouser.R
import com.callastrouser.databinding.ActivityAudioCallBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.Constant.Companion.ACTION_HANG_UP_ANSWERED_CALL
import com.callastrouser.viewModel.VideoCallViewModel
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import de.hdodenhof.circleimageview.CircleImageView
import io.agora.rtc2.*
import io.agora.rtc2.video.VideoCanvas
import java.text.DecimalFormat
import java.util.*

@AndroidEntryPoint
class AudioCallActivity : BaseActivity(), View.OnClickListener {
    private lateinit var binding: ActivityAudioCallBinding
    private val viewModel: VideoCallViewModel by viewModels()
    var user_id: String? = null
    var booking_id: String? = null
    var patient_image: String? = null
    var patient_number: String? = null
    var patient_name: String? = null
    var token: String? = null
    private var callTimer: Timer? = null
    private var callTimerText: TextView? = null
    private var counter = 0
    private val PERMISSION_REQ_ID = 22
    private val REQUESTED_PERMISSIONS = arrayOf(
        Manifest.permission.RECORD_AUDIO
    )
    lateinit var name :TextView
    lateinit var expertise :TextView
    lateinit var language :TextView
    lateinit var experience :TextView
    lateinit var image : CircleImageView
    lateinit var bottomdialog: BottomSheetDialog
    var astroname: String? = null
    var astroid: String? = null
    var caller_id: String? = null
    var profileimage: String? = null
    // An integer that identifies the local user.
    private val uid = 0
    private var mMuted = false
    // Track the status of your connection
    private var isJoined = false
    private var channelName: String? = ""

    private var WalletMoney: Int = 0
    private var CallingCharge: Int = 0
    private var Calculatetime: Int = 0
    private var Minimumbalence: Int = 0
    private lateinit var Fixthirtymin: String
    private lateinit var Fixsixtymin: String
    val handlerStatusCheck = Handler(Looper.getMainLooper())
    var runnableStatusCheck: Runnable? = null
    // Agora engine instance
    private var agoraEngine: RtcEngine? = null
    //    var firebasePushResponse: FirebasePushResponse? = null
    private fun checkSelfPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            REQUESTED_PERMISSIONS[0]
        ) == PackageManager.PERMISSION_GRANTED
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_audio_call)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_audio_call)
        callTimerText = findViewById(R.id.tvTime)
        if (intent != null){
            astroid = intent.getStringExtra("astroid").toString()
            astroname = intent.getStringExtra("astroname").toString()
//            channelName = intent.getStringExtra("channelName")
            channelName = intent.getStringExtra("channel_name")
            token = intent.getStringExtra("agoratoken")
            caller_id = intent.getStringExtra("caller_id")
            profileimage = intent.getStringExtra("profileimage")
        }
        // If all the permissions are granted, initialize the RtcEngine object and join a channel.
        if (!checkSelfPermission()) {
            ActivityCompat.requestPermissions(this, REQUESTED_PERMISSIONS, PERMISSION_REQ_ID)
        }

        binding.btnUnmute.setOnClickListener(this)
        setupVoiceSDKEngine()
        if (CommonUtils.isInternetAvailable(this@AudioCallActivity)) {
            CallStart()
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }
        viewModel.callStartResponse.observe(this){
            if (it.status == 1){
                WalletMoney = it.data?.wallet!!.toInt()
                CallingCharge = it.data?.callingCharg!!.toInt()
                Fixthirtymin = it.data?.fixed_session_30min_charge.toString()
                Fixsixtymin = it.data?.fixed_session_30min_charge.toString()
                Calculatetime = (WalletMoney/CallingCharge)*60
                Minimumbalence = CallingCharge*5
                if(WalletMoney < Minimumbalence){
                    Alertdialog()
                }else{
                    joinChannel(token.toString(),channelName.toString())
                }
            }
        }
        viewModel.astrorahiResponse.observe(this) {
            if (it.status == 1) {
                name.text = it.data?.name.toString()
                expertise.text = it.data?.expertise.toString()
                language.text = it.data?.language.toString()
                experience.text = "Exp: "+it.data?.experence.toString()
                Glide.with(this).load(it.data?.profile).into(image)
            }
        }
        binding.ivCallEnd.setOnClickListener(this)
        binding.tvName.text = astroname
        Glide.with(this).load(profileimage)
            .apply(RequestOptions.placeholderOf(droidninja.filepicker.R.drawable.image_placeholder))
            .apply(RequestOptions.errorOf(droidninja.filepicker.R.drawable.image_placeholder))
            .into(binding.ivProfileImage)

        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(11)
        /*  val hang_up = findViewById<FloatingActionButton>(R.id.activity_hang_up_button)
            hang_up.setOnClickListener {
                sendBroadcast(Intent(com.example.swastharakshak.utils.Constants.ACTION_HANG_UP_ANSWERED_CALL))
                finish()
            } */

        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                toast(this@AudioCallActivity,it.message.toString())
//                finish()
                Alertdialog1()
            }
        }

        viewModel.givereviewResponse.observe(this){
            if (it.status == 1){
                finish()
            }else{
                snackbar(it.message.toString())
            }
        }

        handlerStatusCheck.postDelayed(Runnable { //do something
            handlerStatusCheck.postDelayed(runnableStatusCheck!!, 5000)
            if (CommonUtils.isInternetAvailable(this@AudioCallActivity)) {
                viewModel.call_ring("Bearer "+userPref.getToken().toString(),astroid.toString(),userPref.getUserId().toString(),caller_id.toString())
            } else {
                Log.d("TAG", "onCreate: " + "else part")
                toast(this,"Please check internet connection.")
            }

        }.also { runnableStatusCheck = it }, 0)


        viewModel.callRingResponse.observe(this){
            if (it.status == 1){
                if (it.data?.ringStatus == 1){
                    finish()
                }
            }
        }
    }


    fun ReviewAndRating() {
        // on below line we are creating a new bottom sheet dialog.
        bottomdialog = BottomSheetDialog(this)
        // on below line we are inflating a layout file which we have created.
        val view = layoutInflater.inflate(R.layout.astro_review_and_rating, null)
        val metrics = DisplayMetrics()
        windowManager?.defaultDisplay?.getMetrics(metrics)
        bottomdialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomdialog.behavior.peekHeight = metrics.heightPixels

        name = view.findViewById(R.id.name)
        expertise = view.findViewById(R.id.expertise)
        language = view.findViewById(R.id.language)
        experience = view.findViewById(R.id.experience)
        image = view.findViewById(R.id.iv_image)
        var btnSubmit = view.findViewById<AppCompatButton>(R.id.btnSubmit)
        var rating_complete = view.findViewById<RatingBar>(R.id.rating_complete)
        var etReason = view.findViewById<EditText>(R.id.etReason)
        var cancel = view.findViewById<ImageView>(R.id.cancel)
//        name.text = user_name.toString()
//        charge.text = charges.toString()
//        time.text = times.toString()
//        Glide.with(requireContext()).load(profiles).into(image)

        if (CommonUtils.isInternetAvailable(this@AudioCallActivity)) {
            viewModel.strologer_details(
                "Bearer " + userPref.getToken().toString(),
                astroid.toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }


        cancel.setOnClickListener{
            bottomdialog.dismiss()
            finish()
        }

        btnSubmit.setOnClickListener{
            if (rating_complete.rating.toInt().equals(0)){
                toast(this@AudioCallActivity,"Please rate to our astrologer.")
            }else{
                if (CommonUtils.isInternetAvailable(this@AudioCallActivity)) {
                    viewModel.user_give_review(
                        "Bearer "+userPref.getToken().toString(),
                        astroid.toString(),rating_complete.rating.toString(),etReason.text.toString(),caller_id.toString(),"2"
                    )
                } else {
                    toast(this,"Please check internet connection.")
                }
            }
        }

        bottomdialog.setCancelable(false)

        // on below line we are setting
        // content view to our view.
        bottomdialog.setContentView(view)

        // on below line we are calling
        // a show method to display a dialog.
        bottomdialog.show()



    }

    fun showMessage(message: String?) {
        runOnUiThread {
            Toast.makeText(
                applicationContext,
                message,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun Alertdialog1(){
        val buinder = AlertDialog.Builder(this)
        buinder.setMessage("Call has been ended.")
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Call Ended!!")

        buinder.setPositiveButton("OK") { dialogInterface, which ->
//                        val intent = Intent(this, CreateOrder::class.java)
//                        intent.putExtra("POPUP_FLAG", "yes")
//                        startActivity(intent)
            ReviewAndRating()

        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }

    fun Alertdialog(){
        val buinder = AlertDialog.Builder(this)

        buinder.setMessage("Your wallet balance is Rs $WalletMoney. " +
                "Minimum balance required Rs $Minimumbalence " +
                "to connect Astrologer $astroname Recharge now with following balance")
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Recharge Now!!")

        buinder.setPositiveButton("OK") { dialogInterface, which ->
//                        val intent = Intent(this, CreateOrder::class.java)
//                        intent.putExtra("POPUP_FLAG", "yes")
//                        startActivity(intent)
            val intent = Intent(this, WalletActivity::class.java)
            intent.putExtra("POPUP_FLAG", "yes")
            startActivity(intent)
//            CallEnd()
//            finish()
        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(true)
        alertDialog.show()
    }
    private fun startCallTimer() {
//        if (counter< Calculatetime){
        callTimer?.scheduleAtFixedRate(object : TimerTask() {
            override fun run() {

                if (++counter == Calculatetime) counter =
                    0 // for the taluxi app a call must not be longer than 1h.
                val formatter = DecimalFormat("00")
                val timerText =
                    formatter.format((counter / 60).toLong()) + ":" + formatter.format((counter % 60).toLong())
                runOnUiThread {
                    if (counter == 0){
                        if (CommonUtils.isInternetAvailable(this@AudioCallActivity)) {
                            CallEnd()
                        } else {
                            Log.d("TAG", "onCreate: " + "else part")
                            toast(this@AudioCallActivity,"Please check internet connection.")
                        }
                        if (isJoined) {
//                    viewCallStatusApi()
                            showMessage("You left the channel")
                            agoraEngine?.leaveChannel()
                            finish()
                            isJoined = false
                            sendBroadcast(Intent(ACTION_HANG_UP_ANSWERED_CALL))
                        } else {
//                    showMessage("Join a channel first")
                        }
                    }else{
                        callTimerText?.text = timerText
                        binding.tvTime.text = timerText
                    }
                }
                Thread.sleep(1000);
            }
        }, 0, 1000)
//        }else{
//            snackbar("you don't have enough balence.")
//        }

    }

    fun onSwitchSpeakerphoneClicked(view: View) {
        val iv: ImageView = view as ImageView
        if (iv.isSelected) {
            iv.isSelected = false
            iv.clearColorFilter()
        } else {
            iv.isSelected = true
            iv.setColorFilter(resources.getColor(R.color.theme_purple), PorterDuff.Mode.MULTIPLY)
        }

        // Enables/Disables the audio playback route to the speakerphone.
        //
        // This method sets whether the audio is routed to the speakerphone or earpiece. After calling this method, the SDK returns the onAudioRouteChanged callback to indicate the changes.
        agoraEngine?.setEnableSpeakerphone(view.isSelected)
    }

    private fun setupVoiceSDKEngine() {
        try {
            val config = RtcEngineConfig()
            config.mContext = baseContext
            config.mAppId = getString(R.string.agoraapp_id)
            config.mEventHandler = mRtcEventHandler
            agoraEngine = RtcEngine.create(config)
        } catch (e: Exception) {
            throw RuntimeException("Check the error.")
        }
    }

    private var mRtcEventHandler: IRtcEngineEventHandler = object : IRtcEngineEventHandler() {
        // Listen for the remote user joining the channel.
        override fun onUserJoined(uid: Int, elapsed: Int) {
            runOnUiThread { binding.infoText.text = "Remote user joined: $uid" }
            callTimer = Timer()
            startCallTimer()
        }

        override fun onJoinChannelSuccess(channel: String, uid: Int, elapsed: Int) {
            // Successfully joined a channel
            isJoined = true
//            showMessage("Joined Channel $channel")
            runOnUiThread { binding.infoText.text = "Waiting for a remote user to join" }
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            // Listen for remote users leaving the channel
//            showMessage("Remote user offline $uid $reason")
            if (isJoined) runOnUiThread {
                binding.tvTime.visibility = View.GONE
                Alertdialog1()

            }
            CallEnd()
            agoraEngine?.leaveChannel()

//            finish()
        }

        override fun onLeaveChannel(stats: RtcStats) {
            // Listen for the local user leaving the channel
            runOnUiThread { binding.infoText.text = "Press the button to join a channel"
                binding.tvTime.visibility = View.GONE}
            isJoined = false
//            CallEnd()
//            finish()
            agoraEngine?.leaveChannel()


        }

        /**
         * Occurs when a remote user stops/resumes sending the audio stream.
         * The SDK triggers this callback when the remote user stops or resumes sending the audio stream by calling the muteLocalAudioStream method.
         *
         * @param uid ID of the remote user.
         * @param muted Whether the remote user's audio stream is muted/unmuted:
         *
         * true: Muted.
         * false: Unmuted.
         */
        override fun onUserMuteAudio(uid: Int, muted: Boolean) { // Tutorial Step 6
            runOnUiThread { onRemoteUserVoiceMuted(uid, muted) }
        }
    }

    private fun onRemoteUserVoiceMuted(uid: Int, muted: Boolean) {
//        showLongToast(
//            java.lang.String.format(
//                Locale.US, "user %d muted or unmuted %b",
//                uid and 0xFFFFFFFFL.toInt(), muted
//            )
//        )
    }

    fun showLongToast(msg: String?) {
        runOnUiThread { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    private fun joinChannel(token: String, channelName: String) {
        val options = ChannelMediaOptions()
        options.autoSubscribeAudio = true
        // Set both clients as the BROADCASTER.
        options.clientRoleType = io.agora.rtc2.Constants.CLIENT_ROLE_BROADCASTER
        // Set the channel profile as BROADCASTING.
        options.channelProfile = Constants.CHANNEL_PROFILE_LIVE_BROADCASTING

        // Join the channel with a temp token.
        // You need to specify the user ID yourself, and ensure that it is unique in the channel.
        agoraEngine?.joinChannel(token, channelName, uid, options)
    }

//    private fun viewIdentityDataResponse() {
//        viewModel.identityDataApi(
//            channelName.toString()
//            /*userPref.getChannelName().toString()*/
//        )?.observe(this) {
//            if (it.status == 1) {
//                if (it.data?.status?.equals(4) == true || it.data?.status?.equals(3) == true) {
//                    agoraEngine?.leaveChannel()
//                    finish()
//                } else {
//                    toast(it.message.toString())
//                }
//            } else {
//                toast(it.message.toString())
//            }
//        }
//
//    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.iv_CallEnd -> {
                CallEnd()
                if (isJoined) {
//                    viewCallStatusApi()
                    showMessage("You left the channel")
                    agoraEngine?.leaveChannel()
//                    finish()
                    isJoined = false
                    sendBroadcast(Intent(ACTION_HANG_UP_ANSWERED_CALL))
//                    ReviewAndRating()

                } else {
//                    showMessage("Join a channel first")
                }
            }
            R.id.btnUnmute ->{

                mMuted = !mMuted
                agoraEngine?.muteLocalAudioStream(mMuted)
                val res: Int = if (mMuted) {
                    R.drawable.ic_mute
                } else {
                    R.drawable.ic_unmute
                }
                binding.btnUnmute.setImageResource(res)
                onRemoteUserVoiceMuted(uid, mMuted)
            }
        }
    }

    private fun CallStart() {
        if (CommonUtils.isInternetAvailable(this@AudioCallActivity)) {
            viewModel.when_call_start(
                "Bearer "+userPref.getToken().toString(),
                astroid.toString()
                /* userPref.getChannelName().toString()*/
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this@AudioCallActivity,"Please check internet connection.")
        }


    }

    private fun CallEnd() {
        if (CommonUtils.isInternetAvailable(this@AudioCallActivity)) {
            viewModel.call_end(
                "Bearer "+userPref.getToken().toString(),
                callTimerText?.text.toString(),astroid.toString(),userPref.getUserId().toString(),caller_id.toString(),"2"
                /* userPref.getChannelName().toString()*/
            )
        } else {
            toast(this@AudioCallActivity,"Please check internet connection.")
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        CallEnd()
        if (isJoined) {
//                    viewCallStatusApi()
            showMessage("You left the channel")
            agoraEngine?.leaveChannel()
//                    finish()
            isJoined = false
            sendBroadcast(Intent(ACTION_HANG_UP_ANSWERED_CALL))
//                    ReviewAndRating()

        } else {
//                    showMessage("Join a channel first")
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        agoraEngine?.leaveChannel()
        callTimer?.cancel()
        // Destroy the engine in a sub-thread to avoid congestion
        Thread {
            RtcEngine.destroy()
            agoraEngine = null
        }.start()
    }
}