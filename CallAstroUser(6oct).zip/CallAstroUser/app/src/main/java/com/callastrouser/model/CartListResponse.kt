package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class CartListResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : CartListResponseData?   = CartListResponseData()
)
data class CartListResponseData(
    @SerializedName("product_list"      ) var productList     : ArrayList<ProductList> = arrayListOf(),
    @SerializedName("total_item"        ) var totalItem       : Int?                   = null,
    @SerializedName("total_item_amount" ) var totalItemAmount : Int?                   = null,
    @SerializedName("tax"               ) var tax             : Int?                   = null,
    @SerializedName("shipping_charg"    ) var shippingCharg   : Int?                   = null,
    @SerializedName("coupon_discount"   ) var couponDiscount  : Int?                   = null,
    @SerializedName("grand_total"       ) var grandTotal      : Int?                   = null,
    @SerializedName("delivery_address"  ) var deliveryAddress : DeliveryAddress?       = DeliveryAddress()
)

data class DeliveryAddress (
    @SerializedName("id"           ) var id          : Int?    = null,
    @SerializedName("user_id"      ) var userId      : Int?    = null,
    @SerializedName("address_type" ) var addressType : Int?    = null,
    @SerializedName("full_name"    ) var fullName    : String? = null,
    @SerializedName("phone_no"     ) var phoneNo     : String? = null,
    @SerializedName("house_no"     ) var houseNo     : String? = null,
    @SerializedName("area"         ) var area        : String? = null,
    @SerializedName("state"        ) var state       : Int?    = null,
    @SerializedName("city"         ) var city        : Int?    = null,
    @SerializedName("pincode"      ) var pincode     : String? = null,
    @SerializedName("is_deleted"   ) var isDeleted   : Int?    = null,
    @SerializedName("created_at"   ) var createdAt   : String? = null,
    @SerializedName("updated_at"   ) var updatedAt   : String? = null

)

data class ProductList (
    @SerializedName("cart_id"    ) var cart_id    : Int?    = null,
    @SerializedName("product_id"    ) var productId    : Int?    = null,
    @SerializedName("qty"           ) var qty          : Int?    = null,
    @SerializedName("product_name"  ) var productName  : String? = null,
    @SerializedName("price"         ) var price        : String?    = null,
    @SerializedName("hsn_code"         ) var hsn_code        : String?    = null,
    @SerializedName("total_price"         ) var total_price        : Int?    = null,
    @SerializedName("product_image" ) var productImage : String? = null

)