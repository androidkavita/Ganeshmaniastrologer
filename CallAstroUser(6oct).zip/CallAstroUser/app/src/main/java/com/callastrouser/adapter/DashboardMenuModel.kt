package com.callastrouser.adapter

data class DashboardMenuModel(val title: String, val icon: Int){


}

