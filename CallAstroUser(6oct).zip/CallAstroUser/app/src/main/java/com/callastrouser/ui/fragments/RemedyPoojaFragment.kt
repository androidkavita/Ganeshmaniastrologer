package com.callastrouser.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.RemedyPoojaAdapter
import com.callastrouser.databinding.FragmentRemedyPoojaBinding
import com.callastrouser.model.RemedyPoojaResponseData
import com.callastrouser.viewModel.RemedyViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class RemedyPoojaFragment : BaseFragment() {
    lateinit var binding: FragmentRemedyPoojaBinding
    var List :ArrayList<RemedyPoojaResponseData> = arrayListOf()
    private val viewModel: RemedyViewModel by viewModels()
    lateinit var adapter: RemedyPoojaAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentRemedyPoojaBinding.inflate(inflater,container,false)

        viewModel.get_puja_list("Bearer "+userPref.getToken().toString())

        viewModel.remedyPoojaResponse.observe(viewLifecycleOwner){
            if (it.status == 1){
                List.clear()
                List.addAll(it.data)
                adapter = RemedyPoojaAdapter(requireContext(),List)
                binding.rvAstrologers.adapter = adapter
            }
        }

        return binding.root
    }
}