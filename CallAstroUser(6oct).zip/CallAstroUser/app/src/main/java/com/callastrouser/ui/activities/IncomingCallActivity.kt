package com.callastrouser.ui.activities

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.widget.AppCompatImageView
import androidx.databinding.DataBindingUtil
import com.airbnb.lottie.LottieAnimationView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.callastrouser.R
import com.callastrouser.databinding.ActivityGiveReviewProductBinding
import com.callastrouser.databinding.ActivityIncomingCallBinding
import com.callastrouser.util.Constant
import com.callastrouser.util.FullScreenActivity
import com.callastrouser.viewModel.VideoCallViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import hilt_aggregated_deps._com_callastrouser_ui_activities_BookingDetailsActivity_GeneratedInjector

@AndroidEntryPoint
class IncomingCallActivity : BaseActivity() {
    lateinit var binding: ActivityIncomingCallBinding
    var channelName: String? = null
    var doctorName: String? = null
    var doctorImage: String? = null
    var agoratoken: String? = null
    var caller_id: String? = null
    var type: String? = null
    var profileimage: String? = null
    var astroid: String? = null
    var astroname: String? = null
    var unique_id: String? = null
    var mMediaPlayer: MediaPlayer? = null
    var vib: Vibrator? = null
    private val viewModel: VideoCallViewModel by viewModels()
    val handlerStatusCheck = Handler(Looper.getMainLooper())
    val handlerStatusCheck1 = Handler(Looper.getMainLooper())
    var runnableStatusCheck: Runnable? = null
    var runnableStatusCheck1: Runnable? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_incoming_call)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_incoming_call)

        channelName = intent.getStringExtra("channel_name")
        astroname = intent.getStringExtra("astroname")
        astroid = intent.getStringExtra("astroid")
        agoratoken = intent.getStringExtra("agoratoken")
        caller_id = intent.getStringExtra("caller_id")
        type = intent.getStringExtra("type")
        profileimage = intent.getStringExtra("profileimage")
        unique_id = intent.getStringExtra("unique_id")


        Glide.with(this@IncomingCallActivity).load(profileimage).into(binding.activityCallerPhoto)
        binding.callerName.text = astroname

        playSound()

        var activity_answer_call_button = findViewById<LottieAnimationView>(R.id.activity_answer_call_button)
        var activity_hang_up_button = findViewById<LottieAnimationView>(R.id.activity_hang_up_button)
        activity_answer_call_button.initLoader(true)
        activity_hang_up_button.initLoader(true)
        findViewById<LottieAnimationView>(R.id.activity_answer_call_button).setOnClickListener {
            if (type == "1") {
                viewModel.call_received("Bearer "+userPref.getToken().toString(),unique_id.toString())
                val intent = Intent(this, AudioCallActivity::class.java)
                intent.putExtra("channel_name", channelName)
                intent.putExtra("astroname", astroname)
                intent.putExtra("astroid", astroid)
                intent.putExtra("caller_id", caller_id)
                intent.putExtra("agoratoken", agoratoken)
                intent.putExtra("profileimage",profileimage)
                startActivity(intent)
                stopSound()
                finish()
            } else {
                viewModel.call_received("Bearer "+userPref.getToken().toString(),unique_id.toString())
                val intent = Intent(this, VideoActivity::class.java)
                intent.putExtra("channel_name", channelName)
                intent.putExtra("astroname", astroname)
                intent.putExtra("astroid", astroid)
                intent.putExtra("caller_id", caller_id)
                intent.putExtra("agoratoken", agoratoken)
                intent.putExtra("profileimage",profileimage)
                startActivity(intent)
                stopSound()
                finish()
            }

        }

        viewModel.commonResponse.observe(this){
            if (it.status == 1){

            }else{

            }
        }

        findViewById<TextView>(R.id.caller_name).text = astroname
        Glide.with(this).load(profileimage)
            .apply(RequestOptions.placeholderOf(R.drawable.logo))
            .apply(RequestOptions.errorOf(R.drawable.logo))
            .into(findViewById<AppCompatImageView>(R.id.activity_caller_photo))
        findViewById<LottieAnimationView>(R.id.activity_hang_up_button).setOnClickListener {

            sendBroadcast(Intent(Constant.ACTION_HANG_UP_INCOMING_CALL))
//            finish()
            stopSound()
            viewModel.call_ring_end("Bearer "+userPref.getToken().toString(),channelName.toString())
            startActivity(Intent(this@IncomingCallActivity,CallCancelRequestActivity::class.java))

        }

        handlerStatusCheck.postDelayed(Runnable { //do something
            viewModel.call_ring_status_save("Bearer "+userPref.getToken().toString(),channelName.toString())
            handlerStatusCheck.postDelayed(runnableStatusCheck!!, 10 * 200)
        }.also { runnableStatusCheck = it }, 200)
        viewModel.call_ring_status_save_Response.observe(this){
            if (it.status == 1 ){
                if (it.data?.status == 0){
                    stopSound()
                    finish()
                }

            }
        }
        handlerStatusCheck1.postDelayed(Runnable { //do something
            viewModel.call_ring("Bearer "+userPref.getToken().toString(),astroid.toString(),userPref.getUserId().toString(),unique_id.toString())
            handlerStatusCheck1.postDelayed(runnableStatusCheck1!!, 5000)
        }.also { runnableStatusCheck1 = it }, 0)
        viewModel.callRingResponse.observe(this){
            if (it.status == 1){
                if (it.data?.ringStatus == 1){
                    stopSound()
                    finish()
                }
            }
        }
        viewModel.commonResponse.observe(this){
            if (it.status == 1 ){

            }
        }
    }
    fun LottieAnimationView.initLoader(isLoading: Boolean) {
        if (isLoading) {
            playAnimation()
            visibility = View.VISIBLE
        } else {
            pauseAnimation()
            animation?.reset()
            visibility = View.GONE
        }
    }
    fun playSound() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager

        when (am.ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> Log.i("MyApp", "Silent mode")
            AudioManager.RINGER_MODE_VIBRATE -> {

                vib = this.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vib?.vibrate(5000)

                Log.i("MyApp", "Vibrate mode")
            }
            AudioManager.RINGER_MODE_NORMAL -> {
                val manager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                manager.setStreamVolume(AudioManager.STREAM_MUSIC, 10, 0)
                val notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                mMediaPlayer = MediaPlayer.create(applicationContext, notification)
                if (manager.ringerMode != AudioManager.RINGER_MODE_SILENT)
                    mMediaPlayer?.isLooping = true
                mMediaPlayer?.start()
                Log.i("MyApp", "Normal mode")
            }
        }
    }

    fun stopSound() {
        if (mMediaPlayer != null) {
            vib = this.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            mMediaPlayer!!.stop()
            vib!!.cancel()
            mMediaPlayer!!.release()
            mMediaPlayer = null
        }
    }
}