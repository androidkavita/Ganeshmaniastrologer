package com.callastrouser.util

import com.callastrouser.BuildConfig

interface  Constant {
    companion object {

        var check: Int = 0

        //Local server url


        val IS_NOTIFICATION = "is_notification"
        var cartcount:Int? = 0
        var isItem:Boolean? = false
        var cartAmount:String? = ""
        var cartCurrency:String? = ""
        const val MY_PREFERENCES = "prefs"


        val ACTION_HANG_UP_INCOMING_CALL =
            BuildConfig.APPLICATION_ID + "ACTION_HANG_UP_INCOMING_CALL"
        val ACTION_HANG_UP_ANSWERED_CALL =
            BuildConfig.APPLICATION_ID + "ACTION_HANG_UP_ANSWERED_CALL"
    }
}