package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class UserAstroConnectStatusResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : UserAstroConnectStatusResponseData?   = UserAstroConnectStatusResponseData()
)
data class UserAstroConnectStatusResponseData(
    @SerializedName("id"           ) var id          : Int?    = null,
    @SerializedName("user_id"      ) var userId      : Int?    = null,
    @SerializedName("astro_id"     ) var astroId     : Int?    = null,
    @SerializedName("channel_name" ) var channelName : String? = null,
    @SerializedName("status"       ) var status      : Int?    = null,
    @SerializedName("created_at"   ) var createdAt   : String? = null,
    @SerializedName("updated_at"   ) var updatedAt   : String? = null
)