package com.callastrouser.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.CallHistoryAdapter
import com.callastrouser.databinding.FragmentCallHistoryBinding
import com.callastrouser.model.CallHistoryResponseData
import com.callastrouser.ui.activities.IntakeMatchMakingFormActivity
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.DashboardHistoryWalletViewModel
import com.maxtra.astrorahi.interfaces.CallVideo
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CallHistoryFragment : BaseFragment(), CallVideo {
    lateinit var binding: FragmentCallHistoryBinding
    private val viewModel: DashboardHistoryWalletViewModel by viewModels()
    lateinit var adapter: CallHistoryAdapter
    var List:ArrayList<CallHistoryResponseData> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentCallHistoryBinding.inflate(inflater,container,false)


        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.history_call(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }


        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.historyCallResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                List.clear()
                List.addAll(it.data)
                adapter = CallHistoryAdapter(requireContext(), List,this)
                binding.rvwallethistory.adapter = adapter
            } else {
                toast(it.message.toString())
//                snackbar(it?.message!!)
            }

        }
        return binding.root
    }

    override fun callchatLL(linear: ImageView, id: String, type: String) {
        linear.setOnClickListener {
            startActivity(Intent(requireContext(), IntakeMatchMakingFormActivity::class.java).putExtra("id",id).putExtra("request_type",type))
        }
    }
}