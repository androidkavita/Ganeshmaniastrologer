package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class PlanetsResponse(
    val input: Input,
    val output: ArrayList<Output>,
    val statusCode: Int
)

data class Input(
    val date: Int,
    val hours: Int,
    val latitude: Double,
    val longitude: Double,
    val minutes: Int,
    val month: Int,
    val seconds: Int,
    val settings: Settings,
    val timezone: Double,
    val year: Int
)

data class Output(
    val `0`: X0,
    val `1`: X0,
    val `10`: X0,
    val `11`: X0,
    val `12`: X0,
    val `13`: X13,
    val `2`: X0,
    val `3`: X0,
    val `4`: X0,
    val `5`: X0,
    val `6`: X0,
    val `7`: X0,
    val `8`: X0,
    val `9`: X0,
    val Ascendant: Ascendant,
    val Jupiter: Jupiter,
    val Ketu: Ketu,
    val Mars: Mars,
    val Mercury: Mercury,
    val Moon: Moon,
    val Neptune: Neptune,
    val Pluto: Pluto,
    val Rahu: Rahu,
    val Saturn: Saturn,
    val Sun: Sun,
    val Uranus: Uranus,
    val Venus: Venus,
    val debug: Debug
)

data class Settings(
    val ayanamsha: String,
    val observation_point: String
)

data class X0(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val name: String,
    val normDegree: Double
)

data class X13(
    val name: String,
    val value: Double
)

data class Ascendant(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Jupiter(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Ketu(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Mars(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Mercury(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Moon(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Neptune(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Pluto(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Rahu(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Saturn(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Sun(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Uranus(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Venus(
    val current_sign: Int,
    val fullDegree: Double,
    val isRetro: String,
    val normDegree: Double
)

data class Debug(
    val ayanamsa: String,
    val observation_point: String
)