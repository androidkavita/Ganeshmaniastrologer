package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class CallStartResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : CallStartResponseData?   = CallStartResponseData()
)
data class CallStartResponseData(
    @SerializedName("wallet"        ) var wallet       : String? = null,
    @SerializedName("calling_charg" ) var callingCharg : String? = null,
    @SerializedName("fixed_session_30min_charge" ) var fixed_session_30min_charge : String? = null,
    @SerializedName("fixed_session_60min_charge" ) var fixed_session_60min_charge : String? = null,
)
