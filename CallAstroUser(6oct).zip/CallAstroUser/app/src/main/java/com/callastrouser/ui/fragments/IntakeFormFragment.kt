package com.callastrouser.ui.fragments

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TimePicker
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.MainActivity
import com.callastrouser.R
import com.callastrouser.databinding.FragmentIntakeFormBinding
import com.callastrouser.model.CityListData
import com.callastrouser.model.GetAstroSlotsResponseData
import com.callastrouser.model.LanguageResponseData
import com.callastrouser.model.MaritalStatusListData
import com.callastrouser.model.StateListData
import com.callastrouser.ui.activities.WalletActivity
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.DateFormat
import com.callastrouser.viewModel.IntakeViewModel
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import dagger.hilt.android.AndroidEntryPoint
import java.util.*

@AndroidEntryPoint
class IntakeFormFragment : BaseFragment() {
    private val viewModel: IntakeViewModel by viewModels()
    lateinit var binding: FragmentIntakeFormBinding
    var ListLanguagedata: ArrayList<LanguageResponseData> = ArrayList()
    var languagenamedata :ArrayList<String> = arrayListOf()
    var idlanguagedata :ArrayList<String> = arrayListOf()
    var selectedLanguageId= ""
    var selectedLanguagename= ""
    lateinit var astro_id:String
    lateinit var request_type:String
    private var WalletMoney: Int = 0
    private var CallingCharge: Int = 0
    private var Calculatetime: Int = 0
    private var Minimumbalence: Int = 0
    var astroname: String? = null

    var statedata :ArrayList<StateListData> = arrayListOf()
    var statenamedata :ArrayList<String> = arrayListOf()
    var idstatedata :ArrayList<String> = arrayListOf()
    lateinit var minimumbalence:String
    var citydata :ArrayList<CityListData> = arrayListOf()
    var citynamedata :ArrayList<String> = arrayListOf()
    var idcitydata :ArrayList<String> = arrayListOf()
    var selectedStateId= ""
    var gender: String = "1"
    var maritaldata :ArrayList<MaritalStatusListData> = arrayListOf()
    var maritalnamedata :ArrayList<String> = arrayListOf()
    var idmaritaldata :ArrayList<String> = arrayListOf()
    var selectedMaritalId= ""
    lateinit var fix:String
    lateinit var sessiontype:String
    lateinit var selectedCityId :String

    var placesClient: PlacesClient? = null
    private val AUTOCOMPLETE_PLACE_REQUEST_CODE = 4
    var latLng: LatLng? = null
    var pickupLongitude = 0.0
    var pickupLatitude = 0.0
    var dropLongitude = 0.0
    var dropLatitude = 0.0
    var sourceLatLong: LatLng? = null
    var destLatLong: LatLng? = null
    var distance: Double? = null
    var distanceString: String? = null


    var ListAstroslotdata: ArrayList<GetAstroSlotsResponseData> = ArrayList()
    var Astroslotdata :ArrayList<String> = arrayListOf()
    var idAstroslotdata :ArrayList<String> = arrayListOf()
    var selectedAstroslotId= ""
    var selectedAstroslotname= ""

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentIntakeFormBinding.inflate(inflater,container,false)

        if (requireArguments().getString("id") != null) {
            astro_id = requireArguments().getString("id").toString()
            fix = requireArguments().getString("fix").toString()
            sessiontype = requireArguments().getString("sessiontype").toString()
            request_type = requireArguments().getString("request_type").toString()
            minimumbalence = requireArguments().getString("minimumbalence").toString()
        }


        val apiKey = getString(R.string.api_key)
        if (!Places.isInitialized()) {
            Places.initialize(requireContext(), apiKey)
        }

        placesClient = Places.createClient(requireContext())
        binding.etPlace.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_PLACE_REQUEST_CODE)
        }

        if (CommonUtils.isInternetAvailable(requireContext())) {
            CallStart()
//            StateAPI()
            LanguageAPI()
            MaritalAPI()
//            chooseDataPickerForfix()
        } else {
            toast("Please check internet connection.")
        }
//        binding.State.onItemSelectedListener = object :
//            AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
//                selectedStateId=idstatedata[p2]
//                CityAPI()
//            }
//            override fun onNothingSelected(p0: AdapterView<*>?) {
//
//            }
//        }
//        binding.city.onItemSelectedListener = object :
//            AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
//                selectedCityId=idcitydata[p2]
//            }
//            override fun onNothingSelected(p0: AdapterView<*>?) {
//
//            }
//        }

        binding.radio1.setOnClickListener {
            if (binding.radio1.isChecked == true) {
                gender = "1"
            }
        }
        binding.radio2.setOnClickListener {
            if (binding.radio2.isChecked == true) {
                gender = "2"
            }
        }
        binding.radio3.setOnClickListener {
            if (binding.radio2.isChecked == true) {
                gender = "3"
            }
        }
        binding.etMaritalstatus.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedMaritalId=idmaritaldata[p2]
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }

        binding.etslotstime.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedAstroslotId=idAstroslotdata[p2]
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }

        binding.etDob.setOnClickListener{
            chooseDataPicker()
        }

        binding.dateofslots.setOnClickListener {
            chooseDataPickerForfix()
        }


        binding.etTime.setOnClickListener {
            Selecttime()
        }


        binding.etLanguagestatus.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedLanguageId=idlanguagedata[p2]
                selectedLanguagename=languagenamedata[p2]
//                if (expertisenamedata.contains(expertisenamedata[p2])){
//                    toast("Already Selected")
//                }else{
//                languageaddData.add(selectedLanguagename)
//                }
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

//        viewModel.callStartResponse.observe(viewLifecycleOwner){
//            if (it.status == 1){
//                WalletMoney = it.data?.wallet!!.toInt()
//                CallingCharge = it.data?.callingCharg!!.toInt()
//                Calculatetime = (WalletMoney/CallingCharge)*60
//                Minimumbalence = CallingCharge*5
//                if(WalletMoney < Minimumbalence){
//                    Alertdialog()
//                }else{
//                    binding.btnSubmit.setOnClickListener {
//                        viewModel.add_user_details_first(
//                            "Bearer "+userPref.getToken().toString(),
//                            binding.etName.text.toString(),
//                            binding.etDob.text.toString(),
//                            binding.etTime.text.toString()+":00",
//                            binding.etPlace.text.toString(),
//                            binding.etOccupation.text.toString(),
//                            selectedMaritalId,
//                            binding.etConsultationtopic.text.toString(),
//                            selectedLanguageId,
//                            astro_id,
//                            request_type,
//                            selectedStateId,
//                            selectedCityId,
//                            gender,
//                        )
//                    }
//
//                }
//            }
//        }

        viewModel.callStartResponse.observe(viewLifecycleOwner){

            if (it.status == 1){
                if (fix == "FIX"){
                    binding.slots.visibility = View.VISIBLE
                    WalletMoney = it.data?.wallet!!.toInt()
                    CallingCharge = it.data?.callingCharg!!.toInt()

                    if (sessiontype == "1"){
                        Calculatetime = 1800000
//                        Minimumbalence = 2000
                        if(WalletMoney < minimumbalence.toInt()){
                            AlertdialogFixed()
                        }else{
                            binding.btnSubmit.setOnClickListener {
                                if (binding.etName.text.isNullOrEmpty()){
                                    toast("Please enter name")
                                }else if (binding.etDob.text.isNullOrEmpty()){
                                    toast("Please enter date of birth.")
                                }else if(binding.etTime.text.isNullOrEmpty()){
                                    toast("Please enter time of birth.")
                                }else if (binding.etPlace.text.isNullOrEmpty()){
                                    toast("Please enter place of birth.")
                                }else {
                                    if (CommonUtils.isInternetAvailable(requireContext())) {
                                        viewModel.add_user_details_first(
                                            "Bearer " + userPref.getToken().toString(),
                                            binding.etName.text.toString(),
                                            binding.etDob.text.toString(),
                                            binding.etTime.text.toString() + ":00",
                                            binding.etPlace.text.toString(),
                                            binding.etOccupation.text.toString(),
                                            selectedMaritalId,
                                            binding.etConsultationtopic.text.toString(),
                                            selectedLanguageId,
                                            astro_id,
                                            request_type,
//                                    selectedStateId,
//                                    selectedCityId,
                                            gender,
                                            "FIX",
                                            "1",
                                            binding.dateofslots.text.toString(),
                                            selectedAstroslotId.toString()
                                        )
                                    } else {
                                        Log.d("TAG", "onCreate: " + "else part")
                                        toast("Please check internet connection.")
                                    }
                                }
                            }

                        }
                    }else if(sessiontype == "2"){
                        Calculatetime = 3600000
//                        Minimumbalence = CallingCharge*5
                        if(WalletMoney < minimumbalence.toInt()){
                            AlertdialogFixed()
                        }else{
                            binding.btnSubmit.setOnClickListener {
                                if (binding.etName.text.isNullOrEmpty()){
                                    toast("Please enter name")
                                }else if (binding.etDob.text.isNullOrEmpty()){
                                    toast("Please enter date of birth.")
                                }else if(binding.etTime.text.isNullOrEmpty()){
                                    toast("Please enter time of birth.")
                                }else if (binding.etPlace.text.isNullOrEmpty()){
                                    toast("Please enter place of birth.")
                                }else {

                                    if (CommonUtils.isInternetAvailable(requireContext())) {
                                        viewModel.add_user_details_first(
                                            "Bearer " + userPref.getToken().toString(),
                                            binding.etName.text.toString(),
                                            binding.etDob.text.toString(),
                                            binding.etTime.text.toString() + ":00",
                                            binding.etPlace.text.toString(),
                                            binding.etOccupation.text.toString(),
                                            selectedMaritalId,
                                            binding.etConsultationtopic.text.toString(),
                                            selectedLanguageId,
                                            astro_id,
                                            request_type,
//                                    selectedStateId,
//                                    selectedCityId,
                                            gender,
                                            "FIX",
                                            "2",
                                            binding.dateofslots.text.toString(),
                                            selectedAstroslotId.toString()
                                        )
                                    } else {
                                        Log.d("TAG", "onCreate: " + "else part")
                                        toast("Please check internet connection.")
                                    }
                                }
                            }
                        }
                    }
                }else{
                    WalletMoney = it.data?.wallet!!.toInt()
                    CallingCharge = it.data?.callingCharg!!.toInt()
                    try{
                    Calculatetime = (WalletMoney/CallingCharge)*60
                    Minimumbalence = CallingCharge*5
                    }catch (e:ArithmeticException){
                        e.printStackTrace()
                    }
                    if(WalletMoney < Minimumbalence){
                        Alertdialog()
                    }else{
                        binding.btnSubmit.setOnClickListener {
                            if (binding.etName.text.isNullOrEmpty()){
                                toast("Please enter name")
                            }else if (binding.etDob.text.isNullOrEmpty()){
                                toast("Please enter date of birth.")
                            }else if(binding.etTime.text.isNullOrEmpty()){
                                toast("Please enter time of birth.")
                            }else if (binding.etPlace.text.isNullOrEmpty()){
                                toast("Please enter place of birth.")
                            }else {
                                if (CommonUtils.isInternetAvailable(requireContext())) {
                                    viewModel.add_user_details_first(
                                        "Bearer " + userPref.getToken().toString(),
                                        binding.etName.text.toString(),
                                        binding.etDob.text.toString(),
                                        binding.etTime.text.toString() + ":00",
                                        binding.etPlace.text.toString(),
                                        binding.etOccupation.text.toString(),
                                        selectedMaritalId,
                                        binding.etConsultationtopic.text.toString(),
                                        selectedLanguageId,
                                        astro_id,
                                        request_type,
//                                selectedStateId,
//                                selectedCityId,
                                        gender,
                                        "Nofix", "","",""
                                    )
                                } else {
                                    Log.d("TAG", "onCreate: " + "else part")
                                    toast("Please check internet connection.")
                                }


                            }
                        }
                    }
                }
            }
        }

        viewModel.intakeResponse.observe(viewLifecycleOwner){
            if (it.status == 1){
                var intent = Intent(requireContext(), MainActivity::class.java)
                    .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
//                fragmentManager?.popBackStack()
                Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
            }else{
                toast(it.message.toString())
            }
        }

        viewModel.getIntakeResponse.observe(viewLifecycleOwner){
            if (it.status == 1){
                binding.etName.setText(it.data?.name.toString())
                binding.etDob.setText(it.data?.dob.toString())
                binding.etTime.setText(it.data?.birthTime.toString())
                binding.etPlace.setText(it.data?.birthPlace.toString())
//                binding.etOccupation.setText(it.data?.occupation.toString())
//                binding.etMaritalstatus.setText(it.data?.maritialStatus.toString())
//                binding.etConsultationtopic.setText(it.data?.topicConsultation.toString())
            }
        }

        viewModel.get_intake_report("Bearer "+userPref.getToken().toString())

        return binding.root
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("TAG", "@@onActivityResult:")
        if (requestCode == AUTOCOMPLETE_PLACE_REQUEST_CODE) {
            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    pickupLongitude = latLng!!.longitude
                    pickupLatitude = latLng!!.latitude

//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLAT,
//                        pickupLatitude.toString()
//                    )
//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLNG,
//                        pickupLongitude.toString()
//                    )

                    binding.etPlace.text = place.address
                    sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
                    Log.e("@@pickupLatitude", pickupLatitude.toString())
                }
                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                }
            }
            return
        }
    }
    private fun placesAPiCall(requestCode: Int) {
        val fields = listOf(
            Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS,
            Place.Field.LAT_LNG
        )
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
            .build(requireContext())
        startActivityForResult(intent, requestCode)
    }
    private fun AlertdialogFixed(){
        val buinder = AlertDialog.Builder(requireContext())

        buinder.setMessage("Your wallet balance is Rs $WalletMoney. " +
                "Minimum balance required Rs $minimumbalence " +
                "to connect Astrologer $astroname Recharge now with following balance")
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Recharge Now!!")

        buinder.setPositiveButton("Yes") { dialogInterface, which ->


            var intent = Intent(requireContext(),WalletActivity::class.java)
//                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
    fun MaritalAPI(){
        viewModel.maritials_list("Bearer "+userPref.getToken().toString()).observe(viewLifecycleOwner) {
            if (it!!.status == 1) {
                maritaldata.clear()
                maritalnamedata.clear()
                maritaldata.addAll(it!!.data)
                viewModel.maritalResponseData.value = it.data
                for (i in 0 until it.data.size) {
                    maritalnamedata.add(it.data[i].name.toString())
                    idmaritaldata.add(it.data[i].id.toString())
                }
                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
                    requireContext(),
                    android.R.layout.simple_spinner_dropdown_item,
                    maritalnamedata
                )
                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.etMaritalstatus.adapter = spinnerArrayAdapter

            }
        }
    }

    fun GetAstroSlot(){
        viewModel.get_astro_slot(
            "Bearer "+userPref.getToken().toString(),
            binding.dateofslots.text.toString(),astro_id
        ).observe(viewLifecycleOwner) {
            if (it!!.status == 1) {
                ListAstroslotdata.clear()
                Astroslotdata.clear()
                ListAstroslotdata.addAll(it!!.data)
                viewModel.timesloteResponseData.value = it.data
                for (i in 0 until it.data.size) {
                    Astroslotdata.add(it.data[i].timeAvail.toString())
                    idAstroslotdata.add(it.data[i].id.toString())
                }
                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
                    requireContext(),
                    android.R.layout.simple_spinner_dropdown_item,
                    Astroslotdata
                )
                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.etslotstime.adapter = spinnerArrayAdapter
            }
        }
    }
//    fun StateAPI(){
//        viewModel.StateListAPI().observe(viewLifecycleOwner) {
//            if (it!!.status == 1) {
//                statedata.clear()
//                statenamedata.clear()
//                statedata.addAll(it!!.data)
//                viewModel.stateListData.value = it.data
//                for (i in 0 until it.data.size) {
//                    statenamedata.add(it.data[i].stateName.toString())
//                    idstatedata.add(it.data[i].id.toString())
//                }
//                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
//                    requireContext(),
//                    android.R.layout.simple_spinner_dropdown_item,
//                    statenamedata
//                )
//                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                binding.State.adapter = spinnerArrayAdapter
//
//            }
//        }
//    }
//    fun CityAPI(){
//        viewModel.CityListAPI(
//            selectedStateId.toInt()
//        ).observe(viewLifecycleOwner) {
//            if (it!!.status == 1) {
//                citydata.clear()
//                citynamedata.clear()
//                citydata.addAll(it!!.data)
//                viewModel.citylistData.value = it.data
//                for (i in 0 until it.data.size) {
//                    citynamedata.add(it.data[i].cityName.toString())
//                    idcitydata.add(it.data[i].id.toString())
//                }
//                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
//                    requireContext(),
//                    android.R.layout.simple_spinner_dropdown_item,
//                    citynamedata
//                )
//                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                binding.city.adapter = spinnerArrayAdapter
//            }
//        }
//    }
    fun Alertdialog(){
        val buinder = AlertDialog.Builder(requireContext())

        buinder.setMessage("Your wallet balance is Rs $WalletMoney. " +
                "Minimum balance required Rs $Minimumbalence " +
                "to connect Astrologer $astroname Recharge now with following balance")
        buinder.setIcon(R.drawable.alert)
        buinder.setTitle("Recharge Now!!")

        buinder.setPositiveButton("Yes") { dialogInterface, which ->
//                        val intent = Intent(this, CreateOrder::class.java)
//                        intent.putExtra("POPUP_FLAG", "yes")
//                        startActivity(intent)
//            CallEnd()
//            finish()
//            fragmentManager?.popBackStack()

            var intent = Intent(requireContext(),WalletActivity::class.java)
//                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
        val alertDialog: AlertDialog = buinder.create()
        alertDialog.setCancelable(false)
        alertDialog.show()
    }
    private fun CallStart() {
        viewModel.when_call_start(
            "Bearer "+userPref.getToken().toString(),
            astro_id.toString()
            /* userPref.getChannelName().toString()*/
        )
    }
    fun LanguageAPI(){
        viewModel.Language(
            "Bearer "+userPref.getToken().toString()
        ).observe(viewLifecycleOwner) {
            if (it!!.status == 1) {
                ListLanguagedata.clear()
                languagenamedata.clear()
                ListLanguagedata.addAll(it!!.data)
                viewModel.languageResponseData.value = it.data
                    for (i in 1 until it.data.size) {
                        languagenamedata.add(it.data[i].language.toString())
                        idlanguagedata.add(it.data[i].id.toString())
                    }

                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
                    requireContext(),
                    android.R.layout.simple_spinner_dropdown_item,
                    languagenamedata
                )
                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.etLanguagestatus.adapter = spinnerArrayAdapter
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun chooseDataPicker() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            requireContext(), R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                binding.etDob.text =
                    DateFormat.addServiceDealsDate(simpleDateFormat.format(cal.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
//        datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun chooseDataPickerForfix() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            requireContext(), R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                binding.dateofslots.text =
                    DateFormat.addServiceDealsDate(simpleDateFormat.format(cal.time))
                GetAstroSlot()

            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
//        datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }

    fun Selecttime() {
        val mTimePicker: TimePickerDialog
        val mcurrentTime = Calendar.getInstance()
        val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
        val minute = mcurrentTime.get(Calendar.MINUTE)

        mTimePicker = TimePickerDialog(
            requireContext(),
            R.style.MyTimePickerTheme,
            object : TimePickerDialog.OnTimeSetListener {
                override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                    if (hourOfDay < 10) {
                        if (minute <10){
                            binding.etTime.setText(String.format("0%d:0%d",hourOfDay,minute))
                        }else{
                            binding.etTime.setText(String.format("0%d:%d",hourOfDay,minute))
                        }

                    } else {
                        if (minute <10){
                            binding.etTime.setText(String.format("%d:0%d",hourOfDay,minute))
                        }else{
                            binding.etTime.setText(String.format("%d:%d",hourOfDay,minute))
                        }
                    }
                }
            },
            hour,
            minute,
            false
        )
        mTimePicker.show()
    }
}