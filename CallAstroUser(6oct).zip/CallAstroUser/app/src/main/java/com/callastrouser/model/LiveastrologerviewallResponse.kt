package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class LiveastrologerviewallResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<LiveastrologerviewallResponseData> = arrayListOf()
)
data class LiveastrologerviewallResponseData(
    @SerializedName("id"      ) var id      : Int?    = null,
    @SerializedName("name"    ) var name    : String? = null,
    @SerializedName("topic"    ) var topic    : String? = null,
    @SerializedName("profile" ) var profile : String? = null,
    @SerializedName("agora_token" ) var agora_token : String? = null,
    @SerializedName("channel_name" ) var channel_name : String? = null,
    @SerializedName("calling_charg" ) var calling_charg : String? = null,
)