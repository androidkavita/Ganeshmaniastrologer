package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.BookingDetailsResponse
import com.callastrouser.model.CancelReasonResponse
import com.callastrouser.model.CartListResponse
import com.callastrouser.model.CartPlaceOrderResponse
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.ConsultancyDetail
import com.callastrouser.model.ConsultancyOrderResponse
import com.callastrouser.model.GiveReviewResponse
import com.callastrouser.model.MyCartResponse
import com.callastrouser.model.MyOrdersEcommersProductResponse
import com.callastrouser.model.PlaceOrderResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OrderDetailsViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    val myCartResponse = MutableLiveData<MyCartResponse>()
    val cartListResponse = MutableLiveData<CartListResponse>()
    val cartPlaceOrderResponse = MutableLiveData<CartPlaceOrderResponse>()
    val placeorderResponse = MutableLiveData<PlaceOrderResponse>()
    val myorderResponse = MutableLiveData<MyOrdersEcommersProductResponse>()
    val bookingResponse = MutableLiveData<BookingDetailsResponse>()
    val consultancyOrderResponse = MutableLiveData<ConsultancyOrderResponse>()
    val cancelReasonResponse = MutableLiveData<CancelReasonResponse>()
    val commonResponse = MutableLiveData<CommonResponse>()
    val consultancydetailResponse = MutableLiveData<ConsultancyDetail>()
    val givereviewResponse = MutableLiveData<GiveReviewResponse>()


    fun OrderDetail(
        token: String,
        product_id:String,
        address_id:String,
        type: String,
        coupon_code: String,

    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.OrderDetails(token,product_id,address_id,type,coupon_code)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                myCartResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun cart_lists(
        token: String,
        coupon_code:String,
        address_id:String

    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.cart_lists(token,coupon_code,address_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                cartListResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun delete_cart(
        token: String,
        cart_id: String

    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.delete_cart(token,cart_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }



    fun add_to_cart(
        token: String,
        product_id: String,
        type: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.add_to_cart(token,product_id,type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }


    }


    fun help(
        token: String,
        astro_id:String,
        message:String,
        booking_id: String

    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.help(token,astro_id,message,booking_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun cart_place_order(
        token: String,
        address_id:String,
        payment_status:String,
        payment_type:String,
        transaction_id:String,
        orderfrom: String,
        product_id: String,
        coupon_discount: String,
        qty: String


    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.cart_place_order(token,address_id,payment_status,payment_type,transaction_id,orderfrom,product_id,coupon_discount,qty)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                cartPlaceOrderResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }
    fun OrderPlace(
        token: String,
        product_id: String,
        product_price: String,
        shipping_chard: String,
        coupon_discount: String,
        grand_total: String,
        coupon_code: String,
        address_id: String,
        qty: String,
        transaction_id: String,
        payment_status: String,
        payment_type: String,

    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.OrderPlaced(token, product_id, product_price, shipping_chard, coupon_discount,
                    grand_total, coupon_code, address_id, qty, transaction_id, payment_status, payment_type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                placeorderResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun OrderDetail(
        token: String,
        type:String,


    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.my_orders(token,type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                myorderResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun BookingDetail(
        token: String,
        order_id:String,
        product_id: String,

        ) {
        progressBarStatus.value = true
        viewModelScope.launch {
//            try {
            val response =
                mainRepository.booking_detail(token,order_id,product_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                bookingResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
//            }catch (e:Exception){
//                e.printStackTrace()
//            }
        }
    }


    fun consultancy_order(
        token: String,

    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.consultancy_order(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                consultancyOrderResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun reason_cancel_list(
        token: String,

        ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.reason_cancel_list(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                cancelReasonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun cancel_order(
        token: String,
        order_id: String,
        id: String,
        reason_ids: String
        ,write_reason: String

        ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.cancel_order(token,order_id,id,reason_ids,write_reason)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun consultancy_order_detail(
        token: String,
        booking_id: String,
        ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            try {
            val response =
                mainRepository.consultancy_order_detail(token,booking_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                consultancydetailResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
    }

    fun user_give_review(
        token: String,
        astro_id: String,
        rating: String,
        review: String,
        ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.user_give_review(token,astro_id,rating,review,"","")
            if (response.isSuccessful) {
                progressBarStatus.value = false
                givereviewResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


}