package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowShopwithusSeeallBinding
import com.callastrouser.model.ShopwithusViewallResponseData

class ShopwithUsViewallAdapter (val context : Context, var data: ArrayList<ShopwithusViewallResponseData>, var transfer:Shop) :
    RecyclerView.Adapter<ShopwithUsViewallAdapter.ViewHolder>() {
    var id :String = ""
    var name :String = ""
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowShopwithusSeeallBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShopwithUsViewallAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_shopwithus_seeall, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ShopwithUsViewallAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.itemname.text = List.categoryName
        id = List.id.toString()
        name = List.categoryName.toString()
        Glide.with(context).load(List.categoryImage).into(holder.binding.rvImgs)
        transfer.layoutid(holder.binding.wholelayout,id,name)




    }

    override fun getItemCount(): Int {
        return data.size
    }

    interface Shop{
        fun layoutid(layout:LinearLayout,id:String,name:String)
    }

}