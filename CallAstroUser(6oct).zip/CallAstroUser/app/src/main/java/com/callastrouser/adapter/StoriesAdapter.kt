package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowstoriesBinding
import com.callastrouser.model.Blogs
import com.callastrouser.model.LiveStrologers

class StoriesAdapter (val context : Context, var data: ArrayList<Blogs>, var click: ClickMe) :
    RecyclerView.Adapter<StoriesAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowstoriesBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.rowstories, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.title
        Glide.with(context).load(List.image).into(holder.binding.rvImgs)
//        click.Click(holder.binding.linearItem,List.id.toString(),List.channel_name.toString(),List.agora_token.toString())
        click.layoutclick(holder.binding.linearItem,List.id.toString())
//        holder.binding.linearItem.setOnClickListener(View.OnClickListener {
//            val intent = Intent(context, DriverDetailActivity::class.java)
//            intent.putExtra("orderType", "4")
//            intent.putExtra("id",List.id)
//            context.startActivity(intent)
//        })
    }

    override fun getItemCount(): Int {
        return data.size
    }


}
interface ClickMe{
    fun layoutclick(linear: LinearLayout, id:String)
}