package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class BookingDetailsResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<BookingDetailsResponseData> = arrayListOf(),
    @SerializedName("details" ) var details : Details?        = Details()
)
data class BookingDetailsResponseData(
    @SerializedName("id"               ) var id              : Int?    = null,
    @SerializedName("order_id"         ) var orderId         : String? = null,
    @SerializedName("user_id"          ) var userId          : Int?    = null,
    @SerializedName("product_id"       ) var productId       : Int?    = null,
    @SerializedName("product_price"    ) var productPrice    : String? = null,
    @SerializedName("qty"              ) var qty             : String? = null,
    @SerializedName("status"           ) var status          : String?    = null,
    @SerializedName("choose_reason"    ) var chooseReason    : String? = null,
    @SerializedName("write_reason"     ) var writeReason     : String? = null,
    @SerializedName("created_at"       ) var createdAt       : String? = null,
    @SerializedName("updated_at"       ) var updatedAt       : String? = null,
    @SerializedName("address_id"       ) var addressId       : Int?    = null,
    @SerializedName("shipping_charg"   ) var shippingCharg   : String? = null,
    @SerializedName("coupon_discount"  ) var couponDiscount  : String? = null,
    @SerializedName("grand_total"      ) var grandTotal      : String? = null,
    @SerializedName("order_date"       ) var orderDate       : String? = null,
    @SerializedName("tax"              ) var tax             : String? = null,
    @SerializedName("main_image"       ) var mainImage       : String? = null,
    @SerializedName("name"             ) var name            : String? = null,
    @SerializedName("delivery_address" ) var deliveryAddress : String? = null,
    @SerializedName("expact_delivery"  ) var expactDelivery  : String? = null,
    @SerializedName("gst"              ) var gst             : String? = null,
    @SerializedName("product_price1"   ) var productPrice1   : Int?    = null
)
data class Details (

    @SerializedName("grand_total"      ) var grandTotal      : String? = null,
    @SerializedName("shipping_charg"   ) var shippingCharg   : String? = null,
    @SerializedName("product_price"    ) var productPrice    : Int?    = null,
    @SerializedName("coupon_discount"  ) var couponDiscount  : String? = null,
    @SerializedName("tax"              ) var tax             : String? = null,
    @SerializedName("booking_id"       ) var bookingId       : String? = null,
    @SerializedName("order_date"       ) var orderDate       : String? = null,
    @SerializedName("expact_delivery"  ) var expactDelivery  : String? = null,
    @SerializedName("delivery_address" ) var deliveryAddress : String? = null,
    @SerializedName("status"           ) var status          : Int?    = null

)