package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class AgoraCreateUserResponse (
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : AgoraCreateUserData?   = AgoraCreateUserData()
)

data class AgoraCreateUserEntities (
    @SerializedName("uuid"      ) var uuid      : String?  = null,
    @SerializedName("type"      ) var type      : String?  = null,
    @SerializedName("created"   ) var created   : Int?     = null,
    @SerializedName("modified"  ) var modified  : Int?     = null,
    @SerializedName("username"  ) var username  : String?  = null,
    @SerializedName("activated" ) var activated : Boolean? = null,
    @SerializedName("nickname"  ) var nickname  : String?  = null
)

data class AgoraCreateUserData (
    @SerializedName("path"            ) var path            : String?             = null,
    @SerializedName("uri"             ) var uri             : String?             = null,
    @SerializedName("timestamp"       ) var timestamp       : Long?               = null,
    @SerializedName("organization"    ) var organization    : String?             = null,
    @SerializedName("application"     ) var application     : String?             = null,
    @SerializedName("entities"        ) var entities        : ArrayList<AgoraCreateUserEntities> = arrayListOf(),
    @SerializedName("action"          ) var action          : String?             = null,
    @SerializedName("data"            ) var data            : ArrayList<String>   = arrayListOf(),
    @SerializedName("duration"        ) var duration        : Int?                = null,
    @SerializedName("applicationName" ) var applicationName : String?             = null
)