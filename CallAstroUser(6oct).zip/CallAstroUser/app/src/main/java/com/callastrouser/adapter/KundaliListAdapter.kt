package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowRecentlyOpenedListBinding
import com.callastrouser.model.AstrologersListViewAllResponseData
import com.callastrouser.model.RecentSeeKundliResponseData
import com.callastrouser.ui.activities.Kundali

class KundaliListAdapter (val context : Context, var data: ArrayList<RecentSeeKundliResponseData>/*, var click: LiveAstro*/) :
    RecyclerView.Adapter<KundaliListAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowRecentlyOpenedListBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_recently_opened_list, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.name.text = List.name
        holder.binding.datetime.text = List.dob+","+List.time_of_birth
        holder.binding.place.text = List.birthplace
        holder.binding.groom.visibility = View.GONE
        holder.binding.bride.visibility = View.GONE
        holder.binding.girldetail.visibility = View.GONE
//        holder.binding.place.text = List.
//        Glide.with(context).load(R.drawable.logo2).into(holder.binding.image)
//        click.Click(holder.binding.liveastro,List.id.toString(),List.channel_name.toString(),List.agora_token.toString())
        holder.binding.linearItem.setOnClickListener(View.OnClickListener {
            context.startActivity(
                Intent(context, Kundali::class.java)
                .putExtra("boydob",List.dob)
                .putExtra("boytob",List.time_of_birth)
                .putExtra("picklat",List.latitude.toDouble())
                .putExtra("picklong",List.longitude.toDouble())
            )
        })
    }

    override fun getItemCount(): Int {
        return data.size
    }
    @SuppressLint("NotifyDataSetChanged")
    fun filterList(filteredStateList: ArrayList<RecentSeeKundliResponseData>) {
        data = filteredStateList
        notifyDataSetChanged()
    }
}