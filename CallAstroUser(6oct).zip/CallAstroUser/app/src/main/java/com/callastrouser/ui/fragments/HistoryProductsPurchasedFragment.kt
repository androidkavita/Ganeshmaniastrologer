package com.callastrouser.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.HistoryProductPurchasedAdapter
import com.callastrouser.adapter.ShopsHistoryPurchased
import com.callastrouser.databinding.FragmentHistoryProductsPurchasedBinding
import com.callastrouser.model.HistoryProductSuggestedData
import com.callastrouser.ui.activities.ShopWithUsItemDetails
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.DashboardHistoryWalletViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HistoryProductsPurchasedFragment : BaseFragment(), ShopsHistoryPurchased {
    lateinit var binding: FragmentHistoryProductsPurchasedBinding
    lateinit var adapter : HistoryProductPurchasedAdapter
    private val viewModel: DashboardHistoryWalletViewModel by viewModels()
    var List :ArrayList<HistoryProductSuggestedData> = arrayListOf()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentHistoryProductsPurchasedBinding.inflate(inflater,container,false)

        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.history_products("Bearer "+userPref.getToken().toString(),"2")
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.historyProductSuggestedResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                List.clear()
                List.addAll(it.data)
                adapter = HistoryProductPurchasedAdapter(requireContext(), List,this)
                binding.rvPurchasedProducts.adapter = adapter
            } else {
                toast(it.message.toString())
//                snackbar(it?.message!!)
            }
        }


        return binding.root
    }

    override fun onResume() {
        super.onResume()
        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.history_products("Bearer "+userPref.getToken().toString(),"2")
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

    }

    override fun onStart() {
        super.onStart()
        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.history_products("Bearer "+userPref.getToken().toString(),"2")
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

    }

    override fun layoutid(layout: LinearLayout, id: String, name: String) {
        layout.setOnClickListener {
            var intent = Intent(requireContext(), ShopWithUsItemDetails::class.java)
            intent.putExtra("id",id)
            intent.putExtra("name",name)
            startActivity(intent)
        }
    }
}
