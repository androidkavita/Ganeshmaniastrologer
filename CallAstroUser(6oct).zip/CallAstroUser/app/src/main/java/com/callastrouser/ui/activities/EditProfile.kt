package com.callastrouser.ui.activities

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.CursorLoader
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TimePicker
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.FileProvider
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.callastrouser.R
import com.callastrouser.databinding.ActivityEditProfileBinding
import com.callastrouser.model.CityListData
import com.callastrouser.model.StateListData
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.DateFormat
import com.callastrouser.viewModel.ProfileViewModel
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class EditProfile : BaseActivity() {
    lateinit var binding: ActivityEditProfileBinding
    private val viewModel: ProfileViewModel by viewModels()
    var imageFile: MultipartBody.Part? = null
    private val pickImageCamera = 1
    private val pickImageGallery = 2
    lateinit var currentPhotoPath: String
    var mPhotoFile: File? = null
    var photoURICamera: Uri?=null
    var flag:Boolean = false
//
//    var statedata :ArrayList<StateListData> = arrayListOf()
//    var statenamedata :ArrayList<String> = arrayListOf()
//    var idstatedata :ArrayList<String> = arrayListOf()
//
//    var citydata :ArrayList<CityListData> = arrayListOf()
//    var citynamedata :ArrayList<String> = arrayListOf()
//    var idcitydata :ArrayList<String> = arrayListOf()
//    var selectedStateId= ""
//    lateinit var selectedCityId :String
    var placesClient: PlacesClient? = null
    private val AUTOCOMPLETE_PLACE_REQUEST_CODE = 3
    var latLng: LatLng? = null
    var pickupLongitude = 0.0
    var pickupLatitude = 0.0
    var dropLongitude = 0.0
    var dropLatitude = 0.0
    var sourceLatLong: LatLng? = null
    var destLatLong: LatLng? = null
    var distance: Double? = null
    var distanceString: String? = null
    var gender: String = "1"
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_edit_profile)

        binding.ivPict.setOnClickListener {
            selectImage()
        }
        binding.ivCamera.setOnClickListener {
            selectImage()
        }
        binding.backArrow.setOnClickListener {
            finish()
        }
        binding.tvDateOfBirth.setOnClickListener {
            chooseDataPicker()
        }
        binding.birthtime.setOnClickListener {
            Selecttime()
        }
        binding.radio1.setOnClickListener {
            if (binding.radio1.isChecked == true) {
                gender = "1"
            }
        }
        binding.radio2.setOnClickListener {
            if (binding.radio2.isChecked == true) {
                gender = "2"
            }
        }
        binding.radio3.setOnClickListener {
            if (binding.radio3.isChecked == true) {
                gender = "3"
            }
        }

        val apiKey = getString(R.string.api_key)
        if (!Places.isInitialized()) {
            Places.initialize(this, apiKey)
        }

        placesClient = Places.createClient(this)
        binding.address.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_PLACE_REQUEST_CODE)
        }

//        binding.State.onItemSelectedListener = object :
//            AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
//                selectedStateId=idstatedata[p2]
//                CityAPI()
//            }
//            override fun onNothingSelected(p0: AdapterView<*>?) {
//
//            }
//        }
//        binding.city.onItemSelectedListener = object :
//            AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
//                selectedCityId=idcitydata[p2]
//            }
//            override fun onNothingSelected(p0: AdapterView<*>?) {
//
//            }
//        }
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.ViewProfile(
                "Bearer "+userPref.getToken().toString()
            )
//            StateAPI()
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.viewProfileResponse.observe(this) {
            if (it?.status == 1) {
                binding.tvFullName.setText(it.data?.name.toString())
                binding.tvmobile.setText(it.data?.mobileNo.toString())
                binding.tvEmailid.setText(it.data?.email.toString())
                binding.address.setText(it.data?.birthPlace.toString())
                binding.tvDateOfBirth.text = it.data?.dob.toString()
                binding.birthtime.text = it.data?.birthTime.toString()
                Glide.with(this@EditProfile).load(it.data?.profile).apply(RequestOptions.placeholderOf(droidninja.filepicker.R.drawable.image_placeholder)).into(binding.ivPict)
                if (it.data?.gender == 1){
                    binding.radio1.isChecked = true
                    gender = "1"
                }else if (it.data?.gender == 2){
                    binding.radio2.isChecked = true
                    gender = "2"
                }else if (it.data?.gender == 3){
                    binding.radio3.isChecked = true
                    gender = "3"
                }
            }else{
                snackbar(it.message.toString())
            }
        }


        binding.updateProfile.setOnClickListener {
            if (binding.tvFullName.text.toString().isNullOrEmpty()){
                snackbar("Please enter name.")
            }else if (binding.tvmobile.text.toString().isNullOrEmpty()){
                snackbar("Please enter Mobile.")
            }else if (binding.tvEmailid.text.toString().isNullOrEmpty()){
                snackbar("Please enter email.")
            }else if (binding.tvEmailid.text.toString() == "" || !binding.tvEmailid.text.toString().trim().matches(emailPattern.toRegex())){
                snackbar("Please enter valid email.")
            }else if (binding.tvDateOfBirth.text.toString().isNullOrEmpty()){
                snackbar("Please select date ot birth.")
            }else if (binding.birthtime.text.toString().isNullOrEmpty()){
                snackbar("Please select time ot birth.")
            }else if (binding.address.text.toString().isNullOrEmpty()){
                snackbar("Please enter address.")
            }else {
                if (imageFile == null) {
                    val requestFile = RequestBody.create(MediaType.parse("image/jpg"), "")
                    imageFile = MultipartBody.Part.createFormData("profile_image", "", requestFile)
                }
                if (CommonUtils.isInternetAvailable(this)) {
                    viewModel.EditProfile(
                        "Bearer "+userPref.getToken().toString(),
                        binding.tvFullName.text.toString(),
                        binding.tvmobile.text.toString(),
                        binding.tvEmailid.text.toString(),
                        binding.tvDateOfBirth.text.toString(),
                        binding.address.text.toString(),
                        binding.birthtime.text.toString(),
                        gender,
//                    selectedStateId.toString(),
//                    selectedCityId,
                        imageFile!!
                    )
                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this,"Please check internet connection.")
                }

            }
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.commonResponse.observe(this) {
            if (it?.status == 1) {
                finish()
            }else{
                snackbar(it.message.toString())
            }
        }
    }

//    fun StateAPI(){
//        viewModel.StateListAPI().observe(this) {
//            if (it!!.status == 1) {
//                statedata.clear()
//                statenamedata.clear()
//                statedata.addAll(it!!.data)
//                viewModel.stateListData.value = it.data
//                for (i in 0 until it.data.size) {
//                    statenamedata.add(it.data[i].stateName.toString())
//                    idstatedata.add(it.data[i].id.toString())
//                }
//                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
//                    this,
//                    android.R.layout.simple_spinner_dropdown_item,
//                    statenamedata
//                )
//                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                binding.State.adapter = spinnerArrayAdapter
//
//            }
//        }
//    }
//    fun CityAPI(){
//        viewModel.CityListAPI(
//            selectedStateId.toInt()
//        ).observe(this) {
//            if (it!!.status == 1) {
//                citydata.clear()
//                citynamedata.clear()
//                citydata.addAll(it!!.data)
//                viewModel.citylistData.value = it.data
//                for (i in 0 until it.data.size) {
//                    citynamedata.add(it.data[i].cityName.toString())
//                    idcitydata.add(it.data[i].id.toString())
//                }
//                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
//                    this,
//                    android.R.layout.simple_spinner_dropdown_item,
//                    citynamedata
//                )
//                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                binding.city.adapter = spinnerArrayAdapter
//            }
//        }
//    }
    fun Selecttime() {
        val mTimePicker: TimePickerDialog
        val mcurrentTime = Calendar.getInstance()
        val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
        val minute = mcurrentTime.get(Calendar.MINUTE)

        mTimePicker = TimePickerDialog(
            this,
            R.style.MyTimePickerTheme,
            object : TimePickerDialog.OnTimeSetListener {
                override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                    if (minute < 10) {
                        binding.birthtime.setText(String.format("%d:0%d", hourOfDay, minute))
                    } else {
                        binding.birthtime.setText(String.format("%d:%d", hourOfDay, minute))

                    }
                }
            },
            hour,
            minute,
            false
        )
        mTimePicker.show()
    }
    @RequiresApi(Build.VERSION_CODES.N)
    private fun chooseDataPicker() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = android.icu.text.SimpleDateFormat("dd-MM-yyyy")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            this,R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                binding.tvDateOfBirth.text = DateFormat.addServiceDealsDate(simpleDateFormat.format(cal.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }

    private fun selectImage() {
        val options = arrayOf<CharSequence>("Take Photo", "Choose From Gallery", "Cancel")
        val pm: PackageManager = packageManager
        val builder =
            android.app.AlertDialog.Builder(this, R.style.AlertDialogTheme)
        builder.setTitle("Select Option")
        builder.setItems(
            options
        ) { dialog: DialogInterface, item: Int ->
            if (options[item] == "Take Photo") {
                dialog.dismiss()
                requestStoragePermission(true)
            } else if (options[item] == "Choose From Gallery") {
                dialog.dismiss()
                requestStoragePermission(false)
            } else if (options[item] == "Cancel") {
                dialog.dismiss()
            }
        }
        builder.show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImageCamera) {
            binding.ivPict.setImageURI(photoURICamera)
            val file = File(currentPhotoPath)
            val requestFile = RequestBody.create(MediaType.parse("image/jpg"), file)
            imageFile = MultipartBody.Part.createFormData("profile", file.name, requestFile)
            flag = true
            binding.ivPict.setImageURI(photoURICamera)
            Glide.with(this)
                .load(currentPhotoPath)
                .error(droidninja.filepicker.R.drawable.image_placeholder)
                .into(binding.ivPict)
//            placeOrderApi("2")
        } else if (requestCode == pickImageGallery && data != null) {
            val selectedImage = data.data
            try {
                binding.ivPict.setImageURI(selectedImage)
                val file = File(getPath(selectedImage!!))
                val requestFile = RequestBody.create(MediaType.parse("image/jpg"), file)
                imageFile = MultipartBody.Part.createFormData("profile", file.name, requestFile)
                flag = true
                binding.ivPict.setImageURI(photoURICamera)
                Glide.with(this)
                    .load(selectedImage)
                    .error(droidninja.filepicker.R.drawable.image_placeholder)
                    .into(binding.ivPict)
//                placeOrderApi("2")
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }else  if (requestCode == AUTOCOMPLETE_PLACE_REQUEST_CODE) {
            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    pickupLongitude = latLng!!.longitude
                    pickupLatitude = latLng!!.latitude

//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLAT,
//                        pickupLatitude.toString()
//                    )
//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLNG,
//                        pickupLongitude.toString()
//                    )

                    binding.address.text = place.address
                    sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
                    Log.e("@@pickupLatitude", pickupLatitude.toString())
                }
                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                }
            }
            return
        }
    }

    @SuppressLint("SimpleDateFormat")
    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            // Save a file: path for use with ACTION_VIEW intents
            currentPhotoPath = absolutePath
        }
    }

    private fun openCamera() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {

                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {


                    null
                }

                photoFile?.also {
                    val photoURI: Uri =
                        FileProvider.getUriForFile(
                            this,
                            "com.callastrouser.myUniquefileprovider",
                            it
                        )
                    mPhotoFile = photoFile
                    photoURICamera = photoURI
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, pickImageCamera)
                }
            }
        }

    }

    private fun getPath(uri: Uri): String {
        val data = arrayOf(MediaStore.Images.Media.DATA)
        val loader =
            CursorLoader(this, uri, data, null, null, null)
        val cursor = loader.loadInBackground()
        val column_index = cursor!!.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
        cursor.moveToFirst()
        Log.d("image path", cursor.getString(column_index))
        return cursor.getString(column_index)
    }

    private fun requestStoragePermission(isCamera: Boolean) {
        Dexter.withActivity(this)
            .withPermissions(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport) {
                    // check if all permissions are granted
                    if (report.areAllPermissionsGranted()) {
                        if (isCamera) {
                            openCamera()
                        } else {
                            openGallery()
                        }
                    }
                    // check for permanent denial of any permission
                    if (report.isAnyPermissionPermanentlyDenied) {
                        // show alert dialog navigating to Settings
                        showSettingsDialog()
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<com.karumi.dexter.listener.PermissionRequest>?,
                    token: PermissionToken?
                ) {
                    token!!.continuePermissionRequest()
                }
            })
            .withErrorListener { error ->

            }
            .onSameThread()
            .check()
    }

    private fun openGallery() {
        val pickPhoto =
            Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(pickPhoto, pickImageGallery)
    }

    private fun showSettingsDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Need Permissions")
        builder.setMessage(
            "This app needs permission to use this feature. You can grant them in app settings."
        )
        builder.setPositiveButton(
            "GOTO SETTINGS"
        ) { dialog: DialogInterface, which: Int ->
            openSettings()
            dialog.cancel()
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog: DialogInterface, which: Int -> dialog.cancel() }
        builder.show()
    }

    private fun openSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        val uri = Uri.fromParts("package", "com.maxtra.astrorahi", null)
        intent.data = uri
        startActivityForResult(intent, 101)
    }


    private fun placesAPiCall(requestCode: Int) {
        val fields = listOf(
            Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS,
            Place.Field.LAT_LNG
        )
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
            .build(this)
        startActivityForResult(intent, requestCode)
    }
//    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        if (requestCode == AUTOCOMPLETE_PLACE_REQUEST_CODE) {
//            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
//                Activity.RESULT_OK -> {
//                    val place = Autocomplete.getPlaceFromIntent(data!!)
//                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
//                    latLng = place.latLng
//                    pickupLongitude = latLng!!.longitude
//                    pickupLatitude = latLng!!.latitude
//
////                    SavedPrefManager.saveStringPreferences(
////                        this,SavedPrefManager.PICLAT,
////                        pickupLatitude.toString()
////                    )
////                    SavedPrefManager.saveStringPreferences(
////                        this,SavedPrefManager.PICLNG,
////                        pickupLongitude.toString()
////                    )
//
//                    binding.placeofbirth.text = place.name
//                    sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
//                    Log.e("@@pickupLatitude", pickupLatitude.toString())
//                }
//                AutocompleteActivity.RESULT_ERROR -> {
//                    val status = Autocomplete.getStatusFromIntent(data!!)
//                    Log.i("TAG", status.statusMessage!!)
//                }
//                Activity.RESULT_CANCELED -> {
//                }
//            }
//            return
//        }
//        super.onActivityResult(requestCode, resultCode, data)
//    }
}