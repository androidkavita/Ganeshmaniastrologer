package com.callastrouser.ui.activities

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TimePicker
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.databinding.ActivityEnterKundaliDetailsBinding
import com.callastrouser.databinding.ActivityKundaliBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.DateFormat
import com.callastrouser.viewModel.KundaliViewModel
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import java.util.Calendar
import java.util.TimeZone

@AndroidEntryPoint
class EnterKundaliDetails : BaseActivity() {
    lateinit var binding: ActivityEnterKundaliDetailsBinding
    lateinit var boydob:String
    lateinit var boytob:String
    lateinit var boybirthplace:String
    lateinit var Time:String
    var picklat = 0.0
    var sourceLatLong: LatLng? = null
    var picklong = 0.0
    var placesClient: PlacesClient? = null
    val viewModel : KundaliViewModel by viewModels()
    var pickupLongitude = 0.0
    var pickupLatitude = 0.0
    var latLng: LatLng? = null
    private val AUTOCOMPLETE_PLACE_BOY_REQUEST_CODE = 1
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enter_kundali_details)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_enter_kundali_details)
        val apiKey = getString(R.string.api_key)
        if (!Places.isInitialized()) {
            Places.initialize(this, apiKey)
        }
        placesClient = Places.createClient(this)
        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Lagna Kundli"

        if (intent != null){
            boydob = intent.getStringExtra("boydob").toString()
            boytob = intent.getStringExtra("boytob").toString()
            boybirthplace = intent.getStringExtra("boybirthplace").toString()
            picklat = intent.getDoubleExtra("picklat",0.0)
            picklong = intent.getDoubleExtra("picklong",0.0)
        }
        binding.etBoyBirthplace.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_PLACE_BOY_REQUEST_CODE)
        }

        binding.etBoyBirthdate.setOnClickListener {
            chooseDatBoyPicker()
        }
        binding.etBoyBirthtime.setOnClickListener {
            SelectBoytime()
        }

        viewModel.sendKundliResponse.observe(this){
            if (it.status == 1){
                startActivity(Intent(this@EnterKundaliDetails,Kundali::class.java)
                    .putExtra("boydob",binding.etBoyBirthdate.text.toString(),)
                    .putExtra("boytob",Time)
                    .putExtra("picklat",pickupLatitude)
                    .putExtra("picklong",pickupLongitude)
                )
            }
        }
        binding.btnSubmit.setOnClickListener {
            var splitLink = binding.etBoyBirthdate.text.toString().split("/").toTypedArray()
            var startdate = splitLink[0]
            var middledate = splitLink[1]
            var enddate = splitLink[2]
            var splitTime = Time.split(":").toTypedArray()
            var starttime = splitTime[0]
            var endtime = splitTime[1]

            if (binding.etboyname.text.isNullOrEmpty()){
                toast(this,"Please enter Name.")
            }else if (binding.etBoyBirthdate.text.isNullOrEmpty()){
                toast(this,"Please enter date of birth.")
            }else if (binding.etBoyBirthtime.text.isNullOrEmpty()){
                toast(this,"Please enter time of birth.")
            }else if (binding.etBoyBirthplace.text.isNullOrEmpty()){
                toast(this,"Please enter place of birth")
            }else{
                if (CommonUtils.isInternetAvailable(this)) {
                    viewModel.insert_recently_see_kundali(
                        "Bearer "+userPref.getToken().toString(),binding.etboyname.text.toString(),enddate,middledate,startdate,starttime,endtime,"0",pickupLatitude.toString(),pickupLongitude.toString(),"5.5",binding.etBoyBirthplace.text.toString()
                    )
                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this,"Please check internet connection.")
                }
            }
        }
    }
    @RequiresApi(Build.VERSION_CODES.N)
    private fun chooseDatBoyPicker() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("d-M-yyyy")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            this, R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                var Date = DateFormat.getHoroscopeDate(simpleDateFormat.format(cal.time))
                toast(this@EnterKundaliDetails,Date.toString())
                binding.etBoyBirthdate.text =
                    DateFormat.getHoroscopeDate(simpleDateFormat.format(cal.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
//        datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }


    fun SelectBoytime() {
        val mTimePicker: TimePickerDialog
        val mcurrentTime = Calendar.getInstance()
        val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
        val minute = mcurrentTime.get(Calendar.MINUTE)

        mTimePicker = TimePickerDialog(
            this,
            R.style.MyTimePickerTheme,
            object : TimePickerDialog.OnTimeSetListener {
                override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                    Time = String.format("%d:%d",hourOfDay,minute)
                    if (hourOfDay < 10) {
                        if (minute <10){
                            binding.etBoyBirthtime.setText(String.format("0%d:0%d",hourOfDay,minute))
                        }else{
                            binding.etBoyBirthtime.setText(String.format("0%d:%d",hourOfDay,minute))
                        }

                    }else{
                        if (minute < 10) {
                            binding.etBoyBirthtime.setText(String.format("%d:0%d", hourOfDay, minute))
                        } else {
                            binding.etBoyBirthtime.setText(String.format("%d:%d", hourOfDay, minute))

                        }
                    }

                }
            },
            hour,
            minute,
            false
        )
        mTimePicker.show()
    }
    private fun placesAPiCall(requestCode: Int) {
        val fields = listOf(
            Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS,
            Place.Field.LAT_LNG
        )
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
            .build(this)
        startActivityForResult(intent, requestCode)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == AUTOCOMPLETE_PLACE_BOY_REQUEST_CODE) {
            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    pickupLongitude = latLng!!.longitude
                    pickupLatitude = latLng!!.latitude

//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLAT,
//                        pickupLatitude.toString()
//                    )
//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLNG,
//                        pickupLongitude.toString()
//                    )

                    binding.etBoyBirthplace.text = place.address
                    sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
                }

                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                }
            }
            return
        }
    }
}