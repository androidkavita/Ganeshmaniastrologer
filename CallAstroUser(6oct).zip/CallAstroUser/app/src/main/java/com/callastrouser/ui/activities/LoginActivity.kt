package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.databinding.ActivityLoginBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.LoginViewModel
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginActivity : BaseActivity() {
    lateinit var binding: ActivityLoginBinding
    private val viewModel: LoginViewModel by viewModels()
    lateinit var id :String
    lateinit var otp :String
    lateinit var is_new :String
    var deviceToken = ""
    var countryCode = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_login)

        FirebaseMessaging.getInstance().getToken()
            .addOnCompleteListener(OnCompleteListener<String?> { task ->
                if (!task.isSuccessful) {
                    Log.w("Failed", "Fetching FCM registration token failed", task.exception)
                    return@OnCompleteListener
                }

                // Get new FCM registration token
                val token = task.result

                // Log and toast
                deviceToken = token
                Log.d("Success", deviceToken)
                //Toast.makeText(this@VehicleInfoActivity, deviceToken, Toast.LENGTH_SHORT).show()
            })
        countryCode = binding.ccp.selectedCountryCode
        binding.ccp.setOnCountryChangeListener(com.hbb20.CountryCodePicker.OnCountryChangeListener {
            countryCode = binding.ccp.selectedCountryCode

        })
        binding.btnSendOtp.setOnClickListener {
            if (binding.etPhone.text.isNullOrEmpty()){
                snackbar("Please enter mobile number.")
            }else if (binding.etPhone.text.length < 10){
                snackbar("Please enter valid number.")
            }else {
                if (CommonUtils.isInternetAvailable(this)) {
                    viewModel.Login(
                        countryCode,binding.etPhone.text.toString(),"Android","Android","Android",deviceToken
                    )
                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this,"Please check internet connection.")
                }

            }
        }
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.loginResponse.observe(this) {
            if (it?.status == 1) {
                id = it.data?.id.toString()
                otp = it.data?.otp.toString()
//                if (it.data?.is_new == "1"){
//                    var intent = Intent(this, Registration::class.java)
//                    intent.putExtra("id",id)
//                    intent.putExtra("otp",otp)
//                    startActivity(intent)
//                }else{
                    var intent = Intent(this, LoginVerifyOtpActivity::class.java)
                    intent.putExtra("id",id)
                    intent.putExtra("otp",otp)
                    intent.putExtra("is_new",it.data?.is_new)
                    intent.putExtra("mobile",binding.etPhone.text.toString())
                    startActivity(intent)
//                }

//                userPref.user = it.data!!
//                userPref.isLogin = true
//                userPref.setid(it.data?.id.toString())
//                userPref.setToken(it.data!!.apiToken)
//                userPref.setRole(it.data!!.role.toString())
//                userPref.setName(it.data?.name!!)
//                userPref.setEmail(it.data!!.email)
//                userPref.setMobile(it.data!!.mobileNumber.toString())
//                userPref.setUserId(it.data!!.id!!.toString())
//                it.data!!.profileImage?.let { it1 -> userPref.setImage(it1) }
//                userPref.setUserId(it!!.data!!.Id.toString())

            } else {
                //toast(it.message)
                snackbar(it?.message!!)
            }
        }
    }
}