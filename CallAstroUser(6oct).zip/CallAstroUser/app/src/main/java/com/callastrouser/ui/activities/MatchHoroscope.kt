package com.callastrouser.ui.activities

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.widget.Toast
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.callastro.data.ApiService
import com.callastrouser.R
import com.callastrouser.databinding.ActivityMatchHoroscopeBinding
import com.callastrouser.model.requesBody.MatchHoroscopeRequest
import com.callastrouser.util.ApiClient
import com.callastrouser.util.ApiClient.retrofit
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.KundaliViewModel
import com.google.gson.JsonObject
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import retrofit2.Call
import retrofit2.Callback
import retrofit2.http.GET
import retrofit2.http.Query

@AndroidEntryPoint
class MatchHoroscope : BaseActivity() {
    lateinit var binding : ActivityMatchHoroscopeBinding
    var description:String=""
    lateinit var boydob:String
    lateinit var boytob:String
    lateinit var boybirthplace:String
    lateinit var girldob:String
    lateinit var girltob:String
    lateinit var girlbirthplace:String
    var picklat = 0.0
    var picklong = 0.0
    var droplat = 0.0
    var droplong = 0.0
    val viewModel: KundaliViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_match_horoscope)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_match_horoscope)
        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Ashtkoot"

        if (intent != null){
            boydob = intent.getStringExtra("boydob").toString()
            boytob = intent.getStringExtra("boytob").toString()
            boybirthplace = intent.getStringExtra("boybirthplace").toString()
            girldob = intent.getStringExtra("girldob").toString()
            girltob = intent.getStringExtra("girltob").toString()
            girlbirthplace = intent.getStringExtra("girlbirthplace").toString()
            picklat = intent.getDoubleExtra("picklat",0.0)
            picklong = intent.getDoubleExtra("picklong",0.0)
            droplat = intent.getDoubleExtra("droplat",0.0)
            droplong = intent.getDoubleExtra("droplong",0.0)
        }

        if (CommonUtils.isInternetAvailable(this)) {
//            aboutUs()
            MatchHoroscope()
        } else {
            toast(this,"Please check internet connection.")
        }
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.kundliMatchMakingResponse.observe(this){
            if (it.statusCode == 200){
                binding.varnamoonsignnumberboy.text = it.output.varna_kootam.groom.moon_sign_number.toString()
                binding.varnamoonsignboy.text = it.output.varna_kootam.groom.moon_sign.toString()
                binding.varnamboy.text = it.output.varna_kootam.groom.varnam.toString()
                binding.varnamnameboy.text = it.output.varna_kootam.groom.varnam_name.toString()
                binding.varnamoonsignnumbergirl.text = it.output.varna_kootam.bride.moon_sign_number.toString()
                binding.varnamoonsigngirl.text = it.output.varna_kootam.bride.moon_sign.toString()
                binding.varnamgirl.text = it.output.varna_kootam.bride.varnam.toString()
                binding.varnamnamegirl.text = it.output.varna_kootam.bride.varnam_name.toString()
                binding.vatsyakootamboy.text = it.output.vasya_kootam.groom.groom_kootam.toString()
                binding.vatsyakootamnameboy.text = it.output.vasya_kootam.groom.groom_kootam_name.toString()
                binding.vatsyakootamgirl.text = it.output.vasya_kootam.bride.bride_kootam.toString()
                binding.vatsyakootamnamegirl.text = it.output.vasya_kootam.bride.bride_kootam_name.toString()
                binding.tarakootamstarnumberboy.text = it.output.tara_kootam.groom.star_number.toString()
                binding.tarakootamstarnameboy.text = it.output.tara_kootam.groom.star_name.toString()
                binding.tarakootamstarnumbergirl.text = it.output.tara_kootam.bride.star_number.toString()
                binding.tarakootamstarnamegirl.text = it.output.tara_kootam.bride.star_name.toString()
                binding.yonikootamstarboy.text = it.output.yoni_kootam.groom.star.toString()
                binding.yonikootamyoninumberboy.text = it.output.yoni_kootam.groom.yoni_number.toString()
                binding.yonikootamyoniboy.text = it.output.yoni_kootam.groom.yoni.toString()
                binding.yonikootamstargirl.text = it.output.yoni_kootam.bride.star.toString()
                binding.yonikootamyoninumbergirl.text = it.output.yoni_kootam.bride.yoni_number.toString()
                binding.yonikootamyonigirl.text = it.output.yoni_kootam.bride.yoni.toString()
                binding.grahmaitrimoonsignnumberboy.text = it.output.graha_maitri_kootam.groom.moon_sign_number.toString()
                binding.grahmaitrimoonsignboy.text = it.output.graha_maitri_kootam.groom.moon_sign.toString()
                binding.grahmaitrimoonsignlordboy.text = it.output.graha_maitri_kootam.groom.moon_sign_lord.toString()
                binding.grahmaitrimoonsignlordnameboy.text = it.output.graha_maitri_kootam.groom.moon_sign_lord_name.toString()
                binding.grahmaitrimoonsignnumbergirl.text = it.output.graha_maitri_kootam.bride.moon_sign_number.toString()
                binding.grahmaitrimoonsigngirl.text = it.output.graha_maitri_kootam.bride.moon_sign.toString()
                binding.grahmaitrimoonsignlordgirl.text = it.output.graha_maitri_kootam.bride.moon_sign_lord.toString()
                binding.grahmaitrimoonsignlordnamegirl.text = it.output.graha_maitri_kootam.bride.moon_sign_lord_name.toString()
                binding.ganakootamnadiboy.text = it.output.gana_kootam.groom.groom_nadi.toString()
                binding.ganakootamnadinameboy.text = it.output.gana_kootam.groom.groom_nadi_name.toString()
                binding.ganakootamnadigirl.text = it.output.gana_kootam.bride.bride_nadi.toString()
                binding.ganakootamnadinamegirl.text = it.output.gana_kootam.bride.bride_nadi_name.toString()
                binding.rashikootammoonsignboy.text = it.output.rasi_kootam.groom.moon_sign.toString()
                binding.rashikootammoonsignnameboy.text = it.output.rasi_kootam.groom.moon_sign_name.toString()
                binding.rashikootammoonsigngirl.text = it.output.rasi_kootam.bride.moon_sign.toString()
                binding.rashikootammoonsignnamegirl.text = it.output.rasi_kootam.bride.moon_sign_name.toString()
                binding.nadikootamnadiboy.text = it.output.nadi_kootam.groom.nadi.toString()
                binding.nadikootamnadinameboy.text = it.output.nadi_kootam.groom.nadi_name.toString()
                binding.nadikootamnadigirl.text = it.output.nadi_kootam.bride.nadi.toString()
                binding.nadikootamnadinamegirl.text = it.output.nadi_kootam.bride.nadi_name.toString()
                binding.asstakootscore.text = it.output.total_score.toString()+"/"+it.output.out_of.toString()
                binding.vrnascore.text = it.output.varna_kootam.score.toString()+"/"+it.output.varna_kootam.out_of.toString()
                binding.vasyascore.text = it.output.vasya_kootam.score.toString()+"/"+it.output.vasya_kootam.out_of.toString()
                binding.tarascore.text = it.output.tara_kootam.score.toString()+"/"+it.output.tara_kootam.out_of.toString()
                binding.yoniscore.text = it.output.yoni_kootam.score.toString()+"/"+it.output.yoni_kootam.out_of.toString()
                binding.grahmaitriscore.text = it.output.graha_maitri_kootam.score.toString()+"/"+it.output.graha_maitri_kootam.out_of.toString()
                binding.ganascore.text = it.output.gana_kootam.score.toString()+"/"+it.output.gana_kootam.out_of.toString()
                binding.rashiscore.text = it.output.rasi_kootam.score.toString()+"/"+it.output.rasi_kootam.out_of.toString()
                binding.nadiscore.text = it.output.nadi_kootam.score.toString()+"/"+it.output.nadi_kootam.out_of.toString()




            }else{
                toast(this@MatchHoroscope,"Data not found.")
            }
        }
    }


    private fun MatchHoroscope(){

        var splitLink = boydob.split("/").toTypedArray()
        var startdate = splitLink[0]
        var middledate = splitLink[1]
        var enddate = splitLink[2]

        var splitTime = boytob.split(":").toTypedArray()
        var starttime = splitTime[0]
        var endtime = splitTime[1]

        var splitLinkgirl = girldob.split("/").toTypedArray()
        var startdategirl = splitLink[0]
        var middledategirl = splitLink[1]
        var enddategirl = splitLink[2]

        var splitTimegirl = girltob.split(":").toTypedArray()
        var starttimegirl = splitTime[0]
        var endtimegirl = splitTime[1]


        viewModel.match_making(
            enddate,
            middledate,
            startdate,
            starttime,
            endtime,
            "0",
            picklat.toString(),
            picklong.toString(),
            "5.5",
            enddategirl,
            middledategirl,
            startdategirl,
            starttimegirl,
            endtimegirl,
            "0",
            droplat.toString(),
            droplong.toString(),
            "5.5",
        )
    }










//    private fun aboutUs() {
//        val service = ApiClient.getClient().create(ApiService::class.java)
//        val call=service.users_about_us(
//            /*"11/03/1994"*/boydob,
//            /*"11:43"*/boytob,
//            "5.5",
//            /*"11"*/picklat.toString(),
//            /*"77"*/picklong.toString(),
//            /*"11/03/1994"*/girldob,
//            /*"11:43"*/girltob,
//            "5.5",
//            /*"11"*/droplat.toString(),
//            /*"77"*/droplong.toString(),
//            "af1c1101-8d4d-5a20-81eb-099719d2897a",
//            "hi",
//
//        )
//        call.enqueue(object : Callback<JsonObject> {
//            override fun onResponse(call: Call<JsonObject>, response: retrofit2.Response<JsonObject>) {
////                progressbar.hideProgress()
//                val mResponseBody: JsonObject = response.body()!!
//                val responseStatus: String = mResponseBody.get("status").asString
////                val response: String = mResponseBody.get("response").asString
//                if (responseStatus=="200"){
//                    val summary=mResponseBody.getAsJsonObject("response").asJsonObject
//                    binding.summary.text =if(summary.asJsonObject.get("extended_response").isJsonNull)""
//                    else summary.asJsonObject.get("extended_response").asString
//
//                    val shortsummary=mResponseBody.getAsJsonObject("response").asJsonObject
//                    binding.shortsummary.text =if(shortsummary.asJsonObject.get("bot_response").isJsonNull)""
//                    else shortsummary.asJsonObject.get("bot_response").asString
//
//                    val astakoot=mResponseBody.getAsJsonObject("response").asJsonObject
//                    var ashtakoot_score =if(astakoot.asJsonObject.get("ashtakoot_score").isJsonNull)""
//                    else astakoot.asJsonObject.get("ashtakoot_score").asString
//                    var astakootdata = ashtakoot_score.toString()
//                    var startDateastakootdata: String = astakootdata.toString()
//                    var splitLinkastakootdata = startDateastakootdata.split("/").toTypedArray()
//                    var startastakootdata = splitLinkastakootdata[0]
//                    var endastakootdata = splitLinkastakootdata[1]
//
//                    binding.astakootboy.text = startastakootdata
//                    binding.astakootgirl.text = endastakootdata
//
//
//
//                    val dashkoot=mResponseBody.getAsJsonObject("response").asJsonObject
//                    var dashkoot_score =if(dashkoot.asJsonObject.get("dashkoot_score").isJsonNull)""
//                    else astakoot.asJsonObject.get("dashkoot_score").asString
//                    var dashkootdata = dashkoot_score.toString()
//                    var startDatedashkootdata: String = dashkootdata.toString()
//                    var splitLinkdashkootdata = startDatedashkootdata.split("/").toTypedArray()
//                    var startdashkootdata = splitLinkdashkootdata[0]
//                    var enddashkootdata = splitLinkdashkootdata[1]
//
//                    binding.dashkootboy.text = startdashkootdata
//                    binding.dashkootgirl.text = enddashkootdata
//
//                    val rajjudosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    var boolvalue =if(rajjudosh.asJsonObject.get("rajjudosh").isJsonNull)""
//                    else rajjudosh.asJsonObject.get("rajjudosh").asString
//                    if (boolvalue == "true"){
//                        binding.rajjudosh.text = "Yes"
//                    }else{
//                        binding.rajjudosh.text = "No"
//                    }
//
//                    val vedhadosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    var boolvalue2 =if(vedhadosh.asJsonObject.get("vedhadosh").isJsonNull)""
//                    else rajjudosh.asJsonObject.get("vedhadosh").asString
//                    if (boolvalue2 == "true"){
//                        binding.veddosh.text = "Yes"
//                    }else{
//                        binding.veddosh.text = "No"
//                    }
//
//
//
//                    val mangakdosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    var mangakdosh_score = mangakdosh.get("mangaldosh_points")
//                    binding.mangaldoshboy.text = if(mangakdosh_score.asJsonObject.get("boy").isJsonNull)""
//                    else mangakdosh_score.asJsonObject.get("boy").asString
//                    binding.mangaldoshgirl.text = if(mangakdosh_score.asJsonObject.get("girl").isJsonNull)""
//                    else mangakdosh_score.asJsonObject.get("girl").asString
//
//
//
//
//
//                    val mangaldosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    binding.mangaldosh.text =if(mangaldosh.asJsonObject.get("mangaldosh").isJsonNull)""
//                    else mangaldosh.asJsonObject.get("mangaldosh").asString
//
//
//                    val pitradoshdosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    var pitradosh_score = pitradoshdosh.get("pitradosh_points")
//                    var boolvalue3 = if(pitradosh_score.asJsonObject.get("boy").isJsonNull)""
//                    else pitradosh_score.asJsonObject.get("boy").asString
//                    if (boolvalue3 == "true"){
//                        binding.pitradoshboy.text = "Yes"
//                    }else{
//                        binding.pitradoshboy.text = "No"
//                    }
//
//                    var boolvalue4 = if(pitradosh_score.asJsonObject.get("girl").isJsonNull)""
//                    else pitradosh_score.asJsonObject.get("girl").asString
//                    if (boolvalue4 == "true"){
//                        binding.pitradoshgirl.text = "Yes"
//                    }else{
//                        binding.pitradoshgirl.text = "No"
//                    }
//
//                    val pitradosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    binding.pitradosh.text =if(pitradosh.asJsonObject.get("pitradosh").isJsonNull)""
//                    else pitradosh.asJsonObject.get("pitradosh").asString
//
//
//                    val kaalsarpdoshdosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    var kaalsarpdoshdosh_score = kaalsarpdoshdosh.get("kaalsarp_points")
//                    var boolvalue5 = if(kaalsarpdoshdosh_score.asJsonObject.get("boy").isJsonNull)""
//                    else kaalsarpdoshdosh_score.asJsonObject.get("boy").asString
//                    if (boolvalue5 == "true"){
//                        binding.kalsarpdoshboy.text = "Yes"
//                    }else{
//                        binding.kalsarpdoshboy.text = "No"
//                    }
//
//                    var boolvalue6 = if(kaalsarpdoshdosh_score.asJsonObject.get("girl").isJsonNull)""
//                    else kaalsarpdoshdosh_score.asJsonObject.get("girl").asString
//                    if (boolvalue6 == "true"){
//                        binding.kalsarpdoshgirl.text = "Yes"
//                    }else{
//                        binding.kalsarpdoshgirl.text = "No"
//                    }
//
//
//                    val kalasarpdosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    binding.kalasarpdosh.text =if(kalasarpdosh.asJsonObject.get("kaalsarpdosh").isJsonNull)""
//                    else kalasarpdosh.asJsonObject.get("kaalsarpdosh").asString
//
//
//                    val manglikdosh_saturn_dosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    var manglikdosh_saturn_score = manglikdosh_saturn_dosh.get("manglikdosh_saturn_points")
//                    var boolvalue7 = if(manglikdosh_saturn_score.asJsonObject.get("boy").isJsonNull)""
//                    else manglikdosh_saturn_score.asJsonObject.get("boy").asString
//                    if (boolvalue7 == "true"){
//                        binding.mangliksaturndoshboy.text = "Yes"
//                    }else{
//                        binding.mangliksaturndoshboy.text = "No"
//                    }
//
//                    var boolvalue8 = if(manglikdosh_saturn_score.asJsonObject.get("girl").isJsonNull)""
//                    else manglikdosh_saturn_score.asJsonObject.get("girl").asString
//                    if (boolvalue8 == "true"){
//                        binding.mangliksaturndoshgirl.text = "Yes"
//                    }else{
//                        binding.mangliksaturndoshgirl.text = "No"
//                    }
//
//
//                    val manglikdosh_saturn=mResponseBody.getAsJsonObject("response").asJsonObject
//                    binding.manglikdoshSaturn.text =if(manglikdosh_saturn.asJsonObject.get("manglikdosh_saturn").isJsonNull)""
//                    else manglikdosh_saturn.asJsonObject.get("manglikdosh_saturn").asString
//
//
//                    val manglikdosh_rahuketu_dosh=mResponseBody.getAsJsonObject("response").asJsonObject
//                    var manglikdosh_rahuketu_score = manglikdosh_rahuketu_dosh.get("manglikdosh_rahuketu_points")
//                    var boolvalue9 = if(manglikdosh_rahuketu_score.asJsonObject.get("boy").isJsonNull)""
//                    else manglikdosh_rahuketu_score.asJsonObject.get("boy").asString
//                    if (boolvalue9 == "true"){
//                        binding.mangalikrauketudoshboy.text = "Yes"
//                    }else{
//                        binding.mangalikrauketudoshboy.text = "No"
//                    }
//
//                    var boolvalue10 = if(manglikdosh_rahuketu_score.asJsonObject.get("girl").isJsonNull)""
//                    else manglikdosh_rahuketu_score.asJsonObject.get("girl").asString
//                    if (boolvalue10 == "true"){
//                        binding.mangalrahuktudoshgirl.text = "Yes"
//                    }else{
//                        binding.mangalrahuktudoshgirl.text = "No"
//                    }
//
//
//                    val manglikdosh_rahuketu=mResponseBody.getAsJsonObject("response").asJsonObject
//                    binding.manglikdoshRahuketu.text =if(manglikdosh_rahuketu.asJsonObject.get("manglikdosh_rahuketu").isJsonNull)""
//                    else manglikdosh_rahuketu.asJsonObject.get("manglikdosh_rahuketu").asString
//
//                }else{
//                    Toast.makeText(this@MatchHoroscope,response.toString(), Toast.LENGTH_LONG).show()
//                }
//            }
//
//            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
////                progressbar.hideProgress()
//                call.cancel()
//            }
//
//
//        })
//    }
}