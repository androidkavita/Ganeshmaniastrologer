package com.callastrouser.model

data class RecentSeeKundliResponse(
    val `data`: List<RecentSeeKundliResponseData>,
    val message: String,
    val status: Int
)

data class RecentSeeKundliResponseData(
    val birthplace: String,
    val created_at: String,
    val dob: String,
    val id: Int,
    val latitude: String,
    val longitude: String,
    val name: String,
    val time_of_birth: String,
    val timezone: String,
    val updated_at: String,
    val user_id: Int,
    val fname: String,
    val fdob: String,
    val ftime_of_birth: String,
    val fplace_of_birth: String,
    val ftimezone: String,
    val mname: String,
    val mdob: String,
    val mtime_of_birth: String,
    val mplace_of_birth: String,
    val mtimezone: String,
    val mlatitude: String,
    val mlongitude: String,
    val flatitude: String,
    val flongitude: String,
)