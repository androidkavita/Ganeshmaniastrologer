package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class HistoryWallet(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : HistoryWalletData?   = HistoryWalletData()
)
data class HistoryWalletData(
    @SerializedName("wallet"              ) var wallet             : String?                       = null,
    @SerializedName("transaction_history" ) var transactionHistory : ArrayList<TransactionHistory> = arrayListOf()
)
data class TransactionHistory (

    @SerializedName("amount"           ) var amount          : String? = null,
    @SerializedName("transaction_date" ) var transactionDate : String? = null,
    @SerializedName("payment_status"   ) var paymentStatus   : Int?    = null,
    @SerializedName("paid_to"          ) var paidTo          : String? = null,
    @SerializedName("trans_date"       ) var transDate       : String? = null,
    @SerializedName("trans_time"       ) var transTime       : String? = null

)
