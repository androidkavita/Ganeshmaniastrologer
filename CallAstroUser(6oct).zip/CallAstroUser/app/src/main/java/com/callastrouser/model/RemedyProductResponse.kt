package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class RemedyProductResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<RemedyProductResponseData> = arrayListOf()
)
data class RemedyProductResponseData(
    @SerializedName("id"           ) var id          : Int?    = null,
    @SerializedName("astro_id"     ) var astroId     : Int?    = null,
    @SerializedName("product_id"   ) var productId   : Int?    = null,
    @SerializedName("main_image"   ) var mainImage   : String? = null,
    @SerializedName("price"        ) var price       : String? = null,
    @SerializedName("product_name" ) var productName : String? = null

)