package com.callastrouser.ui.activities

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.callastro.data.ApiService
import com.callastrouser.R
import com.callastrouser.databinding.ActivityKundaliBinding
import com.callastrouser.databinding.RowCancelReasonsBinding
import com.callastrouser.util.ApiClient
import com.callastrouser.viewModel.KundaliViewModel
import com.google.gson.JsonObject
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import retrofit2.Call
import retrofit2.Callback

@AndroidEntryPoint
class Kundali : BaseActivity() {
    lateinit var binding: ActivityKundaliBinding
    lateinit var boydob:String
    lateinit var boytob:String
    lateinit var boybirthplace:String
    var picklat = 0.0
    var picklong = 0.0
    val viewModel : KundaliViewModel by viewModels()
    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kundali)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_kundali)

        binding.header.backArrow.setOnClickListener { finish() }
        binding.header.tvHeadName.text = "Kundli"
        if (intent != null){
            boydob = intent.getStringExtra("boydob").toString()
            boytob = intent.getStringExtra("boytob").toString()
            boybirthplace = intent.getStringExtra("boybirthplace").toString()
            picklat = intent.getDoubleExtra("picklat",0.0)
            picklong = intent.getDoubleExtra("picklong",0.0)
        }
        binding.ChartName.text = "Lagna Chart"
        binding.Lagna.setTextColor(Color.parseColor("#742086"))
//        binding.navamsa.setTextColor(Color.parseColor("#706E6E"))
        achart_asc()
        binding.planetchart.visibility = View.VISIBLE
        binding.D3chart.visibility = View.GONE
//        binding.Navmshachart.visibility = View.GONE
        binding.Lagna.setOnClickListener {
            binding.ChartName.text = "Lagna Chart"
            binding.Lagna.setTextColor(Color.parseColor("#742086"))
            binding.navamsa.setTextColor(Color.parseColor("#706E6E"))
            achart_asc()
            binding.planetchart.visibility = View.VISIBLE
            binding.D3chart.visibility = View.GONE
//            binding.Navmshachart.visibility = View.GONE
        }
        binding.navamsa.setOnClickListener {
            binding.ChartName.text = "Navamsa Chart"
            binding.navamsa.setTextColor(Color.parseColor("#742086"))
            binding.Lagna.setTextColor(Color.parseColor("#706E6E"))
            chart_d9()
            binding.planetchart.visibility = View.GONE
            binding.D3chart.visibility = View.VISIBLE
//            binding.Navmshachart.visibility = View.VISIBLE
        }

        var splitLink = boydob.split("/").toTypedArray()
        var startdate = splitLink[0]
        var middledate = splitLink[1]
        var enddate = splitLink[2]

        var splitTime = boytob.split(":").toTypedArray()
        var starttime = splitTime[0]
        var endtime = splitTime[1]
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.Planets(
            enddate,
            middledate,
            startdate,
            starttime,
            endtime,
            "0",
            picklat.toString(),
            picklong.toString(),
            "5.5"
        )

        viewModel.dThreechart(
            enddate,middledate,startdate,starttime,endtime,"0",picklat.toString(),picklong.toString(),"5.5"
        )

        viewModel.planetsResponse.observe(this){
            if (it.statusCode == 200){
                binding.sign1.text = it.output[1].Ascendant.current_sign.toString()
                binding.sign2.text = it.output[1].Sun.current_sign.toString()
                binding.sign3.text = it.output[1].Moon.current_sign.toString()
                binding.sign4.text = it.output[1].Mars.current_sign.toString()
                binding.sign5.text = it.output[1].Mercury.current_sign.toString()
                binding.sign6.text = it.output[1].Jupiter.current_sign.toString()
                binding.sign7.text = it.output[1].Venus.current_sign.toString()
                binding.sign8.text = it.output[1].Saturn.current_sign.toString()
                binding.sign9.text = it.output[1].Rahu.current_sign.toString()
                binding.sign10.text = it.output[1].Ketu.current_sign.toString()
                binding.sign11.text = it.output[1].Uranus.current_sign.toString()
                binding.sign12.text = it.output[1].Neptune.current_sign.toString()
                binding.sign13.text = it.output[1].Pluto.current_sign.toString()

//                binding.Fdegree1.text = "%.4f".format(it.output[1].Ascendant.fullDegree).toString()
//                binding.Fdegree2.text = "%.4f".format(it.output[1].Sun.fullDegree).toString()
//                binding.Fdegree3.text = "%.4f".format(it.output[1].Moon.fullDegree).toString()
//                binding.Fdegree4.text = "%.4f".format(it.output[1].Mars.fullDegree).toString()
//                binding.Fdegree5.text = "%.4f".format(it.output[1].Mercury.fullDegree).toString()
//                binding.Fdegree6.text = "%.4f".format(it.output[1].Jupiter.fullDegree).toString()
//                binding.Fdegree7.text = "%.4f".format(it.output[1].Venus.fullDegree).toString()
//                binding.Fdegree8.text = "%.4f".format(it.output[1].Saturn.fullDegree).toString()
//                binding.Fdegree9.text = "%.4f".format(it.output[1].Rahu.fullDegree).toString()
//                binding.Fdegree10.text = "%.4f".format(it.output[1].Ketu.fullDegree).toString()
//                binding.Fdegree11.text = "%.4f".format(it.output[1].Uranus.fullDegree).toString()
//                binding.Fdegree12.text = "%.4f".format(it.output[1].Neptune.fullDegree).toString()
//                binding.Fdegree13.text = "%.4f".format(it.output[1].Pluto.fullDegree).toString()

                binding.Ndegree1.text = "%.4f".format(it.output[1].Ascendant.normDegree).toString()
                binding.Ndegree2.text = "%.4f".format(it.output[1].Sun.normDegree).toString()
                binding.Ndegree3.text = "%.4f".format(it.output[1].Moon.normDegree).toString()
                binding.Ndegree4.text = "%.4f".format(it.output[1].Mars.normDegree).toString()
                binding.Ndegree5.text = "%.4f".format(it.output[1].Mercury.normDegree).toString()
                binding.Ndegree6.text = "%.4f".format(it.output[1].Jupiter.normDegree).toString()
                binding.Ndegree7.text = "%.4f".format(it.output[1].Venus.normDegree).toString()
                binding.Ndegree8.text = "%.4f".format(it.output[1].Saturn.normDegree).toString()
                binding.Ndegree9.text = "%.4f".format(it.output[1].Rahu.normDegree).toString()
                binding.Ndegree10.text = "%.4f".format(it.output[1].Ketu.normDegree).toString()
                binding.Ndegree11.text = "%.4f".format(it.output[1].Uranus.normDegree).toString()
                binding.Ndegree12.text = "%.4f".format(it.output[1].Neptune.normDegree).toString()
                binding.Ndegree13.text = "%.4f".format(it.output[1].Pluto.normDegree).toString()

//                binding.Retro1.text = it.output[1].Ascendant.isRetro.toString()
//                binding.Retro2.text = it.output[1].Sun.isRetro.toString()
//                binding.Retro3.text = it.output[1].Moon.isRetro.toString()
//                binding.Retro4.text = it.output[1].Mars.isRetro.toString()
//                binding.Retro5.text = it.output[1].Mercury.isRetro.toString()
//                binding.Retro6.text = it.output[1].Jupiter.isRetro.toString()
//                binding.Retro7.text = it.output[1].Venus.isRetro.toString()
//                binding.Retro8.text = it.output[1].Saturn.isRetro.toString()
//                binding.Retro9.text = it.output[1].Rahu.isRetro.toString()
//                binding.Retro10.text = it.output[1].Ketu.isRetro.toString()
//                binding.Retro11.text = it.output[1].Uranus.isRetro.toString()
//                binding.Retro12.text = it.output[1].Neptune.isRetro.toString()
//                binding.Retro13.text = it.output[1].Pluto.isRetro.toString()

                if (it.output[1].Ascendant.isRetro.toString() == "true"){
                    binding.planet1.text = "Ascendant(R)"
                }else{
                    binding.planet1.text = "Ascendant"
                }

                if (it.output[1].Sun.isRetro.toString() == "true"){
                    binding.planet2.text = "Sun(R)"
                }else{
                    binding.planet2.text = "Sun"
                }

                if (it.output[1].Moon.isRetro.toString() == "true"){
                    binding.planet3.text = "Moon(R)"
                }else{
                    binding.planet3.text = "Moon"
                }

                if (it.output[1].Mars.isRetro.toString() == "true"){
                    binding.planet4.text = "Mars(R)"
                }else{
                    binding.planet4.text = "Mars"
                }

                if (it.output[1].Mercury.isRetro.toString() == "true"){
                    binding.planet5.text = "Mercury(R)"
                }else{
                    binding.planet5.text = "Mercury"
                }

                if (it.output[1].Jupiter.isRetro.toString() == "true"){
                    binding.planet6.text = "Jupiter(R)"
                }else{
                    binding.planet6.text = "Jupiter"
                }

                if (it.output[1].Venus.isRetro.toString() == "true"){
                    binding.planet7.text = "Venus(R)"
                }else{
                    binding.planet7.text = "Venus"
                }

                if (it.output[1].Saturn.isRetro.toString() == "true"){
                    binding.planet8.text = "Saturn(R)"
                }else{
                    binding.planet8.text = "Saturn"
                }

                if (it.output[1].Rahu.isRetro.toString() == "true"){
                    binding.planet9.text = "Rahu(R)"
                }else{
                    binding.planet9.text = "Rahu"
                }

                if (it.output[1].Ketu.isRetro.toString() == "true"){
                    binding.planet10.text = "Ketu(R)"
                }else{
                    binding.planet10.text = "Ketu"
                }

                if (it.output[1].Uranus.isRetro.toString() == "true"){
                    binding.planet11.text = "Uranus(R)"
                }else{
                    binding.planet11.text = "Uranus"
                }

                if (it.output[1].Neptune.isRetro.toString() == "true"){
                    binding.planet12.text = "Neptune(R)"
                }else{
                    binding.planet12.text = "Neptune"
                }

                if (it.output[1].Pluto.isRetro.toString() == "true"){
                    binding.planet13.text = "Pluto(R)"
                }else{
                    binding.planet13.text = "Pluto"
                }



            }else{
                toast(this@Kundali,"Input Field Wrong")
            }
        }

        viewModel.dThreeChartResponse.observe(this){
            if (it.statusCode == 200){
                binding.Dthreesign1.text = it.output.`0`.current_sign.toString()
                binding.Dthreesign2.text = it.output.`1`.current_sign.toString()
                binding.Dthreesign3.text = it.output.`2`.current_sign.toString()
                binding.Dthreesign4.text = it.output.`3`.current_sign.toString()
                binding.Dthreesign5.text = it.output.`4`.current_sign.toString()
                binding.Dthreesign6.text = it.output.`5`.current_sign.toString()
                binding.Dthreesign7.text = it.output.`6`.current_sign.toString()
                binding.Dthreesign8.text = it.output.`7`.current_sign.toString()
                binding.Dthreesign9.text = it.output.`8`.current_sign.toString()
                binding.Dthreesign10.text = it.output.`9`.current_sign.toString()
                binding.Dthreesign11.text = it.output.`10`.current_sign.toString()
                binding.Dthreesign12.text = it.output.`11`.current_sign.toString()
                binding.Dthreesign13.text = it.output.`12`.current_sign.toString()

//                binding.Fdegree1.text = "%.4f".format(it.output[1].Ascendant.fullDegree).toString()
//                binding.Fdegree2.text = "%.4f".format(it.output[1].Sun.fullDegree).toString()
//                binding.Fdegree3.text = "%.4f".format(it.output[1].Moon.fullDegree).toString()
//                binding.Fdegree4.text = "%.4f".format(it.output[1].Mars.fullDegree).toString()
//                binding.Fdegree5.text = "%.4f".format(it.output[1].Mercury.fullDegree).toString()
//                binding.Fdegree6.text = "%.4f".format(it.output[1].Jupiter.fullDegree).toString()
//                binding.Fdegree7.text = "%.4f".format(it.output[1].Venus.fullDegree).toString()
//                binding.Fdegree8.text = "%.4f".format(it.output[1].Saturn.fullDegree).toString()
//                binding.Fdegree9.text = "%.4f".format(it.output[1].Rahu.fullDegree).toString()
//                binding.Fdegree10.text = "%.4f".format(it.output[1].Ketu.fullDegree).toString()
//                binding.Fdegree11.text = "%.4f".format(it.output[1].Uranus.fullDegree).toString()
//                binding.Fdegree12.text = "%.4f".format(it.output[1].Neptune.fullDegree).toString()
//                binding.Fdegree13.text = "%.4f".format(it.output[1].Pluto.fullDegree).toString()

//                binding.Ndegree1.text = "%.4f".format(it.output[1].Ascendant.normDegree).toString()
//                binding.Ndegree2.text = "%.4f".format(it.output[1].Sun.normDegree).toString()
//                binding.Ndegree3.text = "%.4f".format(it.output[1].Moon.normDegree).toString()
//                binding.Ndegree4.text = "%.4f".format(it.output[1].Mars.normDegree).toString()
//                binding.Ndegree5.text = "%.4f".format(it.output[1].Mercury.normDegree).toString()
//                binding.Ndegree6.text = "%.4f".format(it.output[1].Jupiter.normDegree).toString()
//                binding.Ndegree7.text = "%.4f".format(it.output[1].Venus.normDegree).toString()
//                binding.Ndegree8.text = "%.4f".format(it.output[1].Saturn.normDegree).toString()
//                binding.Ndegree9.text = "%.4f".format(it.output[1].Rahu.normDegree).toString()
//                binding.Ndegree10.text = "%.4f".format(it.output[1].Ketu.normDegree).toString()
//                binding.Ndegree11.text = "%.4f".format(it.output[1].Uranus.normDegree).toString()
//                binding.Ndegree12.text = "%.4f".format(it.output[1].Neptune.normDegree).toString()
//                binding.Ndegree13.text = "%.4f".format(it.output[1].Pluto.normDegree).toString()

//                binding.Retro1.text = it.output[1].Ascendant.isRetro.toString()
//                binding.Retro2.text = it.output[1].Sun.isRetro.toString()
//                binding.Retro3.text = it.output[1].Moon.isRetro.toString()
//                binding.Retro4.text = it.output[1].Mars.isRetro.toString()
//                binding.Retro5.text = it.output[1].Mercury.isRetro.toString()
//                binding.Retro6.text = it.output[1].Jupiter.isRetro.toString()
//                binding.Retro7.text = it.output[1].Venus.isRetro.toString()
//                binding.Retro8.text = it.output[1].Saturn.isRetro.toString()
//                binding.Retro9.text = it.output[1].Rahu.isRetro.toString()
//                binding.Retro10.text = it.output[1].Ketu.isRetro.toString()
//                binding.Retro11.text = it.output[1].Uranus.isRetro.toString()
//                binding.Retro12.text = it.output[1].Neptune.isRetro.toString()
//                binding.Retro13.text = it.output[1].Pluto.isRetro.toString()

                if (it.output.`0`.isRetro == "true"){
                    binding.Dthreeplanet1.text = "Ascendant(R)"
                }else{
                    binding.Dthreeplanet1.text = "Ascendant"
                }

                if (it.output.`1`.isRetro == "true"){
                    binding.Dthreeplanet2.text = "Sun(R)"
                }else{
                    binding.Dthreeplanet2.text = "Sun"
                }

                if (it.output.`2`.isRetro == "true"){
                    binding.Dthreeplanet3.text = "Moon(R)"
                }else{
                    binding.Dthreeplanet3.text = "Moon"
                }

                if (it.output.`3`.isRetro == "true"){
                    binding.Dthreeplanet4.text = "Mars(R)"
                }else{
                    binding.Dthreeplanet4.text = "Mars"
                }

                if (it.output.`4`.isRetro == "true"){
                    binding.Dthreeplanet5.text = "Mercury(R)"
                }else{
                    binding.Dthreeplanet5.text = "Mercury"
                }

                if (it.output.`5`.isRetro == "true"){
                    binding.Dthreeplanet6.text = "Jupiter(R)"
                }else{
                    binding.Dthreeplanet6.text = "Jupiter"
                }

                if (it.output.`6`.isRetro == "true"){
                    binding.Dthreeplanet7.text = "Venus(R)"
                }else{
                    binding.Dthreeplanet7.text = "Venus"
                }

                if (it.output.`7`.isRetro == "true"){
                    binding.Dthreeplanet8.text = "Saturn(R)"
                }else{
                    binding.Dthreeplanet8.text = "Saturn"
                }

                if (it.output.`8`.isRetro == "true"){
                    binding.Dthreeplanet9.text = "Rahu(R)"
                }else{
                    binding.Dthreeplanet9.text = "Rahu"
                }

                if (it.output.`9`.isRetro == "true"){
                    binding.Dthreeplanet10.text = "Ketu(R)"
                }else{
                    binding.Dthreeplanet10.text = "Ketu"
                }

                if (it.output.`10`.isRetro == "true"){
                    binding.Dthreeplanet11.text = "Uranus(R)"
                }else{
                    binding.Dthreeplanet11.text = "Uranus"
                }

                if (it.output.`11`.isRetro == "true"){
                    binding.Dthreeplanet12.text = "Neptune(R)"
                }else{
                    binding.Dthreeplanet12.text = "Neptune"
                }

                if (it.output.`12`.isRetro == "true"){
                    binding.Dthreeplanet13.text = "Pluto(R)"
                }else{
                    binding.Dthreeplanet13.text = "Pluto"
                }



            }else{
                toast(this@Kundali,"Input Field Wrong")
            }
        }


//        viewModel.Navamsa_chart(
//            enddate,middledate,startdate,starttime,endtime,"0",picklat.toString(),picklong.toString(),"5.5"
//        )

//        viewModel.navmsaResponse.observe(this){
//            if (it.statusCode == 200){
//                binding.Navsign1.text = it.output.zero?.current_sign.toString()
//                binding.Navsign2.text = it.output.one?.current_sign.toString()
//                binding.Navsign3.text = it.output.two?.current_sign.toString()
//                binding.Navsign4.text = it.output.three?.current_sign.toString()
//                binding.Navsign5.text = it.output.four?.current_sign.toString()
//                binding.Navsign6.text = it.output.five?.current_sign.toString()
//                binding.Navsign7.text = it.output.six?.current_sign.toString()
//                binding.Navsign8.text = it.output.seven?.current_sign.toString()
//                binding.Navsign9.text = it.output.eight?.current_sign.toString()
//                binding.Navsign10.text = it.output.nine?.current_sign.toString()
//                binding.Navsign11.text = it.output.ten?.current_sign.toString()
//                binding.Navsign12.text = it.output.eleven?.current_sign.toString()
//                binding.Navsign13.text = it.output.twelve?.current_sign.toString()
//
//                binding.NavRetro1.text = it.output.zero?.isRetro.toString()
//                binding.NavRetro2.text = it.output.one?.isRetro.toString()
//                binding.NavRetro3.text = it.output.two?.isRetro.toString()
//                binding.NavRetro4.text = it.output.three?.isRetro.toString()
//                binding.NavRetro5.text = it.output.four?.isRetro.toString()
//                binding.NavRetro6.text = it.output.five?.isRetro.toString()
//                binding.NavRetro7.text = it.output.six?.isRetro.toString()
//                binding.NavRetro8.text = it.output.seven?.isRetro.toString()
//                binding.NavRetro9.text = it.output.eight?.isRetro.toString()
//                binding.NavRetro10.text = it.output.nine?.isRetro.toString()
//                binding.NavRetro11.text = it.output.ten?.isRetro.toString()
//                binding.NavRetro12.text = it.output.eleven?.isRetro.toString()
//                binding.NavRetro13.text = it.output.twelve?.isRetro.toString()
//            }
//
//
//
//        }





    }
    private fun achart_asc() {
        val service = ApiClient.getClient().create(ApiService::class.java)
        val call=service.achart_asc(
            /*"04/12/1997"*/boydob,
            /*"07:30"*/boytob,
            /*"26.4499"*/picklat.toString(),
            /*"80.3319"*/picklong.toString(),
            "5.5",
            "shubhamshu",
            "a3da3421b93cb7bc78d168b1433a335e",
            )
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: retrofit2.Response<JsonObject>) {
//                progressbar.hideProgress()
                val mResponseBody: JsonObject = response.body()!!
                val responseStatus: String = mResponseBody.get("url").asString
                    Glide.with(this@Kundali).load(responseStatus).into(binding.kundli)
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
//                progressbar.hideProgress()
                call.cancel()
            }


        })
    }
    private fun chart_d9() {
        val service = ApiClient.getClient().create(ApiService::class.java)
        val call=service.chart_d9(
            /*"04/12/1997"*/boydob,
            /*"07:30"*/boytob,
            /*"26.4499"*/picklat.toString(),
            /*"80.3319"*/picklong.toString(),
            "5.5",
            "shubhamshu",
            "a3da3421b93cb7bc78d168b1433a335e",
        )
        call.enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: retrofit2.Response<JsonObject>) {
//                progressbar.hideProgress()
                val mResponseBody: JsonObject = response.body()!!
                val responseStatus: String = mResponseBody.get("url").asString
                Glide.with(this@Kundali).load(responseStatus).into(binding.kundli)
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
//                progressbar.hideProgress()
                call.cancel()
            }


        })
    }


}