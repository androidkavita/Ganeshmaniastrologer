package com.callastrouser.adapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.callastrouser.ui.fragments.CancelEcommerceProductsFragment
import com.callastrouser.ui.fragments.CompletedEcommerceProductsFragment
import com.callastrouser.ui.fragments.OnGoingEcommerceProductsFragment


class ViewPagerEcommerceProductsAdapter(
    fragmentManager: FragmentManager
) : FragmentPagerAdapter(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    private val titles =
        arrayOf("Ongoing","Cancelled","Completed")

    override fun getItem(position: Int): Fragment {

        val bundle = Bundle()
        val fragment : Fragment
        return when (position) {
            0 -> {
                fragment = OnGoingEcommerceProductsFragment()
                bundle.putInt("type",0)
                fragment.arguments = bundle
                fragment
            }
            1 -> {
                fragment = CancelEcommerceProductsFragment()
                bundle.putInt("type",0)
                fragment.arguments = bundle
                fragment
            }
            else -> {
                fragment = CompletedEcommerceProductsFragment()
                bundle.putInt("type",1)
                fragment.arguments = bundle
                fragment
            }
        }
    }

    override fun getCount(): Int {
        return titles.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return titles[position]
    }
}