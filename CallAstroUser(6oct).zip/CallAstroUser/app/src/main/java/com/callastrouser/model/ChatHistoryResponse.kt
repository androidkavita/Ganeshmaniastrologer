package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ChatHistoryResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<ChatHistoryResponseData> = arrayListOf()
)
data class ChatHistoryResponseData(
//    @SerializedName("amount"          ) var amount        : String? = null,
//    @SerializedName("duration"        ) var duration      : String? = null,
//    @SerializedName("booking_id"      ) var bookingId     : String? = null,
//    @SerializedName("astro_id"        ) var astro_id      : String? = null,
//    @SerializedName("astro_name"      ) var astroName     : String? = null,
//    @SerializedName("calling_charg"   ) var callingCharg  : Int?    = null,
//    @SerializedName("astro_iamge"     ) var astroIamge    : String? = null,
//    @SerializedName("created_at"      ) var createdAt     : String? = null,
//    @SerializedName("astro_package"   ) var astroPackage  : String? = null,
//    @SerializedName("price"           ) var price         : String? = null,
//    @SerializedName("booking_date"    ) var bookingDate   : String? = null,
//    @SerializedName("avg_astro_revew" ) var avgAstroRevew : Double? = null,
//    @SerializedName("status"          ) var status        : String? = null,
//    @SerializedName("remark"          ) var remark        : String? = null,
//    @SerializedName("findiness"       ) var findiness     : String? = null,
//    @SerializedName("conclusion"      ) var conclusion    : String? = null

    @SerializedName("amount"        ) var amount       : String? = null,
    @SerializedName("caller_id"     ) var callerId     : String? = null,
    @SerializedName("duration"      ) var duration     : String? = null,
    @SerializedName("booking_id"    ) var bookingId    : String? = null,
    @SerializedName("astro_id"      ) var astroId      : Int?    = null,
    @SerializedName("astro_name"    ) var astroName    : String? = null,
    @SerializedName("calling_charg" ) var callingCharg : String? = null,
    @SerializedName("astro_iamge"   ) var astroIamge   : String? = null,
    @SerializedName("created_at"    ) var createdAt    : String? = null,
    @SerializedName("astro_package" ) var astroPackage : String? = null,
    @SerializedName("price"         ) var price        : String? = null,
    @SerializedName("booking_date"  ) var bookingDate  : String? = null,
    @SerializedName("feedback"      ) var feedback     : String? = null,
    @SerializedName("rating"        ) var rating       : String? = null,
    @SerializedName("status"        ) var status       : String? = null,
    @SerializedName("remark"        ) var remark       : String? = null,
    @SerializedName("findiness"     ) var findiness    : String? = null,
    @SerializedName("conclusion"    ) var conclusion   : String? = null

)
