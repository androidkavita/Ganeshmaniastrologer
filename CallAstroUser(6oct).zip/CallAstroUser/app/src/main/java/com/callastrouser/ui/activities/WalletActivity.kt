package com.callastrouser.ui.activities

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.airbnb.lottie.LottieAnimationView
import com.callastrouser.R
import com.callastrouser.adapter.RechargeWalletDiscountAdapter
import com.callastrouser.adapter.WalletHistoryAdapter
import com.callastrouser.adapter.Walletvalue
import com.callastrouser.databinding.ActivityWalletBinding
import com.callastrouser.databinding.AddmoneyBinding
import com.callastrouser.model.RechargeAmountDiscountResponseData
import com.callastrouser.model.TransactionHistoryData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.WalletViewModel
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.maxtra.callastro.baseClass.BaseActivity
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject

@AndroidEntryPoint
class WalletActivity : BaseActivity(), Walletvalue {
    lateinit var binding : ActivityWalletBinding
    private val viewModel : WalletViewModel by viewModels()
    lateinit var bottomdialog: BottomSheetDialog
    var List:ArrayList<RechargeAmountDiscountResponseData> = arrayListOf()
    var List1:ArrayList<TransactionHistoryData> = arrayListOf()
    var amt :String=""
    lateinit var adapter : RechargeWalletDiscountAdapter
    lateinit var adapter1 : WalletHistoryAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wallet)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_wallet)

        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = "Wallet"
        RechargeNow()

        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.wallet(
                "Bearer "+userPref.getToken().toString()
            )
            viewModel.Rechargewithdiscount("Bearer "+userPref.getToken().toString())
            viewModel.history_wallets("Bearer "+userPref.getToken().toString())
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.walletResponse.observe(this){
            if (it.status == 1){
                binding.name.text = it.data?.name.toString()
                binding.tvBalance.text = "₹"+it.data?.wallet.toString()
            }
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        binding.addmoney.setOnClickListener {
            ADDMONEY()
        }

        viewModel.rechargeAmountDiscountResponse.observe(this){
            if (it.status == 1){
                List.clear()
                List.addAll(it.data)
                val staggeredGridLayoutManager = StaggeredGridLayoutManager(3, LinearLayoutManager.VERTICAL)
                binding.rvWallet.layoutManager = staggeredGridLayoutManager
                adapter = RechargeWalletDiscountAdapter(this@WalletActivity,List,this)
                binding.rvWallet.adapter = adapter
            }
        }

        viewModel.transactionHistory.observe(this){
            if (it.status == 1){
                List1.clear()
                List1.addAll(it.data)
                adapter1 = WalletHistoryAdapter(this@WalletActivity,List1)
                binding.rvAstrologers.adapter = adapter1
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.wallet(
                "Bearer "+userPref.getToken().toString()
            )
            viewModel.history_wallets("Bearer "+userPref.getToken().toString())
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }


    }
    private fun ADDMONEY() {
        val cDialog = Dialog(this)
        val bindingDialog: AddmoneyBinding = DataBindingUtil.inflate(
            LayoutInflater.from(this),
            R.layout.addmoney,
            null,
            false
        )
        cDialog.setContentView(bindingDialog.root)
        cDialog.setCancelable(true)
        cDialog.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        cDialog.show()
        bindingDialog.btnCancel.setOnClickListener {
            cDialog.dismiss()
        }

        bindingDialog.btnLogout.setOnClickListener {
            amt = bindingDialog.fullnameet.text.toString()

            if (bindingDialog.fullnameet.text.toString().isNullOrEmpty()){
                toast(this@WalletActivity,"Please enter Amount.")
            }else{
                startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                    .putExtra("amount",amt))
            }

//            startPayment(amt)
            cDialog.dismiss()


        }


//        bindingDialog.btnLogout.setOnClickListener {
//            userPref.clearPref()
//            startActivity(Intent(this, LoginActivity::class.java))
//            finishAffinity()
//            cDialog.dismiss()
//        }
    }
    fun RechargeNow() {
        // on below line we are creating a new bottom sheet dialog.
        bottomdialog = BottomSheetDialog(this,R.style.AppBottomSheetDialogTheme)
        // on below line we are inflating a layout file which we have created.
        val view = layoutInflater.inflate(R.layout.rechargenow, null)
        val metrics = DisplayMetrics()
        windowManager?.defaultDisplay?.getMetrics(metrics)
        bottomdialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
//        this.bottomdialog.getWindow()?.setBackgroundDrawableResource(R.drawable.lowerborder2);
        bottomdialog.behavior.peekHeight = metrics.heightPixels
        var cross = view.findViewById<ImageView>(R.id.cross)
        var three = view.findViewById<Button>(R.id.three)
        var five = view.findViewById<Button>(R.id.five)
        var ten = view.findViewById<Button>(R.id.ten)
        var fifteen = view.findViewById<Button>(R.id.fifteen)
        var twenty = view.findViewById<Button>(R.id.twenty)
        var twentyfive = view.findViewById<Button>(R.id.twentyfive)
        var thirty = view.findViewById<Button>(R.id.thirty)
        var thirtyfive = view.findViewById<Button>(R.id.thirtyfive)

        three.setOnClickListener {
            amt ="300"
//            startPayment(amt)
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt))
            bottomdialog.dismiss()
        }
        five.setOnClickListener {
            amt ="500"
//            startPayment(amt)
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt))
            bottomdialog.dismiss()
        }
        ten.setOnClickListener {
            amt ="1000"
//            startPayment(amt)
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt))
            bottomdialog.dismiss()
        }
        fifteen.setOnClickListener {
            amt ="1500"
//            startPayment(amt)
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt))
            bottomdialog.dismiss()
        }
        twenty.setOnClickListener {
            amt ="2000"
//            startPayment(amt)
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt))
            bottomdialog.dismiss()
        }
        twentyfive.setOnClickListener {
            amt ="2500"
//            startPayment(amt)
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt))
            bottomdialog.dismiss()
        }
        thirty.setOnClickListener {
            amt ="3000"
//            startPayment(amt)
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt))
            bottomdialog.dismiss()
        }
        thirtyfive.setOnClickListener {
            amt ="3500"
//            startPayment(amt)
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt))
            bottomdialog.dismiss()
        }


        cross.setOnClickListener {
            bottomdialog.dismiss()
        }
        // below line is use to set cancelable to avoid
        // closing of dialog box when clicking on the screen.
        bottomdialog.setCancelable(false)

        // on below line we are setting
        // content view to our view.
        bottomdialog.setContentView(view)

        // on below line we are calling
        // a show method to display a dialog.
        bottomdialog.show()
    }

    override fun Amount(box: LinearLayout, amount: Int,amounttext: TextView,discount:String) {
        box.setOnClickListener {
            amt = amount.toString()
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt)
                .putExtra("discount",discount))
//            startPayment(amt)
        }
        amounttext.setOnClickListener{
            amt = amount.toString()
            startActivity(Intent(this@WalletActivity,PaymentInformation::class.java)
                .putExtra("amount",amt)
                .putExtra("discount",discount))
//            startPayment(amt)
        }
    }
}