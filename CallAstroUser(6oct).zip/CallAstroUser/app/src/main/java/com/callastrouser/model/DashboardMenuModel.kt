package com.callastrouser.model

data class DashboardMenuModel(val title: String, val icon: Int){


}

