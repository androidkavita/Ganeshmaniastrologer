package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.ActiveHomeResponse
import com.callastrouser.model.BlogListResponse
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.GetBlogDetailResponse
import com.callastrouser.model.RechargeAmountDiscountResponse
import com.callastrouser.model.TransactionHistoryResponse
import com.callastrouser.model.WalletResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class StoryViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    var blogListResponse = MutableLiveData<BlogListResponse>()
    var blogDetailResponse = MutableLiveData<GetBlogDetailResponse>()



    fun get_blog_list(
        token: String,
    ) {
//        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.get_blog_list(token)
            if (response.isSuccessful) {
//                progressBarStatus.value = false
                blogListResponse.postValue(response.body())
            } else {
//                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun get_blog_detail(
        token: String,
        id: String,
    ) {
//        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.get_blog_detail(token,id)
            if (response.isSuccessful) {
//                progressBarStatus.value = false
                blogDetailResponse.postValue(response.body())
            } else {
//                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

}