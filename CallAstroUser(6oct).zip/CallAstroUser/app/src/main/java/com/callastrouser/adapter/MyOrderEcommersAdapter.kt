package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowOngoingEcommerceBinding
import com.callastrouser.model.MyOrdersEcommersProductData
import com.maxtra.astrorahi.interfaces.ProductDetails

class MyOrderEcommersAdapter (val context : Context, var data: ArrayList<MyOrdersEcommersProductData>, var details: ProductDetails) :
    RecyclerView.Adapter<MyOrderEcommersAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowOngoingEcommerceBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyOrderEcommersAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_ongoing_ecommerce, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: MyOrderEcommersAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.tvStoneName.text = List.productNames.toString()
//        Glide.with(context).load(List.mainImage).into(holder.binding.image)

        try {
            holder.binding.tvBookingId.text = List.orderId.toString()
            holder.binding.tvQty.text = List.productCount!!.toString()
            holder.binding.tvPrice.text = "₹"+List.grandTotal!!.toString()
            holder.binding.tvDate.text = List.orderDate!!.toString()
            holder.binding.tvConfirmationStatus.text = List.statusName.toString()
        }catch (e:Exception){
            e.printStackTrace()
        }



        details.Details(holder.binding.btnDetails,List.productId.toString(),List.orderId.toString())
    }
    override fun getItemCount(): Int {
        return data.size
    }
}