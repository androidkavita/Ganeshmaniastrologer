package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.WalletrechargediscountBinding
import com.callastrouser.model.RechargeAmountDiscountResponseData

class RechargeWalletDiscountAdapter (val context : Context, var data: ArrayList<RechargeAmountDiscountResponseData>, var amount:Walletvalue) :
    RecyclerView.Adapter<RechargeWalletDiscountAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: WalletrechargediscountBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RechargeWalletDiscountAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.walletrechargediscount, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: RechargeWalletDiscountAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.amount.text = "₹ ${List.amount.toString()}"
        holder.binding.discount.text = "${List.extra.toString()}% Extra"
        amount.Amount(holder.binding.walletbox,List.amount!!.toInt(),holder.binding.amount,List.extra.toString())
    }

    override fun getItemCount(): Int {
        return data.size
    }
}
interface Walletvalue{
    fun Amount(box: LinearLayout,amount:Int,amounttext:TextView,discount:String)
}