package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.CommonResponse
import com.callastrouser.model.RemedyPoojaResponse
import com.callastrouser.model.RemedyProductResponse
import com.callastrouser.model.RemedySuggestedResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RemedyViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    val remedysuggestedResponse = MutableLiveData<RemedySuggestedResponse>()
    val remedyproductResponse = MutableLiveData<RemedyProductResponse>()
    val commonResponse = MutableLiveData<CommonResponse>()
    val remedyPoojaResponse = MutableLiveData<RemedyPoojaResponse>()

    fun RemedySuggested(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.RemedySuggested(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                remedysuggestedResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }
    fun add_to_cart(
        token: String,
        product_id: String,
        type: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.add_to_cart(token,product_id,type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                commonResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }


    }
    fun RemedyProduct(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.RemedyProduct(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                remedyproductResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


    fun get_puja_list(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.get_puja_list(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                remedyPoojaResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

}