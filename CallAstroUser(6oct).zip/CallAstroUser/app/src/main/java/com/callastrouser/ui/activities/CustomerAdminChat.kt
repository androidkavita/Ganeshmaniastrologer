package com.callastrouser.ui.activities

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.CustomerSupportChat
import com.callastrouser.databinding.ActivityCustomerAdminChatBinding
import com.callastrouser.model.GetCustomerSupportChatData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.CustomerViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CustomerAdminChat : BaseActivity() {
    lateinit var binding: ActivityCustomerAdminChatBinding
    private val viewModel: CustomerViewModel by viewModels()
    var Listdata : ArrayList<GetCustomerSupportChatData> = ArrayList()
    lateinit var adapter : CustomerSupportChat
    val handlerStatusCheck = Handler(Looper.getMainLooper())
    var runnableStatusCheck: Runnable? = null
    var isclick:Boolean = false
    lateinit var getUser_name :String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer_admin_chat)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_customer_admin_chat)

        getUser_name = intent.getStringExtra("list_userName").toString()
        binding.backArrow.setOnClickListener {
            finish()
        }
        binding.tvHeadName.text = getUser_name





        binding.ivChatSend.setOnClickListener {

            if (binding.etChatMsg.text.toString() == "") {
                toast(this,"Pls enter text")
            } else {
                if (isclick == false){
                    if (CommonUtils.isInternetAvailable(this)) {
                        viewModel.send_chat_with_us("Bearer "+userPref.getToken().toString(),binding.etChatMsg.text.toString())
                        moveForward()
                        messageList()
                    } else {
                        Log.d("TAG", "onCreate: " + "else part")
                        toast(this,"Please check internet connection.")
                    }
                    isclick = true
                }

            }


        }


        viewModel.customerSupportChat.observe(this) {
            if (it.status == 1) {
//                isscrollable = false
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = CustomerSupportChat(this, Listdata)
                binding.rvUserChat.adapter = adapter
                binding.rvUserChat.scrollToPosition(Listdata.size - 1);
                binding.rvUserChat.smoothScrollToPosition(binding.rvUserChat.adapter!!.itemCount)
                adapter!!.notifyDataSetChanged()
                Log.e("chat", it.message.toString())
            } else {
//                snackbar(it?.message!!)
            }
        }

        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                isclick = false
                binding.etChatMsg.setText("")
            }
        }
        moveForward()
    }

    private fun moveForward() {
        handlerStatusCheck.postDelayed(Runnable { //do // something
            handlerStatusCheck.postDelayed(runnableStatusCheck!!, 5000)
            messageList()

        }.also { runnableStatusCheck = it }, 0)
    }

    fun messageList() {
        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.get_chat_with_us("Bearer "+userPref.getToken().toString())
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

    }

}