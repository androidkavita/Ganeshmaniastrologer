package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class CartPlaceOrderResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : CartPlaceOrderResponseData?   = CartPlaceOrderResponseData()
)

data class CartPlaceOrderResponseData(
    @SerializedName("order_id"            ) var orderId           : String? = null,
    @SerializedName("product_name"        ) var productName       : String? = null,
    @SerializedName("payment_mode"        ) var paymentMode       : String? = null,
    @SerializedName("order_delivery"      ) var orderDelivery     : String? = null,
    @SerializedName("totalItem"      ) var totalItem     : String? = null,
    @SerializedName("expactDeliveryDate"      ) var expactDeliveryDate     : String? = null,
    @SerializedName("orderStatus"      ) var orderStatus     : String? = null,
    @SerializedName("order_delivery_time" ) var orderDeliveryTime : String? = null
)