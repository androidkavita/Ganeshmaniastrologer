package com.callastrouser.ui.fragments

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TimePicker
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.MainActivity
import com.callastrouser.R
import com.callastrouser.databinding.FragmentMatchMakingBinding
import com.callastrouser.model.LanguageResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.DateFormat
import com.callastrouser.viewModel.IntakeViewModel
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import dagger.hilt.android.AndroidEntryPoint
import java.util.*

@AndroidEntryPoint
class MatchMakingFragment : BaseFragment() {
    lateinit var binding: FragmentMatchMakingBinding
    private val viewModel: IntakeViewModel by viewModels()
    lateinit var astro_id:String
    lateinit var request_type:String
    var ListLanguagedata: ArrayList<LanguageResponseData> = ArrayList()
    var languagenamedata :ArrayList<String> = arrayListOf()
    var idlanguagedata :ArrayList<String> = arrayListOf()
    var selectedLanguageId= ""
    var selectedLanguagename= ""


    var placesClient: PlacesClient? = null
    private val AUTOCOMPLETE_PLACE1_REQUEST_CODE = 1
    private val AUTOCOMPLETE_PLACE2_REQUEST_CODE = 2
    var latLng: LatLng? = null
    var pickupLongitude = 0.0
    var pickupLatitude = 0.0
    var dropLongitude = 0.0
    var dropLatitude = 0.0
    var sourceLatLong: LatLng? = null
    var destLatLong: LatLng? = null
    var distance: Double? = null
    var distanceString: String? = null

    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentMatchMakingBinding.inflate(inflater,container,false)

        if (requireArguments().getString("id") != null) {
            astro_id = requireArguments().getString("id").toString()
            request_type = requireArguments().getString("request_type").toString()
        }

//        toast(astro_id)

        binding.etBoyDob.setOnClickListener {
            chooseDataPickerBoy()
        }
        binding.etGirlDob.setOnClickListener {
            chooseDataPickerGirl()
        }
        binding.etBoyTime.setOnClickListener {
            SelecttimeBoy()
        }
        binding.etGirlTime.setOnClickListener {
            SelecttimeGirl()
        }

        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        if (CommonUtils.isInternetAvailable(requireContext())) {
            LanguageAPI()
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

        binding.etLanguagestatus.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedLanguageId=idlanguagedata[p2]
                selectedLanguagename=languagenamedata[p2]
//                if (expertisenamedata.contains(expertisenamedata[p2])){
//                    toast("Already Selected")
//                }else{
//                languageaddData.add(selectedLanguagename)
//                }
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
        val apiKey = getString(R.string.api_key)
        if (!Places.isInitialized()) {
            Places.initialize(requireContext(), apiKey)
        }

        placesClient = Places.createClient(requireContext())
        binding.etBoyPlaceofbirth.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_PLACE1_REQUEST_CODE)
        }
        binding.etGirlPlaceofbirth.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_PLACE2_REQUEST_CODE)
        }



        binding.btnSubmit.setOnClickListener {
            if (binding.etBoyName.text.isNullOrEmpty()){
                toast("Please enter boy name.")
            }else if (binding.etBoyDob.text.isNullOrEmpty()){
                toast("Please enter boy's date of birth")
            }else if (binding.etBoyTime.text.isNullOrEmpty()){
                toast("Please enter boy's time of birth.")
            }else if (binding.etBoyPlaceofbirth.text.isNullOrEmpty()){
                toast("Please enter boy's place of birth.")
            }else if (binding.etGirlName.text.isNullOrEmpty()){
                toast("Please enter girl name.")
            }else if (binding.etGirlDob.text.isNullOrEmpty()){
                toast("Please enter girls' date of birth.")
            }else if (binding.etGirlTime.text.isNullOrEmpty()){
                toast("Please enter boy's girl's time of birth.")
            }else if (binding.etGirlPlaceofbirth.text.isNullOrEmpty()){
                toast("Please enter girl's place of birth.")
            }else{

                if (CommonUtils.isInternetAvailable(requireContext())) {
                    viewModel.MatchMaking(
                        "Bearer "+userPref.getToken().toString(),
                        binding.etBoyName.text.toString(),
                        binding.etBoyDob.text.toString(),
                        binding.etBoyTime.text.toString()+":00",
                        binding.etBoyPlaceofbirth.text.toString(),
                        binding.etBoyOccupation.text.toString(),
//                        binding.etMaritalStatusBoy.text.toString(),
//                        binding.etBoyConsultationtopic.text.toString(),
                        binding.etGirlName.text.toString(),
                        binding.etGirlDob.text.toString(),
                        binding.etGirlTime.text.toString()+":00",
                        binding.etGirlPlaceofbirth.text.toString(),
                        binding.etGirlOccupation.text.toString(),
//                        binding.etGirlMaritalstatus.text.toString(),
//                        binding.etGirlConsultationtopic.text.toString(),
                        request_type,astro_id,
                        selectedLanguageId
                    )
                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast("Please check internet connection.")
                }



            }

        }

        viewModel.matchmakingResponse.observe(viewLifecycleOwner){
            if (it.status == 1){
                var intent = Intent(requireContext(), MainActivity::class.java)
                    .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                Toast.makeText(requireContext(), it.message, Toast.LENGTH_SHORT).show()
            }
        }
        return binding.root
    }
    private fun placesAPiCall(requestCode: Int) {
        val fields = listOf(
            Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS,
            Place.Field.LAT_LNG
        )
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
            .build(requireContext())
        startActivityForResult(intent, requestCode)
    }




    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("TAG", "@@onActivityResult:")
        if (requestCode == AUTOCOMPLETE_PLACE1_REQUEST_CODE) {
            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    pickupLongitude = latLng!!.longitude
                    pickupLatitude = latLng!!.latitude

//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLAT,
//                        pickupLatitude.toString()
//                    )
//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLNG,
//                        pickupLongitude.toString()
//                    )

                    binding.etBoyPlaceofbirth.text = place.address
                    sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
                    Log.e("@@pickupLatitude", pickupLatitude.toString())
                }
                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                }
            }
            return
        }else{
            if (requestCode == AUTOCOMPLETE_PLACE2_REQUEST_CODE) {
                when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                    Activity.RESULT_OK -> {
                        val place = Autocomplete.getPlaceFromIntent(data!!)
                        Log.i("TAG", "Place: " + place.name + ", " + place.id)
                        latLng = place.latLng
                        pickupLongitude = latLng!!.longitude
                        pickupLatitude = latLng!!.latitude

//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLAT,
//                        pickupLatitude.toString()
//                    )
//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLNG,
//                        pickupLongitude.toString()
//                    )

                        binding.etGirlPlaceofbirth.text = place.address
                        sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
                        Log.e("@@pickupLatitude", pickupLatitude.toString())
                    }
                    AutocompleteActivity.RESULT_ERROR -> {
                        val status = Autocomplete.getStatusFromIntent(data!!)
                        Log.i("TAG", status.statusMessage!!)
                    }
                    Activity.RESULT_CANCELED -> {
                    }
                }
                return
            }
        }
    }

    fun LanguageAPI(){
        viewModel.Language(
            "Bearer "+userPref.getToken().toString()
        ).observe(viewLifecycleOwner) {
            if (it!!.status == 1) {
                ListLanguagedata.clear()
                languagenamedata.clear()
                ListLanguagedata.addAll(it!!.data)
                viewModel.languageResponseData.value = it.data
                for (i in 1 until it.data.size) {
                    languagenamedata.add(it.data[i].language.toString())
                    idlanguagedata.add(it.data[i].id.toString())
                }
                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
                    requireContext(),
                    android.R.layout.simple_spinner_dropdown_item,
                    languagenamedata
                )
                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.etLanguagestatus.adapter = spinnerArrayAdapter
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun chooseDataPickerBoy() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            requireContext(), R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                binding.etBoyDob.text =
                    DateFormat.addServiceDealsDate(simpleDateFormat.format(cal.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }
    @RequiresApi(Build.VERSION_CODES.N)
    private fun chooseDataPickerGirl() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            requireContext(), R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                binding.etGirlDob.text =
                    DateFormat.addServiceDealsDate(simpleDateFormat.format(cal.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }
    fun SelecttimeBoy() {
        val mTimePicker: TimePickerDialog
        val mcurrentTime = Calendar.getInstance()
        val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
        val minute = mcurrentTime.get(Calendar.MINUTE)

        mTimePicker = TimePickerDialog(
            requireContext(),
            R.style.MyTimePickerTheme,
            object : TimePickerDialog.OnTimeSetListener {
                override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                    if (hourOfDay < 10) {
                        if (minute <10){
                            binding.etBoyTime.setText(String.format("0%d:0%d",hourOfDay,minute))
                        }else{
                            binding.etBoyTime.setText(String.format("0%d:%d",hourOfDay,minute))
                        }

                    } else {
                        if (minute <10){
                            binding.etBoyTime.setText(String.format("%d:0%d",hourOfDay,minute))
                        }else{
                            binding.etBoyTime.setText(String.format("%d:%d",hourOfDay,minute))
                        }
                    }
                }
            },
            hour,
            minute,
            false
        )
        mTimePicker.show()
    }
    fun SelecttimeGirl() {
        val mTimePicker: TimePickerDialog
        val mcurrentTime = Calendar.getInstance()
        val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
        val minute = mcurrentTime.get(Calendar.MINUTE)

        mTimePicker = TimePickerDialog(
            requireContext(),
            R.style.MyTimePickerTheme,
            object : TimePickerDialog.OnTimeSetListener {
                override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                    if (hourOfDay < 10) {
                        if (minute <10){
                            binding.etGirlTime.setText(String.format("0%d:0%d",hourOfDay,minute))
                        }else{
                            binding.etGirlTime.setText(String.format("0%d:%d",hourOfDay,minute))
                        }

                    } else {
                        if (minute <10){
                            binding.etGirlTime.setText(String.format("%d:0%d",hourOfDay,minute))
                        }else{
                            binding.etGirlTime.setText(String.format("%d:%d",hourOfDay,minute))
                        }
                    }
                }
            },
            hour,
            minute,
            false
        )
        mTimePicker.show()
    }
}