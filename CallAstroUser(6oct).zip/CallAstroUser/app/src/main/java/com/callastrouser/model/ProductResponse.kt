package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class ProductResponse(
    @SerializedName("status"  ) var status  : Int?    = null,
    @SerializedName("message" ) var message : String? = null,
    @SerializedName("data"    ) var data    : ProductResponseData?   = ProductResponseData()
)
data class ProductResponseData(

    @SerializedName("product"         ) var product        : Product?                  = Product(),
    @SerializedName("product_images"  ) var productImages  : ArrayList<ProductImages>  = arrayListOf(),
    @SerializedName("product_details" ) var productDetails : ArrayList<ProductDetails> = arrayListOf(),
    @SerializedName("testimonials"    ) var testimonials   : ArrayList<Testimonials>   = arrayListOf()
)
data class Product (

    @SerializedName("id"          ) var id          : Int?    = null,
    @SerializedName("category_id" ) var categoryId  : Int?    = null,
    @SerializedName("name"        ) var name        : String? = null,
    @SerializedName("description" ) var description : String? = null,
    @SerializedName("price"       ) var price       : String? = null,
    @SerializedName("main_image"  ) var mainImage   : String? = null

)

data class ProductDetails (

    @SerializedName("title"       ) var title       : String? = null,
    @SerializedName("description" ) var description : String? = null

)

data class Testimonials (

    @SerializedName("user_id"   ) var userId   : Int?    = null,
    @SerializedName("rating"    ) var rating   : String? = null,
    @SerializedName("reveiw"    ) var reveiw   : String? = null,
    @SerializedName("user_name" ) var userName : String? = null,
    @SerializedName("profile"   ) var profile  : String? = null

)

data class ProductImages (

    @SerializedName("image" ) var image : String? = null

)