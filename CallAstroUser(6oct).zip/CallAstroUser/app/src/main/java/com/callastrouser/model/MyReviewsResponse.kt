package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class MyReviewsResponse(

    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<MyReviewsResponseData> = arrayListOf()
)
data class MyReviewsResponseData(
    @SerializedName("astro_id"      ) var astroId      : Int?    = null,
    @SerializedName("rating"        ) var rating       : String? = null,
    @SerializedName("reveiw"        ) var reveiw       : String? = null,
    @SerializedName("astro_name"    ) var astroName    : String? = null,
    @SerializedName("astro_profile" ) var astroProfile : String? = null
)