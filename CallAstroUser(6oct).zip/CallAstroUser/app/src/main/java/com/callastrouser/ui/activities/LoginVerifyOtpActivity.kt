package com.callastrouser.ui.activities

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.MainActivity
import com.callastrouser.R
import com.callastrouser.databinding.ActivityLoginVerifyOtpBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.toast
import com.callastrouser.viewModel.LoginViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginVerifyOtpActivity : BaseActivity() {
    private lateinit var binding: ActivityLoginVerifyOtpBinding
    private val viewModel: LoginViewModel by viewModels()
    var id: String = ""
    var otp: String = ""
    var is_new: String = ""
    var mobile: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login_verify_otp)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        if (intent != null) {
            id = intent.getStringExtra("id").toString()
            otp = intent.getStringExtra("otp").toString()
            is_new = intent.getStringExtra("is_new").toString()
            mobile = intent.getStringExtra("mobile").toString()
        }
        binding.otptext.text = "OTP sent to $mobile"

        TimeCountDown()

        binding.otpView.addTextChangedListener(
            object : TextWatcher {
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

                }

                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                    val  getOtp=p0.toString()
                    if (getOtp.length==4){
//                        veriefyOtp!!.isEnabled=true
//                        veriefyOtp.isClickable=true
//                        veriefyOtp.setBackgroundColor(resources.getColor(R.color.black))
                        val imm: InputMethodManager? = getSystemService(Context.INPUT_METHOD_SERVICE)as InputMethodManager;
                        imm?.hideSoftInputFromWindow(binding.otpView.getWindowToken(), 0);
                    }else{
//                        veriefyOtp!!.isEnabled=false
//                        veriefyOtp.isClickable=false
//                        veriefyOtp.setBackgroundColor(resources.getColor(R.color.gray_button))
                    }
                }

                override fun afterTextChanged(p0: Editable?) {

                }

            }
        )


        binding.resentotp.setOnClickListener {
            viewModel.Recent_otp(
                mobile,"1"
            )

        }
//        val one = number.substring(0, 5)
//        val two = number.substring(5, 10)
//        NumberTv.setText("$one $two")


//        et1 = findViewById(R.id.et_1)
//        et2 = findViewById(R.id.et_2)
//        et3 = findViewById(R.id.et_3)
//        et4 = findViewById(R.id.et_4)
//        textView = findViewById(R.id.timer)


        viewModel.loginResponse.observe(this){
            if (it.status == 1){
                toast(this@LoginVerifyOtpActivity,it.data?.otp.toString())
                TimeCountDown()
            }
        }

        toast(otp)
        binding.btnOtpSubmit.setOnClickListener(View.OnClickListener {
            if (binding.otpView.text.isNullOrEmpty()) {
                snackbar("Please enter OTP")
            } else {

                if (CommonUtils.isInternetAvailable(this)) {
                    viewModel.LoginVerification(
                        id,
                        binding.otpView.text.toString()
                    )
                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this,"Please check internet connection.")
                }

            }
        })

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.loginVerificationResponse.observe(this) {
            if (it?.status == 1) {
                if (is_new == "1") {
                    var intent = Intent(this, Registration::class.java)
                    intent.putExtra("id", id)
                    intent.putExtra("otp", otp)
                    intent.putExtra("otp", mobile)
                    startActivity(intent)
                } else {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finishAffinity()
//                userPref.user = it.data!!
                    userPref.isLogin = true
                    userPref.setid(it.data?.id.toString())
                    userPref.setUserId(it.data!!.id!!.toString())
                    userPref.setMobile(it.data!!.mobileNo.toString())
                    userPref.setToken(it.data!!.apiToken)
                    userPref.setName(it.data?.name!!)
                    userPref.setEmail(it.data!!.email)
                    userPref.setProfile(it.data!!.profile.toString())

                }
//                viewModel.agora_create_userApi("Bearer " + it.otpdata!!.apiToken.toString(), it.otpdata?.id.toString(), "TestName")

//                it.data!!.profileImage?.let { it1 -> userPref.setImage(it1) }
//                userPref.setUserId(it!!.data!!.Id.toString())

                } else {
                    //toast(it.message)
                    snackbar(it?.message!!)
                }
            }

        }
    fun TimeCountDown(){
        object : CountDownTimer(60000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                if(millisUntilFinished / 1000<10){
                    binding.timer.setText("00:0" + millisUntilFinished / 1000)
                }else{
                    binding.timer.setText("00:" + millisUntilFinished / 1000)

                }
                binding.resentotp.isEnabled = false
                binding.resentotp.setBackgroundDrawable(resources.getDrawable(R.drawable.buttondisable))

            }

            override fun onFinish() {
                binding.timer.setText("00:00")
                binding.resentotp.isEnabled = true
                binding.resentotp.setBackgroundDrawable(resources.getDrawable(R.drawable.button))

            }
        }.start()
    }
    }