package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class SendKundliResponse(
@SerializedName("status"  ) var status  : Int?    = null,
@SerializedName("message" ) var message : String? = null,
@SerializedName("data"    ) var data    : Boolean? = null

)
