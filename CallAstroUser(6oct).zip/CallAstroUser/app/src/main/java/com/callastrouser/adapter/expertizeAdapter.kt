package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowTopicSuggestionBinding
import com.callastrouser.model.ExpertizeResponseData

class expertizeAdapter (val context : Context, var data: ArrayList<ExpertizeResponseData>,var astroid:Astroid) :
    RecyclerView.Adapter<expertizeAdapter.ViewHolder>() {

    var id :String = ""
    private var selectedItemPosition: Int = 0
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var binding: RowTopicSuggestionBinding = DataBindingUtil.bind(itemView)!!
    }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): expertizeAdapter.ViewHolder {
            val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_topic_suggestion, parent, false)
            return ViewHolder(itemView)
        }

        @SuppressLint("SetTextI18n")
        override fun onBindViewHolder(holder: expertizeAdapter.ViewHolder, @SuppressLint("RecyclerView") position: Int) {
            val List = data[position]
            holder.binding.category.setText(List.name.toString())

            id = List.id.toString()
            holder.binding.category.setOnClickListener {
                selectedItemPosition = position
                notifyDataSetChanged()
                astroid.id(List.id.toString())
            }
            if(selectedItemPosition == position){
                holder.binding.category.setTextColor(Color.parseColor("#FFFFFF"))
                holder.binding.category.setBackgroundResource(R.drawable.redbackgroundbutton)

            } else{
                holder.binding.category.setTextColor(Color.parseColor("#530C0C"))
                holder.binding.category.setBackgroundResource(R.drawable.white_background_round)

            }
        }

        override fun getItemCount(): Int {
            return data.size
        }
}
interface Astroid{
    fun id(id:String)
}
