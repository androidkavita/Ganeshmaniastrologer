package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.callastrouser.MainActivity
import com.callastrouser.R
import com.maxtra.callastro.prefs.UserPref

class SplashScreen : AppCompatActivity() {
    private  val splashTimeout : Long = 2000 //2sec
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)


        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)




//        if (CommonUtils.isInternetAvailable(this)) {
            checkLogin()
//        } else {
//            Log.d("TAG", "onCreate: " + "else part")
//            toast("Please check internet connection.")
//        }


        val extras = intent.extras

        if (extras != null) {
            // possible launched from notification
            // check if desired notification data present in extras then its
            // confirmed that launched from notification
        } else {
            // not launched from notification
        }



    }

    private fun checkLogin(){
        Handler().postDelayed({

            val userPref = UserPref(this)
            if(userPref.isLogin){
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finishAffinity()
            }else {
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
        },splashTimeout)
    }
}