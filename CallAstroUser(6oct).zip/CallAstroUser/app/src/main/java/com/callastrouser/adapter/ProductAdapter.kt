package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.callastrouser.R
import com.callastrouser.databinding.RowHistoryProductsSuggestedBinding
import com.callastrouser.model.RemedyProductResponseData

class ProductAdapter (val context : Context, var data: ArrayList<RemedyProductResponseData>, var transfer: ShopCategoryRemedy) :
    RecyclerView.Adapter<ProductAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowHistoryProductsSuggestedBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_history_products_suggested, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ProductAdapter.ViewHolder, position: Int) {
        val List = data[position]
        holder.binding.productname.text = List.productName.toString()
        holder.binding.productprise.text = List.price.toString()
//        holder.binding.money.text = List.
        Glide.with(context).load(List.mainImage).into(holder.binding.ivImage)
        transfer.layoutid(holder.binding.llGroceryItem,List.productId.toString(),List.productName.toString(),holder.binding.tvMinus,
            holder.binding.tvCount.text.toString(),holder.binding.tvPlus)

    }

    override fun getItemCount(): Int {
        return data.size
    }

    interface ShopCategoryRemedy{
        fun layoutid(layout: LinearLayout, id:String, name:String, minus: ImageView, qty:String, plus: ImageView)
    }

}