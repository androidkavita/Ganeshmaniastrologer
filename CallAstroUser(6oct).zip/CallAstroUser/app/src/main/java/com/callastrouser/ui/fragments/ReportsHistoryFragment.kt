package com.callastrouser.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.viewModels
import com.callastro.baseClass.BaseFragment
import com.callastrouser.adapter.ClickReport
import com.callastrouser.adapter.ReportsHistoryAdapter
import com.callastrouser.databinding.FragmentReportsHistoryBinding
import com.callastrouser.model.ReportsHistoryResponseData
import com.callastrouser.ui.activities.ViewReport
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.DashboardHistoryWalletViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ReportsHistoryFragment : BaseFragment(), ClickReport {
    lateinit var binding: FragmentReportsHistoryBinding
    private val viewModel: DashboardHistoryWalletViewModel by viewModels()
    lateinit var adapter: ReportsHistoryAdapter
    var List:ArrayList<ReportsHistoryResponseData> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentReportsHistoryBinding.inflate(inflater,container,false)

        if (CommonUtils.isInternetAvailable(requireContext())) {
            viewModel.history_reports(
                "Bearer "+userPref.getToken().toString()
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast("Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.historyReportsResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                binding.rvwallethistory.visibility = View.VISIBLE
                binding.nodatatext.visibility = View.GONE
                List.clear()
                List.addAll(it.data)
                adapter = ReportsHistoryAdapter(requireContext(), List,this)
                binding.rvwallethistory.adapter = adapter
            } else {
                binding.rvwallethistory.visibility = View.GONE
                binding.nodatatext.visibility = View.VISIBLE
//                snackbar(it?.message!!)
            }
        }
        return binding.root
    }

    override fun layoutid(id: String, layout: LinearLayout) {
        startActivity(Intent(requireContext(), ViewReport::class.java).putExtra("id",id))

    }
}