package com.callastrouser.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.callastrouser.R
import com.callastrouser.databinding.RowConsultancyOrdersBinding
import com.callastrouser.model.ConsultancyOrderResponseData
import com.maxtra.astrorahi.interfaces.ProductDetailsconsultancy
import com.squareup.picasso.Picasso

class ConsultancyAdapter (val context : Context, var List:ArrayList<ConsultancyOrderResponseData>, var details: ProductDetailsconsultancy) :
    RecyclerView.Adapter<ConsultancyAdapter.ViewHolder>() {
    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowConsultancyOrdersBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ConsultancyAdapter.ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_consultancy_orders, parent, false)
        return ViewHolder(itemView)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ConsultancyAdapter.ViewHolder, position: Int) {
        val List = List[position]
        holder.binding.name.text = List.astroName.toString()
        holder.binding.tvBookingId.text = List.bookingId.toString()
        holder.binding.tvDate.text = List.bookingDate.toString()
        holder.binding.tvTime.text = List.bookingTime.toString()
        holder.binding.amtpermin.text = "₹"+List.astroPackage.toString()
        holder.binding.amount.text = "₹"+List.price.toString()

        holder.binding.duration.text = "${List.duration.toString()} min"
//        Glide.with(context).load(List.astroIamge).into(holder.binding.image)
        Picasso.get().load(List.astroIamge).into(holder.binding.image)
        details.Details(holder.binding.btnDetails,List.bookingId.toString(),holder.binding.help,List.astro_id.toString(),List.type.toString())
        if (List.type == 2){
            holder.binding.callimage.setImageResource(R.drawable.ic_call)
            holder.binding.call.text = "Call"
        }else if (List.type == 1){
            holder.binding.callimage.setImageResource(R.drawable.ic_chat)
            holder.binding.call.text = "Chat"
        }else if (List.type == 3){
            holder.binding.callimage.setImageResource(R.drawable.ic_video_call)
            holder.binding.call.text = "Video"
        }

        if(List.status!!.equals(1)){
            holder.binding.tvConfirmationStatus.text = "Completed"
            holder.binding.tvConfirmationStatus.setTextColor(Color.parseColor("#2B7D24"))
        }else{
            holder.binding.tvConfirmationStatus.text = "Pending"
            holder.binding.tvConfirmationStatus.setTextColor(Color.parseColor("#a80017"))
        }


    }

    override fun getItemCount(): Int {
        return List.size
    }
}