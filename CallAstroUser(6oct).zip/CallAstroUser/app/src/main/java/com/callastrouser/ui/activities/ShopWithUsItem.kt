package com.callastrouser.ui.activities

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.adapter.CategoryListAdapter
import com.callastrouser.databinding.ActivityShopWithUsItemBinding
import com.callastrouser.model.CategoryProductResponseData
import com.callastrouser.model.ChatFragmentResponseData
import com.callastrouser.util.CommonUtils
import com.callastrouser.viewModel.HomeViewModel
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import java.util.ArrayList
import kotlin.math.min

@AndroidEntryPoint
class ShopWithUsItem : BaseActivity(),CategoryListAdapter.ShopCategory {
    lateinit var binding : ActivityShopWithUsItemBinding
    lateinit var adapter: CategoryListAdapter
    var Listdata: ArrayList<CategoryProductResponseData> = ArrayList()
    private val viewModel: HomeViewModel by viewModels()
    lateinit var id :String
    lateinit var name :String
    var scpflag: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shop_with_us_item)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_shop_with_us_item)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        if (intent  != null){
            id = intent.getStringExtra("id").toString()
            name = intent.getStringExtra("name").toString()
        }
        binding.header.backArrow.setOnClickListener {
            finish()
        }
        binding.header.tvHeadName.text = name

        if (CommonUtils.isInternetAvailable(this)) {
            viewModel.CategoryList(
                "Bearer "+userPref.getToken().toString(),
                id
            )
        } else {
            Log.d("TAG", "onCreate: " + "else part")
            toast(this,"Please check internet connection.")
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.categoryproductResponse.observe(this){
            if (it.status == 1){
                Listdata.clear()
                Listdata.addAll(it.data)
                adapter = CategoryListAdapter(this,Listdata,this)
                binding.rvShopWithUsItem.adapter = adapter
            }else{
                snackbar(it.message.toString())
            }
        }

        viewModel.commonResponse.observe(this){
            if (it.status == 1){
                toast(this@ShopWithUsItem,"Product added successfully.")
            }else{
                snackbar(it.message.toString())
            }
        }

        binding.tvSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(text: Editable?) {
                filterData(text.toString(), scpflag)
            }

        })
    }

    private fun filterData(searchText: String, scpflag: String) {
        var filteredStateList: ArrayList<CategoryProductResponseData> = ArrayList()
        for (item in Listdata) {
            try {
                if (item.name!!.toLowerCase().contains(searchText.toLowerCase())) {
                    filteredStateList.add(item)
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
        }


        try {
            adapter?.filterList(filteredStateList)
        } catch (e:Exception) {
            e.printStackTrace()
        }
    }
    override fun layoutid(layout: LinearLayout, id: String, name: String, minus: ImageView, qty:String, plus: ImageView) {
        layout.setOnClickListener {
            var intent = Intent(this,ShopWithUsItemDetails::class.java)
            intent.putExtra("id",id)
            intent.putExtra("name",name)
            startActivity(intent)
        }
        minus.setOnClickListener {
            viewModel.add_to_cart("Bearer "+userPref.getToken().toString(),id,"2")
        }
        plus.setOnClickListener {
            viewModel.add_to_cart("Bearer "+userPref.getToken().toString(),id,"1")
        }
    }



}