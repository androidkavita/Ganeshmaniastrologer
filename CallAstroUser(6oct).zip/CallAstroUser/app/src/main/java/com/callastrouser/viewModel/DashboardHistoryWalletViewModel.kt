package com.callastrouser.viewModel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.callastro.data.MainRepository
import com.callastrouser.model.CallHistoryResponse
import com.callastrouser.model.ChatHistoryResponse
import com.callastrouser.model.HistoryProductSuggestedResponse
import com.callastrouser.model.HistoryWallet
import com.callastrouser.model.MissedCallChatResponse
import com.callastrouser.model.ReportsHistoryResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardHistoryWalletViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {

    val progressBarStatus = MutableLiveData<Boolean>()
    val historyWalletResponse = MutableLiveData<HistoryWallet>()
    val historyCallResponse = MutableLiveData<CallHistoryResponse>()
    val historyChatResponse = MutableLiveData<ChatHistoryResponse>()
    val historyReportsResponse = MutableLiveData<ReportsHistoryResponse>()
    val historyProductSuggestedResponse = MutableLiveData<HistoryProductSuggestedResponse>()
    val missedCallChatResponse = MutableLiveData<MissedCallChatResponse>()

    fun HistoryWallet(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.HistoryWallet(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                historyWalletResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun missed_requests(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.missed_requests(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                missedCallChatResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun history_call(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.history_call(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                historyCallResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun history_chat(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.history_chat(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                historyChatResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun history_reports(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.history_reports(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                historyReportsResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun history_products(
        token: String,
        type:String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.history_products(token,type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                historyProductSuggestedResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }


}