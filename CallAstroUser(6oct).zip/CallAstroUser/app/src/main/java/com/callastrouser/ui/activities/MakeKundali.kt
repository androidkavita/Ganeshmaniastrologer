package com.callastrouser.ui.activities

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.ViewGroup
import android.widget.TimePicker
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import com.callastrouser.R
import com.callastrouser.databinding.ActivityMakeKundaliBinding
import com.callastrouser.util.CommonUtils
import com.callastrouser.util.DateFormat
import com.callastrouser.util.toast
import com.callastrouser.viewModel.KundaliViewModel
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.maxtra.callastro.baseClass.BaseActivity
import dagger.hilt.android.AndroidEntryPoint
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone


@AndroidEntryPoint
class MakeKundali : BaseActivity()/*, SlideDatePickerDialogCallback*/ {
    lateinit var binding: ActivityMakeKundaliBinding
    val viewModel: KundaliViewModel by viewModels()
    private val AUTOCOMPLETE_PLACE_BOY_REQUEST_CODE = 1
    private val AUTOCOMPLETE_PLACE_GIRL_REQUEST_CODE = 2
    var latLng: LatLng? = null
    var pickupLongitude = 0.0
    var pickupLatitude = 0.0
    var dropLongitude = 0.0
    var dropLatitude = 0.0
    var sourceLatLong: LatLng? = null
    var destLatLong: LatLng? = null
    var distance: Double? = null
    var distanceString: String? = null
    var BoyTime: String? = null
    var GirlTime: String? = null
    var placesClient: PlacesClient? = null
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_make_kundali)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_make_kundali)
        val apiKey = getString(R.string.api_key)
        if (!Places.isInitialized()) {
            Places.initialize(this, apiKey)
        }
        placesClient = Places.createClient(this)
        binding.header.tvHeadName.text = "Kundli"
        binding.header.backArrow.setOnClickListener { finish() }



        binding.etBoyBirthdate.setOnClickListener {
            chooseDatBoyPicker()
        }

        binding.etgirlBirthdate.setOnClickListener {
            chooseDatGirlPicker()
        }

        binding.etBoyBirthtime.setOnClickListener {
            SelectBoytime()
        }

        binding.etgirlBirthtime.setOnClickListener {
            SelectGirltime()
        }

        viewModel.sendKundliResponse.observe(this){
            if (it.status == 1){
                startActivity(Intent(this@MakeKundali,MatchHoroscope::class.java)
                    .putExtra("boydob",binding.etBoyBirthdate.text.toString(),)
                    .putExtra("boytob",BoyTime)
                    .putExtra("girldob",binding.etgirlBirthdate.text.toString(),)
                    .putExtra("girltob",GirlTime)
                    .putExtra("picklat",pickupLatitude)
                    .putExtra("picklong",pickupLongitude)
                    .putExtra("droplat",dropLatitude)
                    .putExtra("droplong",dropLongitude))
            }
        }

        binding.btnSubmit.setOnClickListener {
            if (binding.etboyname.text.isNullOrEmpty()){
                toast(this@MakeKundali,"Please enter boy name.")
            }else if (binding.etBoyBirthdate.text.isNullOrEmpty()){
            toast(this@MakeKundali,"Please enter boy's date of birth.")
            }else if (binding.etBoyBirthtime.text.isNullOrEmpty()){
                toast(this@MakeKundali,"Please enter boy's time of birth.")
            }else if (binding.etBoyBirthplace.text.isNullOrEmpty()){
                toast(this@MakeKundali,"Please enter boy's place of birth.")
            }else if (binding.etgirlname.text.isNullOrEmpty()){
                toast(this@MakeKundali,"Please enter girl name.")
            }else if (binding.etgirlBirthdate.text.isNullOrEmpty()){
                toast(this@MakeKundali,"Please enter girl's date of birth.")
            }else if (binding.etgirlBirthtime.text.isNullOrEmpty()){
                toast(this@MakeKundali,"Please enter girl's time of birth.")
            }else if (binding.etgirlBirthplace.text.isNullOrEmpty()){
                toast(this@MakeKundali,"Please enter girl's place of birth.")
            }else{

                if (CommonUtils.isInternetAvailable(this)) {

                    var splitLink = binding.etBoyBirthdate.text.toString().split("/").toTypedArray()
                    var startdate = splitLink[0]
                    var middledate = splitLink[1]
                    var enddate = splitLink[2]

                    var splitTime = BoyTime?.split(":")!!.toTypedArray()
                    var starttime = splitTime[0]
                    var endtime = splitTime[1]

                    var splitLinkgirl = binding.etgirlBirthdate.text.toString().split("/").toTypedArray()
                    var startdategirl = splitLink[0]
                    var middledategirl = splitLink[1]
                    var enddategirl = splitLink[2]

                    var splitTimegirl = GirlTime?.split(":")!!.toTypedArray()
                    var starttimegirl = splitTime[0]
                    var endtimegirl = splitTime[1]

                    viewModel.insert_recently_see_match_making_kundali(
                        "Bearer "+userPref.getToken().toString(),
                        binding.etgirlname.text.toString(),
                        startdategirl,middledategirl,enddategirl,starttimegirl,endtimegirl,"0",dropLatitude.toString(),dropLongitude.toString(),"5.5",
                        binding.etgirlBirthplace.text.toString(),binding.etboyname.text.toString(),startdate,middledate,enddate,starttime,endtime,"0",pickupLatitude.toString(),pickupLongitude.toString(),"5.5",binding.etBoyBirthplace.text.toString()
                    )

//                viewModel.MakeKundali(
//                    "Bearer "+userPref.getToken().toString(),
//                    binding.etboyname.text.toString(),
//                    binding.etBoyBirthdate.text.toString(),
//                    binding.etBoyBirthtime.text.toString(),
//                    binding.etBoyBirthplace.text.toString(),
//                    binding.etgirlname.text.toString(),
//                    binding.etgirlBirthdate.text.toString(),
//                    binding.etgirlBirthtime.text.toString(),
//                    binding.etgirlBirthplace.text.toString()
//
//                )

//                viewModel.match_making(
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                    "",
//                )

                } else {
                    Log.d("TAG", "onCreate: " + "else part")
                    toast(this,"Please check internet connection.")
                }

            }


        }
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
//        viewModel.makeKundaliResponse.observe(this) {
//            if (it?.status == 1) {
//                startActivity(Intent(this@MakeKundali,MatchHoroscope::class.java)
//                    .putExtra("boydob",binding.etBoyBirthdate.text.toString(),)
//                    .putExtra("boytob",binding.etBoyBirthtime.text.toString(),)
//                    .putExtra("girldob",binding.etgirlBirthdate.text.toString(),)
//                    .putExtra("girltob",binding.etgirlBirthtime.text.toString(),)
//                    .putExtra("picklat",pickupLatitude)
//                    .putExtra("picklong",pickupLongitude)
//                    .putExtra("droplat",dropLatitude)
//                    .putExtra("droplong",dropLongitude)
//                )
//            } else {
//                //toast(it.message)
//                snackbar(it?.message!!)
//            }
//        }

        viewModel.kundliMatchMakingResponse.observe(this){
            if (it.statusCode == 200){


            }
        }
        binding.etBoyBirthplace.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_PLACE_BOY_REQUEST_CODE)
        }

        binding.etgirlBirthplace.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_PLACE_GIRL_REQUEST_CODE)
        }
    }

    private fun placesAPiCall(requestCode: Int) {
        val fields = listOf(
            Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS,
            Place.Field.LAT_LNG
        )
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
            .build(this)
        startActivityForResult(intent, requestCode)
    }

        override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == AUTOCOMPLETE_PLACE_BOY_REQUEST_CODE) {
            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    pickupLongitude = latLng!!.longitude
                    pickupLatitude = latLng!!.latitude

//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLAT,
//                        pickupLatitude.toString()
//                    )
//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLNG,
//                        pickupLongitude.toString()
//                    )

                    binding.etBoyBirthplace.text = place.address
                    sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
                }
                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                }
            }
            return
        }else if (requestCode == AUTOCOMPLETE_PLACE_GIRL_REQUEST_CODE) {
            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    dropLongitude = latLng!!.longitude
                    dropLatitude = latLng!!.latitude

//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLAT,
//                        pickupLatitude.toString()
//                    )
//                    SavedPrefManager.saveStringPreferences(
//                        this,SavedPrefManager.PICLNG,
//                        pickupLongitude.toString()
//                    )

                    binding.etgirlBirthplace.text = place.address
                    sourceLatLong = LatLng(dropLongitude, dropLatitude)
                }
                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                }
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }


//    // date picker
//    @RequiresApi(Build.VERSION_CODES.N)
//    override fun onPositiveClick(date: Int, month: Int, year: Int, calendar: Calendar) {
//        val format = SimpleDateFormat("EEEE, MMM dd, yyyy", Locale.getDefault())
//        binding.etBoyBirthdate.setText(format.format(calendar.time))
//    }


    @RequiresApi(Build.VERSION_CODES.N)
    private fun chooseDatBoyPicker() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            this, R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                binding.etBoyBirthdate.text =
                    DateFormat.getHoroscopeDate(simpleDateFormat.format(cal.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
//        datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }


    fun SelectBoytime() {
        val mTimePicker: TimePickerDialog
        val mcurrentTime = Calendar.getInstance()
        val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
        val minute = mcurrentTime.get(Calendar.MINUTE)

        mTimePicker = TimePickerDialog(
            this,
            R.style.MyTimePickerTheme,
            object : TimePickerDialog.OnTimeSetListener {
                override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                    BoyTime = String.format("%d:%d",hourOfDay,minute)
                    if (hourOfDay < 10) {
                        if (minute <10){
                            binding.etBoyBirthtime.setText(String.format("0%d:0%d",hourOfDay,minute))
                        }else{
                            binding.etBoyBirthtime.setText(String.format("0%d:%d",hourOfDay,minute))
                        }

                    }else{
                        if (minute < 10) {
                            binding.etBoyBirthtime.setText(String.format("%d:0%d", hourOfDay, minute))
                        } else {
                            binding.etBoyBirthtime.setText(String.format("%d:%d", hourOfDay, minute))

                        }
                    }

                }
            },
            hour,
            minute,
            false
        )
        mTimePicker.show()
    }

    @RequiresApi(Build.VERSION_CODES.N)
    private fun chooseDatGirlPicker() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            this, R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                binding.etgirlBirthdate.text =
                    DateFormat.getHoroscopeDate(simpleDateFormat.format(cal.time))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
//        datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }
    fun SelectGirltime() {
        val mTimePicker: TimePickerDialog
        val mcurrentTime = Calendar.getInstance()
        val hour = mcurrentTime.get(Calendar.HOUR_OF_DAY)
        val minute = mcurrentTime.get(Calendar.MINUTE)

        mTimePicker = TimePickerDialog(
            this,
            R.style.MyTimePickerTheme,
            object : TimePickerDialog.OnTimeSetListener {
                override fun onTimeSet(view: TimePicker?, hourOfDay: Int, minute: Int) {
                    GirlTime = String.format("%d:%d",hourOfDay,minute)
                    if (hourOfDay < 10) {
                        if (minute <10){
                            binding.etgirlBirthtime.setText(String.format("0%d:0%d",hourOfDay,minute))
                        }else{
                            binding.etgirlBirthtime.setText(String.format("0%d:%d",hourOfDay,minute))
                        }

                    }else{
                        if (minute < 10) {
                            binding.etgirlBirthtime.setText(String.format("%d:0%d", hourOfDay, minute))
                        } else {
                            binding.etgirlBirthtime.setText(String.format("%d:%d", hourOfDay, minute))

                        }
                    }

                }
            },
            hour,
            minute,
            false
        )
        mTimePicker.show()
    }
}