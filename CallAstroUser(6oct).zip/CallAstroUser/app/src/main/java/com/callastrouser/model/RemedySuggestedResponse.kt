package com.callastrouser.model

import com.google.gson.annotations.SerializedName

data class RemedySuggestedResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<RemedySuggestedData> = arrayListOf()
)
data class RemedySuggestedData(
    @SerializedName("id"            ) var id           : Int?    = null,
    @SerializedName("astro_id"      ) var astroId      : Int?    = null,
    @SerializedName("suggest"       ) var suggest      : String? = null,
    @SerializedName("astro_name"    ) var astroName    : String? = null,
    @SerializedName("astro_profile" ) var astroProfile : String? = null
)